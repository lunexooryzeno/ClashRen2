import { EntryCardOption, HostWorker } from '../types';

export const ENTRY_CARDS: EntryCardOption[] = [
  { id: 'card-0-2', entryFee: 0, prize: 2 },
  { id: 'card-5-10', entryFee: 5, prize: 10 },
  { id: 'card-10-20', entryFee: 10, prize: 20 },
  { id: 'card-15-30', entryFee: 15, prize: 30 },
  { id: 'card-20-40', entryFee: 20, prize: 40 },
];

export const DEFAULT_HOST_WORKERS: HostWorker[] = [
  {
    workerId: 'HOST-PHONE-01',
    name: 'MacroDroid FF Host #1 (Redmi Note 12)',
    webhookUrl: 'https://trigger.macrodroid.com/98315e1f-abce-4c9f-ab7d-87004928eb82/clashren',
    status: 'ONLINE',
    battery: 92,
    internet: '5G',
    lastHeartbeatAt: Date.now(),
    isEnabled: true,
  },
  {
    workerId: 'VERIFY-PHONE-01',
    name: 'OCR Verification Worker #1 (Poco X5 Pro)',
    webhookUrl: 'https://trigger.macrodroid.com/ocr-verify-clashren-01/status',
    status: 'ONLINE',
    battery: 88,
    internet: 'WIFI',
    lastHeartbeatAt: Date.now(),
    isEnabled: true,
  }
];

export const DEFAULT_WHATSAPP_NUMBER = '15551234567'; // Default community host WhatsApp
