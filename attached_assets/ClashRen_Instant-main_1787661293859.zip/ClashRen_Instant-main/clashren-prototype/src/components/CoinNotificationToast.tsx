import React from 'react';
import { Coins, CheckCircle2, X } from 'lucide-react';

interface CoinNotificationToastProps {
  amount: number;
  newBalance: number;
  message?: string;
  onClose: () => void;
}

export const CoinNotificationToast: React.FC<CoinNotificationToastProps> = ({
  amount,
  newBalance,
  message,
  onClose,
}) => {
  return (
    <div className="fixed top-16 right-4 z-50 max-w-sm w-full bg-slate-900 border-2 border-emerald-500/50 rounded-2xl p-4 shadow-2xl animate-bounce-short space-y-2">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h4>+{amount} Coins Added Successfully</h4>
            <p className="text-[10px] text-slate-300 font-normal">
              Your wallet has been credited by the ClashRen admin.
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-mono">
        <span className="text-slate-400">New Wallet Balance:</span>
        <span className="font-bold text-amber-400 text-sm">{newBalance} Coins</span>
      </div>
    </div>
  );
};
