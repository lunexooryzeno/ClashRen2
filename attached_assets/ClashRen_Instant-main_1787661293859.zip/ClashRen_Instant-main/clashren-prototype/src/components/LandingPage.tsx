import React from 'react';
import { ShieldCheck, Flame, Zap, Users, MessageSquareHeart, RefreshCw, AlertTriangle } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
  onOpenFeedback: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onOpenFeedback }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 md:p-8 relative overflow-hidden">
      {/* Background ambient glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Banner */}
      <header className="max-w-4xl w-full mx-auto flex items-center justify-between py-4 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
            <Flame className="w-6 h-6 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="font-bold text-xl tracking-tight text-white flex items-center gap-2">
              ClashRen <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">PROTOTYPE</span>
            </h1>
            <p className="text-xs text-slate-400">Free Fire Matchmaking System</p>
          </div>
        </div>

        <button
          onClick={onOpenFeedback}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-300 border border-slate-700/60 transition-all"
        >
          <MessageSquareHeart className="w-4 h-4 text-amber-400" />
          <span>Feedback</span>
        </button>
      </header>

      {/* Main Hero Card */}
      <main className="max-w-md w-full mx-auto my-auto py-8 text-center flex flex-col items-center">
        {/* Prototype Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/90 border border-amber-500/30 text-amber-300 text-xs font-medium mb-6 backdrop-blur-sm">
          <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>WhatsApp Testing Prototype (600+ Members)</span>
        </div>

        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-3">
          ClashRen <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-500">Prototype</span>
        </h2>

        <p className="text-amber-400/90 font-medium text-sm sm:text-base mb-4">
          Real-time Free Fire instant matchmaking prototype
        </p>

        <p className="text-slate-400 text-sm leading-relaxed mb-8 max-w-sm">
          This is an early prototype built for testing the instant matchmaking system. The platform is still under development and will continue improving over time.
        </p>

        {/* Action Button */}
        <button
          onClick={onGetStarted}
          className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-base shadow-xl shadow-orange-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 mb-8 cursor-pointer"
        >
          <span>Get Started</span>
          <Zap className="w-5 h-5 fill-slate-950" />
        </button>

        {/* Prototype Info Bullet Grid */}
        <div className="w-full bg-slate-900/60 rounded-2xl p-4 border border-slate-800 text-left space-y-3">
          <div className="flex items-start gap-3">
            <div className="p-1 rounded-lg bg-amber-500/10 text-amber-400 mt-0.5">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">Prototype Version (v1.0-beta)</p>
              <p className="text-[11px] text-slate-400">Testing environment optimized for Clash Squad 1v1 Normal.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-1 rounded-lg bg-orange-500/10 text-orange-400 mt-0.5">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">Continuous Improvements</p>
              <p className="text-[11px] text-slate-400">Features may change, matchmaking parameters updated dynamically.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-1 rounded-lg bg-amber-500/10 text-amber-400 mt-0.5">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-200">Data & Wallet Reset Notice</p>
              <p className="text-[11px] text-slate-400">Coins are prototype test balances for workflow evaluation.</p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
            <span className="text-amber-400 font-semibold flex items-center gap-1">
              <Users className="w-3.5 h-3.5" /> Your feedback really matters
            </span>
            <span className="text-slate-500 text-[11px]">Free Fire 1v1</span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="text-center py-4 border-t border-slate-800/60 text-xs text-slate-500">
        ClashRen Instant Matchmaking Engine • Built for WhatsApp Community Testing
      </footer>
    </div>
  );
};
