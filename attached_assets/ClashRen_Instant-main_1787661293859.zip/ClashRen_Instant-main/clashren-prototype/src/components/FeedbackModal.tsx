import React, { useState } from 'react';
import { FeedbackCategory, GuestProfile } from '../types';
import { MessageSquareHeart, Send, X, MessageCircle, Star, ShieldCheck } from 'lucide-react';

interface FeedbackModalProps {
  profile: GuestProfile;
  matchId?: string;
  onClose: () => void;
  onSubmitFeedback: (
    category: FeedbackCategory,
    description: string,
    screenshotUrl?: string,
    experienceRating?: 'Excellent' | 'Good' | 'Average' | 'Poor' | 'Very Poor'
  ) => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  profile,
  matchId,
  onClose,
  onSubmitFeedback,
}) => {
  const [category, setCategory] = useState<FeedbackCategory>('UI / UX Suggestion');
  const [description, setDescription] = useState('');
  const [rating, setRating] = useState<'Excellent' | 'Good' | 'Average' | 'Poor' | 'Very Poor'>('Excellent');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitInApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    onSubmitFeedback(category, description, undefined, rating);
    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  const handleOpenWhatsApp = () => {
    const text = `ClashRen Prototype Feedback\nGuest ID: ${profile.guestId}\nMatch ID: ${matchId || 'N/A'}\nRating: ${rating}\nCategory: ${category}\nFeedback: ${description || 'Testing ClashRen prototype.'}`;
    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 text-amber-400 font-bold text-lg">
          <MessageSquareHeart className="w-5 h-5 text-amber-400" />
          <span>Prototype Feedback</span>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Your feedback directly shapes the development of ClashRen. Send directly in-app or chat with us on WhatsApp.
        </p>

        {submitted ? (
          <div className="py-8 text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-white text-base">Feedback Submitted!</h4>
            <p className="text-xs text-slate-400">Thank you for helping us improve ClashRen.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmitInApp} className="space-y-4">
            {/* Category Dropdown */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as FeedbackCategory)}
                className="w-full bg-slate-950 text-slate-100 text-xs rounded-xl p-3 border border-slate-800 focus:border-amber-500 outline-none"
              >
                <option value="Bug Report">Bug Report</option>
                <option value="Matchmaking Issue">Matchmaking Issue</option>
                <option value="Room Creation Issue">Room Creation Issue</option>
                <option value="Verification Issue">Verification Issue</option>
                <option value="Wallet Issue">Wallet Issue</option>
                <option value="UI / UX Suggestion">UI / UX Suggestion</option>
                <option value="Feature Request">Feature Request</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Experience Rating */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Matchmaking Experience Rating
              </label>
              <div className="grid grid-cols-5 gap-1 text-center">
                {(['Excellent', 'Good', 'Average', 'Poor', 'Very Poor'] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRating(r)}
                    className={`py-2 rounded-xl text-[10px] font-bold border transition-all ${
                      rating === r
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            {/* Feedback Description */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Feedback Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Tell us what worked well or what we should fix…"
                rows={3}
                className="w-full bg-slate-950 text-slate-100 text-xs rounded-xl p-3 border border-slate-800 focus:border-amber-500 outline-none"
              />
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-1">
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-xs shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Submit In-App Feedback</span>
              </button>

              <button
                type="button"
                onClick={handleOpenWhatsApp}
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Feedback on WhatsApp</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
