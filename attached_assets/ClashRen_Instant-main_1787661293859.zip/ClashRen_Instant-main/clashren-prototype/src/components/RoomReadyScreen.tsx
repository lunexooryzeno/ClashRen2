import React, { useState, useEffect } from 'react';
import { Match, GuestProfile } from '../types';
import { Copy, Check, Clock, CheckCircle2, ShieldAlert, ExternalLink, Smartphone, Zap, Play } from 'lucide-react';

interface RoomReadyScreenProps {
  match: Match;
  profile: GuestProfile;
  onRoomTimerExpired: () => void;
  onMinimize?: () => void;
}

export const RoomReadyScreen: React.FC<RoomReadyScreenProps> = ({
  match,
  profile,
  onRoomTimerExpired,
  onMinimize,
}) => {
  const [copiedRoom, setCopiedRoom] = useState(false);
  const [copiedPass, setCopiedPass] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [autoLaunched, setAutoLaunched] = useState(false);

  const creds = match.roomCredentials;
  const ffUrl = creds?.openFfUrl || match.openFfUrl || "intent://#Intent;package=com.dts.freefireth;end";
  const hostPhoneStatus = match.latestPhoneStatus || 'Room Created';

  // Auto-launch Free Fire if setting is enabled when room credentials arrive
  useEffect(() => {
    if (!creds) return;
    const isAutoLaunchOn = localStorage.getItem('clashren_auto_launch') !== 'false';

    if (isAutoLaunchOn && !autoLaunched) {
      setAutoLaunched(true);
      try {
        // Attempt popup / new tab launch first
        const opened = window.open(ffUrl, '_blank');
        if (!opened || opened.closed || typeof opened.closed === 'undefined') {
          // If popup blocked or intent link, trigger anchor click fallback
          const link = document.createElement('a');
          link.href = ffUrl;
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      } catch (e) {
        console.warn('[ClashRen] Auto-launch trigger failed:', e);
      }
    }
  }, [creds, ffUrl, autoLaunched]);

  // Countdown join window timer (30 seconds)
  useEffect(() => {
    if (!creds) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const remaining = Math.max(0, Math.ceil((creds.joinWindowExpiresAt - now) / 1000));
      setTimeLeft(remaining);

      if (remaining <= 0) {
        clearInterval(interval);
        onRoomTimerExpired();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [creds, onRoomTimerExpired]);

  const copyToClipboard = (text: string, type: 'room' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'room') {
      setCopiedRoom(true);
      setTimeout(() => setCopiedRoom(false), 2000);
    } else {
      setCopiedPass(true);
      setTimeout(() => setCopiedPass(false), 2000);
    }
  };

  const handleOpenFreeFire = () => {
    try {
      window.open(ffUrl, '_blank');
    } catch (e) {
      console.warn('[ClashRen] Open Free Fire failed:', e);
    }
  };

  if (!creds) return null;

  return (
    <div className="max-w-md mx-auto p-4 space-y-5">
      {/* Title Header */}
      <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-900 border border-amber-500/40 rounded-2xl p-5 text-center shadow-xl relative overflow-hidden">
        {onMinimize && (
          <button
            onClick={onMinimize}
            className="absolute top-3 right-3 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer text-[11px] font-bold"
            title="Minimize Room Screen"
          >
            <span>Minimize</span>
          </button>
        )}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-bold mb-2">
          <Clock className="w-3.5 h-3.5 animate-pulse" />
          <span>ROOM CREATED • READY</span>
        </div>
        <h2 className="text-3xl font-black text-white tracking-tight">Room Ready</h2>
        <p className="text-xs text-slate-400 mt-1">
          Copy Room ID and Password to enter Free Fire custom room
        </p>
      </div>

      {/* Host Phone Status Display */}
      <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-4 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Host Phone Status
            </span>
            <span className="text-sm font-black text-emerald-400 block mt-0.5">
              {hostPhoneStatus}
            </span>
          </div>
        </div>
        <div className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
          LIVE MACRODROID
        </div>
      </div>

      {/* Countdown Timer */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
          Join Timer
        </span>
        <div className={`text-4xl font-mono font-black mt-1 ${timeLeft <= 10 ? 'text-red-400 animate-pulse' : 'text-amber-400'}`}>
          {timeLeft} seconds
        </div>
        <p className="text-[11px] text-slate-400 mt-1">
          Credentials will automatically close when timer reaches zero.
        </p>
      </div>

      {/* Room Credentials Cards */}
      <div className="space-y-3">
        {/* Room ID Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Room ID
            </span>
            <span className="text-3xl font-mono font-black text-white mt-0.5 block tracking-wider drop-shadow-sm">
              {creds.roomId}
            </span>
          </div>

          <button
            onClick={() => copyToClipboard(creds.roomId, 'room')}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-bold transition-all cursor-pointer active:scale-95"
          >
            {copiedRoom ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copiedRoom ? 'Copied' : 'Copy Room ID'}</span>
          </button>
        </div>

        {/* Room Password Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-md">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Password
            </span>
            <span className="text-3xl font-mono font-black text-amber-400 mt-0.5 block tracking-wider drop-shadow-sm">
              {creds.roomPassword}
            </span>
          </div>

          <button
            onClick={() => copyToClipboard(creds.roomPassword, 'pass')}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-bold transition-all cursor-pointer active:scale-95"
          >
            {copiedPass ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copiedPass ? 'Copied' : 'Copy Password'}</span>
          </button>
        </div>
      </div>

      {/* Auto Launch Feedback Banner */}
      {autoLaunched && (
        <div className="bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-2xl p-3.5 text-xs flex items-center justify-between">
          <span className="flex items-center gap-2 font-semibold">
            <Zap className="w-4 h-4 text-amber-400" />
            Attempted auto-launching Free Fire
          </span>
          <button
            onClick={handleOpenFreeFire}
            className="text-[11px] font-bold text-amber-400 hover:text-amber-300 underline cursor-pointer"
          >
            Launch Again
          </button>
        </div>
      )}

      {/* Open Free Fire Game Launcher Button */}
      <button
        onClick={handleOpenFreeFire}
        className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 text-slate-950 font-black text-sm shadow-lg shadow-orange-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
      >
        <Play className="w-4 h-4 fill-slate-950" />
        <span>OPEN FREE FIRE</span>
        <ExternalLink className="w-4 h-4 ml-1" />
      </button>

      {/* Instruction Guidance Box */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
        <div className="flex items-center gap-2 text-amber-400 font-bold">
          <Smartphone className="w-4 h-4" />
          <span>Important Player Notice</span>
        </div>
        <p className="text-slate-300 leading-relaxed text-[11px]">
          For the fastest experience, keep Free Fire running in the background before joining a match. If Free Fire is already running in the background, ClashRen will attempt to bring it to the foreground when the room is ready. If it is not running, ClashRen will attempt to launch Free Fire.
        </p>
        <p className="text-[10px] text-slate-400 italic pt-1.5 border-t border-slate-800">
          Note: You must manually enter the Room ID and Password after opening Free Fire. They remain visible on this screen.
        </p>
      </div>

      {/* Critical Security Warning Banner */}
      <div className="bg-red-950/40 border border-red-500/30 rounded-2xl p-4 flex items-start gap-3 text-xs">
        <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
        <div className="text-red-200/90 leading-relaxed">
          <span className="font-bold text-red-300 block mb-0.5">SECURITY WARNING:</span>
          Do not share these room credentials with anyone outside this match.
        </div>
      </div>
    </div>
  );
};
