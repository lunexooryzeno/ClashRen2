import React, { useState } from 'react';
import { Match, GuestProfile } from '../types';
import { AlertCircle, X, ShieldAlert, Upload } from 'lucide-react';

interface DisputeModalProps {
  match: Match;
  profile: GuestProfile;
  onClose: () => void;
  onSubmitDispute: (reason: string, screenshotUrl?: string) => void;
}

export const DisputeModal: React.FC<DisputeModalProps> = ({
  match,
  profile,
  onClose,
  onSubmitDispute,
}) => {
  const [reason, setReason] = useState('Opponent submitted fake victory screenshot');
  const [screenshotUrl, setScreenshotUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitDispute(reason, screenshotUrl);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5 text-red-400 font-bold text-lg">
          <AlertCircle className="w-5 h-5" />
          <span>Dispute Match Result</span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Disputing Match <span className="font-mono font-bold text-slate-100">{match.matchId}</span>. Submitting a dispute requires a <strong className="text-amber-400 font-bold">5 Coin verification deposit</strong>.
        </p>

        {/* 5 Coin Deposit Terms Box */}
        <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-4 text-xs text-amber-200/90 space-y-2">
          <div className="font-bold flex items-center gap-1.5 text-amber-300">
            <ShieldAlert className="w-4 h-4" />
            <span>5 Coin Verification Deposit Rules</span>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-300">
            If your dispute is correct, your <strong className="text-emerald-400 font-bold">5 Coin deposit will be fully refunded</strong> alongside your match victory reward. If your dispute is false, the deposit will be awarded to the verified winner as a penalty.
          </p>
          <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Your Current Coin Balance:</span>
            <span className={`font-mono font-bold ${profile.coins >= 5 ? 'text-emerald-400' : 'text-red-400'}`}>
              {profile.coins} Coins
            </span>
          </div>
        </div>

        {profile.coins < 5 && (
          <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs font-semibold">
            ⚠️ You need at least 5 Coins in your wallet to submit a dispute deposit. You currently have {profile.coins} Coins.
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Reason for Dispute
            </label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full bg-slate-950 text-slate-100 text-xs rounded-xl p-3 border border-slate-800 focus:border-amber-500 outline-none"
            >
              <option value="Opponent submitted fake victory screenshot">
                Opponent submitted fake victory screenshot
              </option>
              <option value="Opponent left match before room creation">
                Opponent left match before room creation
              </option>
              <option value="Wrong room credentials / Hacker in room">
                Wrong room credentials / Hacker in room
              </option>
              <option value="Other match rule violation">Other match rule violation</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Proof Screenshot / Video Link (Optional)
            </label>
            <input
              type="text"
              value={screenshotUrl}
              onChange={(e) => setScreenshotUrl(e.target.value)}
              placeholder="Paste image or video link showing final scoreboard"
              className="w-full bg-slate-950 text-slate-100 text-xs rounded-xl p-3 border border-slate-800 focus:border-amber-500 outline-none"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="w-1/2 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={profile.coins < 5}
              className="w-1/2 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-xs font-bold shadow-lg shadow-red-600/20 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Pay 5 Coins & Submit Dispute
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
