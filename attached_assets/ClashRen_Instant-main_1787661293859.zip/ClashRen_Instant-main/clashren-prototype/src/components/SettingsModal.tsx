import React, { useState } from 'react';
import { Settings, RefreshCw, X, Shield, Moon, Smartphone, HelpCircle, Zap } from 'lucide-react';

interface SettingsModalProps {
  guestId: string;
  onClose: () => void;
  onResetIdentity: () => void;
  onOpenFeedback: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  guestId,
  onClose,
  onResetIdentity,
  onOpenFeedback,
}) => {
  const [autoLaunch, setAutoLaunch] = useState<boolean>(() => {
    return localStorage.getItem('clashren_auto_launch') !== 'false';
  });

  const handleToggleAutoLaunch = () => {
    const nextVal = !autoLaunch;
    setAutoLaunch(nextVal);
    localStorage.setItem('clashren_auto_launch', nextVal ? 'true' : 'false');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 text-slate-200 font-bold text-lg">
          <Settings className="w-5 h-5 text-amber-400" />
          <span>ClashRen Settings</span>
        </div>

        <div className="space-y-3 text-xs">
          {/* Identity Box */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Guest ID</span>
            <span className="text-sm font-mono font-bold text-amber-400">{guestId}</span>
          </div>

          {/* Auto Launch Free Fire Setting */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-100 font-bold text-sm">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Auto Launch Free Fire</span>
              </div>
              <button
                type="button"
                onClick={handleToggleAutoLaunch}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                  autoLaunch ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-slate-950 font-bold text-[8px] flex items-center justify-center transition-transform ${
                    autoLaunch ? 'translate-x-6' : 'translate-x-1'
                  }`}
                >
                  {autoLaunch ? 'ON' : 'OFF'}
                </span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Automatically attempt to open Free Fire when room credentials are received.
            </p>
          </div>

          {/* Prototype Version */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300">
              <Smartphone className="w-4 h-4 text-amber-400" />
              <span>Prototype Version</span>
            </div>
            <span className="font-mono text-amber-400 font-semibold">v1.1.0-macro</span>
          </div>

          {/* Theme Indicator */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300">
              <Moon className="w-4 h-4 text-amber-400" />
              <span>Appearance</span>
            </div>
            <span className="text-slate-400">Glassmorphism Dark Theme</span>
          </div>

          {/* Reset Identity Option */}
          <div className="pt-2">
            <button
              onClick={onResetIdentity}
              className="w-full py-3 px-4 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset Local Guest Identity (New Guest ID)</span>
            </button>
          </div>

          {/* Help & Feedback */}
          <button
            onClick={() => {
              onClose();
              onOpenFeedback();
            }}
            className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span>Send Feedback & Support</span>
          </button>
        </div>
      </div>
    </div>
  );
};
