import React, { useState } from 'react';
import { GameCategory, GameMode, GameName, EntryCardOption, GuestProfile } from '../types';
import { ENTRY_CARDS } from '../data/mockData';
import { Copy, Check, Zap, Flame, Trophy, Coins, ChevronDown, User, ShieldCheck } from 'lucide-react';

interface HomeScreenProps {
  profile: GuestProfile;
  onFindOpponent: (category: GameCategory, mode: GameMode, game: GameName, entryCard: EntryCardOption) => void;
  onOpenFeedback: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  profile,
  onFindOpponent,
  onOpenFeedback,
}) => {
  const [category, setCategory] = useState<GameCategory>('Clash Squad');
  const [mode, setMode] = useState<GameMode>('Solo');
  const [game, setGame] = useState<GameName>('Clash Squad Normal');
  const [selectedCardId, setSelectedCardId] = useState<string>(ENTRY_CARDS[0].id);
  const [copied, setCopied] = useState(false);

  const selectedCard = ENTRY_CARDS.find((c) => c.id === selectedCardId) || ENTRY_CARDS[0];

  const handleCopyGuestId = () => {
    navigator.clipboard.writeText(profile.guestId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFindMatch = () => {
    onFindOpponent(category, mode, game, selectedCard);
  };

  return (
    <div className="max-w-xl mx-auto p-4 space-y-6 pb-20">
      {/* Guest Identity Overview Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
            <User className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-white text-base">{profile.nickname}</h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                GUEST
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">ID: {profile.guestId}</p>
          </div>
        </div>

        <button
          onClick={handleCopyGuestId}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-all cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5 text-amber-400" />
              <span>Copy Guest ID</span>
            </>
          )}
        </button>
      </div>

      {/* Match Selection Dropdowns */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            Match Settings
          </h3>
          <span className="text-[11px] text-amber-400/90 font-medium bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
            Free Fire 1v1
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Dropdown 1: Category */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Category
            </label>
            <div className="relative">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as GameCategory)}
                className="w-full bg-slate-950 text-slate-100 text-xs font-medium rounded-xl px-3 py-2.5 border border-slate-800 focus:border-amber-500 outline-none appearance-none cursor-pointer"
              >
                <option value="Clash Squad">Clash Squad</option>
                <option value="Battle Royale">Battle Royale</option>
              </select>
              <ChevronDown className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Dropdown 2: Mode */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Mode
            </label>
            <div className="relative">
              <select
                value={mode}
                onChange={(e) => setMode(e.target.value as GameMode)}
                className="w-full bg-slate-950 text-slate-100 text-xs font-medium rounded-xl px-3 py-2.5 border border-slate-800 focus:border-amber-500 outline-none appearance-none cursor-pointer"
              >
                <option value="Solo">Solo (1v1)</option>
                <option value="Duo">Duo (2v2)</option>
                <option value="Squad">Squad (4v4)</option>
              </select>
              <ChevronDown className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Dropdown 3: Game */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Game
            </label>
            <div className="relative">
              <select
                value={game}
                onChange={(e) => setGame(e.target.value as GameName)}
                className="w-full bg-slate-950 text-amber-300 font-semibold text-xs rounded-xl px-3 py-2.5 border border-amber-500/30 focus:border-amber-500 outline-none appearance-none cursor-pointer"
              >
                <option value="Clash Squad Normal">Clash Squad Normal</option>
              </select>
              <ChevronDown className="w-4 h-4 text-amber-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Entry Fee Cards Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Coins className="w-4 h-4 text-amber-400" />
            Select Entry Fee & Prize
          </label>
          <span className="text-[11px] text-slate-400">1v1 Instant Match</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {ENTRY_CARDS.map((card) => {
            const isSelected = card.id === selectedCardId;
            const isFree = card.entryFee === 0;
            return (
              <button
                key={card.id}
                onClick={() => setSelectedCardId(card.id)}
                className={`relative p-3.5 sm:p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-gradient-to-br from-amber-500/20 via-slate-900 to-slate-900 border-amber-500 shadow-lg shadow-amber-500/10 scale-[1.02]'
                    : isFree
                    ? 'bg-slate-900/90 border-emerald-500/40 hover:border-emerald-500/80 hover:bg-slate-900'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                {isFree && (
                  <span className="absolute -top-2 left-3 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[9px] uppercase tracking-wider shadow-sm">
                    Free Entry
                  </span>
                )}

                {isSelected && (
                  <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}

                <div className={isFree ? 'pt-1' : ''}>
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider mb-1">
                    Entry Fee
                  </div>
                  <div className="text-xl font-black text-white flex items-center gap-1">
                    {card.entryFee === 0 ? (
                      <span className="text-emerald-400 font-extrabold">0 Coins</span>
                    ) : (
                      <>
                        {card.entryFee} <span className="text-xs font-normal text-amber-400">Coins</span>
                      </>
                    )}
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Win Prize</span>
                  <span className="text-sm font-bold text-amber-400 flex items-center gap-1">
                    <Trophy className="w-3.5 h-3.5" />
                    {card.prize} Coins
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary Action: Find Opponent */}
      <div className="pt-2">
        <button
          onClick={handleFindMatch}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-base shadow-xl shadow-orange-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2.5 cursor-pointer"
        >
          <Zap className="w-5 h-5 fill-slate-950" />
          <span>FIND OPPONENT ({selectedCard.entryFee} COINS)</span>
        </button>
      </div>

    </div>
  );
};
