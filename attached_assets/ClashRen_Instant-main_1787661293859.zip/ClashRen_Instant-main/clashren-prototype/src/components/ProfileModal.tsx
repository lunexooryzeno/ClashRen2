import React, { useState } from 'react';
import { GuestProfile } from '../types';
import { User, Copy, Check, ShieldCheck, Coins, Plus, History, X } from 'lucide-react';

interface ProfileModalProps {
  profile: GuestProfile;
  onClose: () => void;
  onOpenWallet: () => void;
  onOpenAddCoins: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  profile,
  onClose,
  onOpenWallet,
  onOpenAddCoins,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyGuestId = () => {
    navigator.clipboard.writeText(profile.guestId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const totalMatches = profile.matchesPlayed || profile.wins + profile.losses;
  const winRate = totalMatches > 0 ? Math.round((profile.wins / totalMatches) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative my-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Profile Card Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-orange-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto text-2xl font-bold">
            <User className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-extrabold text-white">{profile.nickname}</h3>

          <div className="inline-flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
            <span className="font-mono text-xs text-amber-400 font-bold">{profile.guestId}</span>
            <button
              onClick={handleCopyGuestId}
              className="text-slate-400 hover:text-amber-400 transition-colors p-1 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Wallet Overview Section in Profile */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/25 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Coin Wallet
              </span>
            </div>
            <span className="font-mono text-lg font-black text-amber-400">
              {profile.coins} <span className="text-xs font-normal text-slate-400">Coins</span>
            </span>
          </div>

          <div className="flex gap-2 pt-1">
            <button
              onClick={() => {
                onClose();
                onOpenAddCoins();
              }}
              className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>Add Coins</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenWallet();
              }}
              className="flex-1 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1"
            >
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span>View Transactions</span>
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Matches</span>
            <span className="text-lg font-mono font-bold text-white mt-1 block">{totalMatches}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Wins</span>
            <span className="text-lg font-mono font-bold text-amber-400 mt-1 block">{profile.wins}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Win Rate</span>
            <span className="text-lg font-mono font-bold text-emerald-400 mt-1 block">{winRate}%</span>
          </div>
        </div>

        {/* Trust Score Card */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <span className="font-bold text-slate-200 block">ClashRen Trust Score</span>
              <span className="text-[11px] text-slate-400">Maintained through fair gameplay</span>
            </div>
          </div>
          <span className="text-lg font-mono font-black text-emerald-400">{profile.trustScore}/100</span>
        </div>
      </div>
    </div>
  );
};
