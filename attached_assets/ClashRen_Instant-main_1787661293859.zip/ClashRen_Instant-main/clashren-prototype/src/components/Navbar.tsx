import React from 'react';
import { Coins, Plus, Users, User, Settings, ShieldAlert, MessageSquareHeart } from 'lucide-react';

interface NavbarProps {
  coins: number;
  activePlayers: number;
  guestId: string;
  onOpenWallet: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onOpenAdmin: () => void;
  onOpenFeedback: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  coins,
  activePlayers,
  guestId,
  onOpenWallet,
  onOpenProfile,
  onOpenSettings,
  onOpenAdmin,
  onOpenFeedback,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Left Side: Available Coins & Online Count */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenWallet}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
          >
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Coins className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <p className="text-[10px] uppercase tracking-wider text-slate-400 font-medium">Available Coins</p>
              <p className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                {coins} <span className="text-xs text-amber-400 font-normal">Coins</span>
              </p>
            </div>
          </button>

          {/* Online Players Indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            <span className="text-slate-400 text-[11px] font-medium hidden sm:inline">Online:</span>
            <span className="font-bold text-emerald-400">{activePlayers}</span>
            <span className="text-[10px] text-slate-400 font-medium hidden sm:inline">Players</span>
          </div>
        </div>

        {/* Right Side Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Feedback Icon */}
          <button
            onClick={onOpenFeedback}
            title="Send Feedback"
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-amber-500/30 transition-all cursor-pointer"
          >
            <MessageSquareHeart className="w-4 h-4 text-amber-400" />
          </button>

          {/* Profile Icon */}
          <button
            onClick={onOpenProfile}
            title="Guest Profile"
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-amber-500/30 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <User className="w-4 h-4 text-slate-300" />
            <span className="hidden md:inline text-xs font-medium text-slate-300 truncate max-w-[90px]">
              {guestId ? (guestId.split('-')[1] || 'Guest') : 'Guest'}
            </span>
          </button>

          {/* Admin Panel Toggle */}
          <button
            onClick={onOpenAdmin}
            title="Admin & Worker Control Panel"
            className="p-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition-all cursor-pointer"
          >
            <ShieldAlert className="w-4 h-4" />
          </button>

          {/* Settings Icon */}
          <button
            onClick={onOpenSettings}
            title="Settings"
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 border border-slate-800 transition-all cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
