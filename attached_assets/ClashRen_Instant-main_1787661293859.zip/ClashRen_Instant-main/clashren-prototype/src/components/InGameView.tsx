import React, { useState, useEffect } from 'react';
import { Match, GuestProfile } from '../types';
import {
  Trophy,
  Upload,
  ShieldCheck,
  AlertCircle,
  Clock,
  CheckCircle2,
  MessageSquare,
  XCircle,
  Image as ImageIcon,
  Check,
  Loader2,
  Flame,
  ShieldAlert,
  ChevronLeft,
  Minimize2,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react';

interface InGameViewProps {
  match: Match;
  profile: GuestProfile;
  onSubmitVictoryScreenshot: (screenshotUrl: string, screenshotData?: string) => void;
  onAcceptResult: () => void;
  onOpenDisputeModal: () => void;
  onOpenFeedback: () => void;
  onMinimize?: () => void;
  onCloseMatch?: () => void;
}

export const InGameView: React.FC<InGameViewProps> = ({
  match,
  profile,
  onSubmitVictoryScreenshot,
  onAcceptResult,
  onOpenDisputeModal,
  onOpenFeedback,
  onMinimize,
  onCloseMatch,
}) => {
  const [selectedRoleChoice, setSelectedRoleChoice] = useState<'WINNER' | 'LOSER' | null>(null);
  const [selectedRole, setSelectedRole] = useState<'NONE' | 'WINNER' | 'LOSER'>('NONE');
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [pendingTimerLeft, setPendingTimerLeft] = useState<number>(1800); // 30 mins

  const isPlayerA = match.playerA.guestId === profile.guestId;
  const opponent = isPlayerA ? match.playerB : match.playerA;
  const isClaimant = match.claimedWinnerId === profile.guestId;

  // Countdown timer for 30-min pending reward window
  useEffect(() => {
    if (match.status === 'PENDING_VERIFICATION' && match.pendingRewardExpiresAt) {
      const interval = setInterval(() => {
        const remaining = Math.max(0, Math.ceil((match.pendingRewardExpiresAt! - Date.now()) / 1000));
        setPendingTimerLeft(remaining);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [match]);

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainingSecs = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const handleSelectImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setSelectedImage('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80');
    }
  };

  const handleStartSubmit = () => {
    const imgData = selectedImage || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80';
    setIsVerifying(true);
    onSubmitVictoryScreenshot(imgData, imgData);
    setTimeout(() => {
      setIsVerifying(false);
    }, 1200);
  };

  const isResultVerificationActive = (match.status === 'IN_GAME' || match.status === 'ROOM_READY') && !match.claimedWinnerId;

  return (
    <div className="max-w-md mx-auto p-4 space-y-5">
      {/* Top Header Banner */}
      <div className="bg-slate-900/90 border border-slate-800 backdrop-blur-md rounded-2xl p-5 text-center shadow-xl relative">
        <div className="absolute top-3 right-3 flex items-center gap-2">
          {onMinimize && (
            <button
              onClick={onMinimize}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer flex items-center gap-1 text-[11px] font-bold"
              title="Minimize result verification"
            >
              <Minimize2 className="w-3.5 h-3.5" />
              <span>Minimize</span>
            </button>
          )}
          {onCloseMatch && (
            <button
              onClick={onCloseMatch}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer text-[11px] font-bold flex items-center gap-1"
              title="Return to Home Screen"
            >
              <span>Home</span>
            </button>
          )}
        </div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-xs font-bold mb-2">
          <Flame className="w-3.5 h-3.5" />
          <span>MATCH ID: {match.matchId}</span>
        </div>
        <h2 className="text-2xl font-black text-white tracking-tight">Free Fire 1v1 Match</h2>
        <div className="flex items-center justify-center gap-2 text-xs text-slate-400 mt-1">
          <span>{profile.nickname}</span>
          <span className="text-amber-400 font-bold">VS</span>
          <span>{opponent.nickname}</span>
        </div>
      </div>

      {/* STATE 1.5: RESULT_VERIFICATION - AWAITING VERIFICATION */}
      {match.status === 'RESULT_VERIFICATION' && isClaimant && (
        <div className="bg-slate-900/90 border border-amber-500/40 backdrop-blur-md rounded-3xl p-6 space-y-5 shadow-2xl text-center">
          <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping" />
            <div className="relative w-14 h-14 rounded-full bg-slate-950 border border-amber-500/50 text-amber-400 flex items-center justify-center shadow-lg">
              <Loader2 className="w-7 h-7 animate-spin" />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-bold uppercase tracking-wider">
              <span>Verification In Progress</span>
            </div>
            <h3 className="text-2xl font-black text-white tracking-tight">Result Verification In Progress</h3>
            <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
              Your victory screenshot has been submitted and is currently being verified. This usually takes just a few seconds.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left space-y-2 text-xs">
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Match ID:</span>
              <span className="font-mono font-bold text-amber-400">{match.matchId}</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Verification Status:</span>
              <span className="font-mono font-bold text-amber-400 flex items-center gap-1.5">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-400" />
                <span>Verifying Result...</span>
              </span>
            </div>
          </div>

          <div className="space-y-2 pt-1">
            {onMinimize && (
              <button
                onClick={onMinimize}
                className="w-full py-3.5 px-5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Minimize2 className="w-4 h-4 text-amber-400" />
                <span>Minimize Screen</span>
              </button>
            )}
            <p className="text-[10px] text-slate-500">
              You may minimize this screen. The result will automatically update once verification is complete.
            </p>
          </div>
        </div>
      )}

      {match.status === 'RESULT_VERIFICATION' && !isClaimant && (
        <div className="bg-slate-900/90 border border-slate-800 backdrop-blur-md rounded-3xl p-6 space-y-5 shadow-2xl text-center">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto">
            <Clock className="w-7 h-7" />
          </div>

          <div className="space-y-1.5">
            <h3 className="text-2xl font-black text-white tracking-tight">Opponent Claimed Victory</h3>
            <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
              {opponent.nickname} has submitted a victory screenshot for verification.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 pt-2">
            <button
              onClick={onOpenDisputeModal}
              className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xl shadow-red-600/20"
            >
              <AlertCircle className="w-4 h-4" />
              <span>Submit Dispute (5 Coin Deposit)</span>
            </button>

            {onMinimize && (
              <button
                onClick={onMinimize}
                className="w-full py-3.5 px-5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Minimize2 className="w-4 h-4 text-amber-400" />
                <span>Minimize Screen</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* STATE 1: SELECTION MENU (Yes I Am the Winner / No I Lost / Minimize) */}
      {isResultVerificationActive && selectedRole === 'NONE' && (
        <div className="bg-slate-900/90 border border-slate-800 backdrop-blur-md rounded-3xl p-6 space-y-6 shadow-2xl">
          <div className="text-center space-y-1.5">
            <h3 className="text-2xl font-black text-white tracking-tight">Match Result Verification</h3>
            <p className="text-xs text-slate-300">Select the result of your match.</p>
          </div>

          <div className="grid grid-cols-1 gap-3.5 pt-2">
            {/* Button 1: Yes, I Am the Winner */}
            <button
              onClick={() => setSelectedRoleChoice('WINNER')}
              className={`w-full p-4 rounded-2xl border text-left transition-all cursor-pointer group shadow-xl active:scale-[0.98] ${
                selectedRoleChoice === 'WINNER'
                  ? 'bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-900 border-emerald-400 ring-2 ring-emerald-500/40'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div className={`p-3 rounded-2xl border ${selectedRoleChoice === 'WINNER' ? 'bg-emerald-500/30 text-emerald-300 border-emerald-400' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'}`}>
                    <Trophy className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-emerald-400">Yes, I Am the Winner</h4>
                    <p className="text-xs text-slate-400 mt-0.5">I won this 1v1 Free Fire match (Booyah)</p>
                  </div>
                </div>
                <div className={`w-7 h-7 rounded-full flex items-center justify-center border ${selectedRoleChoice === 'WINNER' ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'}`}>
                  <Check className="w-4 h-4" />
                </div>
              </div>
            </button>

            {/* Button 2: No, I Lost */}
            <button
              onClick={() => setSelectedRoleChoice('LOSER')}
              className={`w-full p-4 rounded-2xl border text-left transition-all cursor-pointer group shadow-xl active:scale-[0.98] ${
                selectedRoleChoice === 'LOSER'
                  ? 'bg-gradient-to-r from-rose-950/90 via-slate-900 to-slate-900 border-rose-400 ring-2 ring-rose-500/40'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div className={`p-3 rounded-2xl border ${selectedRoleChoice === 'LOSER' ? 'bg-rose-500/30 text-rose-300 border-rose-400' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                    <XCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-slate-200">No, I Lost</h4>
                    <p className="text-xs text-slate-400 mt-0.5">I lost this match or resigned</p>
                  </div>
                </div>
                {selectedRoleChoice === 'LOSER' && (
                  <div className="w-7 h-7 rounded-full bg-rose-500 text-slate-950 flex items-center justify-center border border-rose-400 font-bold">
                    <Check className="w-4 h-4" />
                  </div>
                )}
              </div>
            </button>

            {/* Button 2.5: Confirm Selection (Above Minimize Screen, Below No I Lost) */}
            <button
              disabled={!selectedRoleChoice}
              onClick={() => {
                if (selectedRoleChoice) {
                  setSelectedRole(selectedRoleChoice);
                }
              }}
              className={`w-full py-4 px-5 rounded-2xl font-black text-xs shadow-xl transition-all flex items-center justify-center gap-2 uppercase tracking-wide ${
                selectedRoleChoice === 'WINNER'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 hover:from-emerald-400 hover:to-teal-400 cursor-pointer shadow-emerald-500/20 active:scale-[0.98]'
                  : selectedRoleChoice === 'LOSER'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:from-amber-400 hover:to-orange-400 cursor-pointer shadow-amber-500/20 active:scale-[0.98]'
                  : 'bg-slate-800/80 text-slate-500 border border-slate-700/60 cursor-not-allowed'
              }`}
            >
              <CheckCircle2 className="w-4.5 h-4.5" />
              <span>
                {selectedRoleChoice
                  ? `Confirm Selection (${selectedRoleChoice === 'WINNER' ? 'I Am Winner' : 'I Lost'})`
                  : 'Select Result Above to Confirm'}
              </span>
            </button>

            {/* Button 3: Minimize */}
            {onMinimize && (
              <button
                onClick={onMinimize}
                className="w-full py-3.5 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Minimize2 className="w-4 h-4 text-amber-400" />
                <span>Minimize Screen</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* STATE 2: WINNER FLOW - UPLOAD SCREENSHOT & NOTICE */}
      {isResultVerificationActive && selectedRole === 'WINNER' && (
        <div className="bg-slate-900/90 border border-slate-800 backdrop-blur-md rounded-3xl p-6 space-y-5 shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <button
              onClick={() => setSelectedRole('NONE')}
              disabled={isVerifying}
              className="text-xs font-bold text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20">
              OFFICIAL VERIFICATION
            </span>
          </div>

          <div className="space-y-1">
            <h3 className="text-2xl font-black text-white tracking-tight">Upload Official Free Fire Screenshot</h3>
            <p className="text-xs text-slate-400">Provide official game export for phone OCR validation.</p>
          </div>

          {/* Security Notice */}
          <div className="bg-red-950/40 border border-red-500/30 rounded-2xl p-4 flex items-start gap-3 text-xs">
            <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <p className="text-red-200/90 text-[11px] leading-relaxed">
              <strong>Warning:</strong> Uploading a fake or edited result may result in account suspension and cancellation of rewards.
            </p>
          </div>

          {/* Upload Controls */}
          {!isVerifying ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  Choose Official Screenshot
                </label>
                <div className="relative">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleSelectImage}
                    id="ff-screenshot-input"
                    className="hidden"
                  />
                  <label
                    htmlFor="ff-screenshot-input"
                    className="w-full py-4 px-5 rounded-2xl bg-slate-950 hover:bg-slate-800 border-2 border-dashed border-amber-500/40 hover:border-amber-400 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    <ImageIcon className="w-4 h-4 text-amber-400" />
                    <span>{selectedImage ? 'Change Selected Screenshot' : 'Choose Official Screenshot'}</span>
                  </label>
                </div>
              </div>

              {selectedImage && (
                <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-slate-950 max-h-48 flex items-center justify-center p-2">
                  <img src={selectedImage} alt="Selected Screenshot" className="max-h-44 object-contain rounded-xl" />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                {onMinimize && (
                  <button
                    onClick={onMinimize}
                    className="py-3.5 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Minimize2 className="w-4 h-4 text-amber-400" />
                    <span>Minimize</span>
                  </button>
                )}
                <button
                  onClick={handleStartSubmit}
                  className={`${onMinimize ? 'w-full' : 'col-span-2'} py-3.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-amber-500 hover:from-emerald-400 hover:to-amber-400 text-slate-950 font-black text-xs shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2`}
                >
                  <Upload className="w-4 h-4" />
                  <span>Submit Result</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 border border-amber-500/40 rounded-2xl p-5 space-y-3 text-center">
              <Loader2 className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
              <h4 className="text-sm font-black text-amber-300">Submitting to Verification Queue...</h4>
              <p className="text-[11px] text-slate-400">MacroDroid verification worker processing result screenshot</p>
            </div>
          )}
        </div>
      )}

      {/* STATE 3: LOSER FLOW - WAITING & DISPUTE OPTION */}
      {isResultVerificationActive && selectedRole === 'LOSER' && (
        <div className="bg-slate-900/90 border border-slate-800 backdrop-blur-md rounded-3xl p-6 space-y-5 shadow-2xl text-center">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto">
            <Clock className="w-7 h-7" />
          </div>

          <div className="space-y-1.5">
            <h3 className="text-2xl font-black text-white tracking-tight">Waiting for Winner Submission</h3>
            <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
              Your opponent may submit an official Free Fire screenshot. If you believe the winner is incorrect, you may submit a dispute.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 pt-2">
            <button
              onClick={onOpenDisputeModal}
              className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xl shadow-red-600/20"
            >
              <AlertCircle className="w-4 h-4" />
              <span>Submit Dispute</span>
            </button>

            {onMinimize && (
              <button
                onClick={onMinimize}
                className="w-full py-3.5 px-5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Minimize2 className="w-4 h-4 text-amber-400" />
                <span>Minimize</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* STATE 4: PENDING VERIFICATION - 20 COINS CREDITED (PENDING VERIFICATION) */}
      {match.status === 'PENDING_VERIFICATION' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-900 border border-emerald-500/40 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black text-emerald-400 tracking-tight">
                  20 Coins Credited (Pending Verification)
                </h3>
                <span className="text-[11px] font-mono font-bold text-amber-400 block mt-0.5">
                  VERIFICATION SUCCESSFUL
                </span>
              </div>
            </div>

            {/* MacroDroid Response Message */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-xs space-y-1">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold block">
                Verification Worker Output:
              </span>
              <p className="text-emerald-400 font-mono font-semibold">
                {match.verificationMessage || 'Verification Successful: Official Free Fire winner screen detected. Confidence: 97%'}
              </p>
            </div>

            {/* Temporary Screenshot Link */}
            {match.screenshotUrl && (
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-xs flex items-center justify-between">
                <span className="text-slate-400 text-[11px]">Temporary Screenshot:</span>
                <a
                  href={`https://temp.clashren.com/upload/${match.matchId}.png`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-amber-400 hover:underline text-[11px] font-mono flex items-center gap-1"
                >
                  <span>https://temp.clashren.com/upload/...</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>

          {/* 30-Minute Pending Timer */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-center space-y-2">
            <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 font-semibold">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>30-Minute Pending Reward Timer</span>
            </div>
            <div className="text-3xl font-mono font-black text-amber-400">
              {formatTimer(pendingTimerLeft)}
            </div>
            <p className="text-[11px] text-slate-400">
              Coins will automatically unlock after 30 minutes if no dispute is filed.
            </p>
          </div>

          {!isClaimant && (
            <button
              onClick={onOpenDisputeModal}
              className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xl"
            >
              <AlertCircle className="w-4 h-4" />
              <span>Submit Dispute (5 Coin Deposit)</span>
            </button>
          )}

          {onMinimize && (
            <button
              onClick={onMinimize}
              className="w-full py-3.5 px-5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Minimize2 className="w-4 h-4 text-amber-400" />
              <span>Minimize Screen</span>
            </button>
          )}
        </div>
      )}

      {/* STATE 5: DISPUTED */}
      {match.status === 'DISPUTED' && (
        <div className="bg-slate-900/90 border border-red-500/40 rounded-3xl p-6 space-y-4 text-center shadow-2xl">
          <div className="w-14 h-14 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto border border-red-500/30">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h3 className="text-xl font-black text-white">Match Disputed</h3>
          <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
            This match is currently under review by the ClashRen admin team. Pending rewards have been locked until the dispute is resolved.
          </p>
          {onMinimize && (
            <button
              onClick={onMinimize}
              className="w-full py-3.5 px-5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              <Minimize2 className="w-4 h-4 text-amber-400" />
              <span>Minimize Screen</span>
            </button>
          )}
        </div>
      )}

      {/* STATE 6: FINALIZED */}
      {match.status === 'FINALIZED' && (
        <div className="bg-slate-900/90 border border-emerald-500/30 backdrop-blur-md rounded-3xl p-6 text-center space-y-4 shadow-2xl">
          <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
            <Trophy className="w-7 h-7" />
          </div>
          <h3 className="text-2xl font-black text-white">Match Finalized</h3>
          <p className="text-xs text-slate-300">
            Winner: <span className="font-bold text-amber-400">{match.finalWinnerId}</span>
          </p>
          <p className="text-[11px] text-slate-400">Payout of {match.prize} Coins has been unlocked and finalized.</p>
          
          {onCloseMatch && (
            <button
              onClick={onCloseMatch}
              className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-xl transition-all cursor-pointer"
            >
              Back to Home Screen
            </button>
          )}
        </div>
      )}

      {/* STATE 7: CANCELLED */}
      {match.status === 'CANCELLED' && (
        <div className="bg-slate-900/90 border border-slate-700 backdrop-blur-md rounded-3xl p-6 text-center space-y-4 shadow-2xl">
          <div className="w-14 h-14 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/20">
            <XCircle className="w-7 h-7 text-amber-400" />
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-white">Match Cancelled</h3>
            <p className="text-xs text-slate-300">
              This match was cancelled. Any deducted entry fees have been refunded to your wallet balance.
            </p>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-xs space-y-1 text-left">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold block">
              Cancellation Reason:
            </span>
            <p className="text-amber-400 font-mono font-semibold">
              {match.cancelReason || 'Match cancelled due to host room setup timeout or system check.'}
            </p>
          </div>
          
          {onCloseMatch && (
            <button
              onClick={onCloseMatch}
              className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-xl transition-all cursor-pointer font-bold"
            >
              Back to Home Screen
            </button>
          )}
        </div>
      )}

      {/* Send Feedback Footer */}
      <button
        onClick={onOpenFeedback}
        className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-semibold transition-all cursor-pointer flex items-center justify-center gap-2"
      >
        <MessageSquare className="w-4 h-4 text-amber-400" />
        <span>How was your match experience? Send Feedback</span>
      </button>
    </div>
  );
};
