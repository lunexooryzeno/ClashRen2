import React, { useState } from 'react';
import {
  Coins,
  Copy,
  Check,
  X,
  ExternalLink,
  ShieldCheck,
  MessageCircle,
  QrCode,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface AddCoinsModalProps {
  guestId: string;
  currentCoins: number;
  onClose: () => void;
  adminWhatsAppNumber?: string;
}

export const AddCoinsModal: React.FC<AddCoinsModalProps> = ({
  guestId,
  currentCoins,
  onClose,
  adminWhatsAppNumber = '919876543210',
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [isCopied, setIsCopied] = useState(false);

  const activeAmount = customAmount ? Math.max(1, parseInt(customAmount, 10) || 0) : selectedAmount;

  const handleCopyGuestId = () => {
    navigator.clipboard.writeText(guestId);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleAskAdmin = () => {
    const textMessage = `Hello Admin,

I want to add coins to my ClashRen account.

Guest ID: ${guestId}
Amount I want to add: ${activeAmount} Coins (₹${activeAmount})

Please share payment details (UPI / QR Code).`;

    const encodedText = encodeURIComponent(textMessage);
    const whatsappUrl = `https://wa.me/${adminWhatsAppNumber}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800/80 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
            <Coins className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Add Coins</h3>
            <p className="text-xs text-amber-400 font-semibold flex items-center gap-1">
              <span>Rate: 1 Coin = ₹1</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400 font-normal">Balance: {currentCoins} Coins</span>
            </p>
          </div>
        </div>

        {/* Prototype Info Alert */}
        <div className="bg-amber-500/10 border border-amber-500/25 rounded-2xl p-3.5 space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Manual Admin Approval Prototype</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            For this prototype, coins are added manually by the ClashRen admin after payment verification.
          </p>
        </div>

        {/* Guest ID Box */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Your Player Guest ID
          </span>
          <div className="flex items-center justify-between gap-2">
            <span className="font-mono text-base font-black text-amber-400 tracking-wider">
              {guestId}
            </span>
            <button
              onClick={handleCopyGuestId}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-500/50 text-slate-200 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Guest ID</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Select Coin Amount */}
        <div className="space-y-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Select Coin Amount (1 Coin = ₹1)
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[100, 200, 500, 1000].map((amt) => (
              <button
                key={amt}
                onClick={() => {
                  setSelectedAmount(amt);
                  setCustomAmount('');
                }}
                className={`py-2.5 px-2 rounded-xl border text-xs font-bold transition-all cursor-pointer flex flex-col items-center ${
                  activeAmount === amt && !customAmount
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md scale-[1.02]'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                <span>{amt} Coins</span>
                <span className="text-[10px] font-mono opacity-80">₹{amt}</span>
              </button>
            ))}
          </div>

          <div className="pt-1">
            <input
              type="number"
              min="10"
              placeholder="Or enter custom coin amount (e.g. 250)"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-500/50 font-mono"
            />
          </div>
        </div>

        {/* Summary Card */}
        <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">Total Amount to Pay:</span>
          <span className="font-mono font-black text-emerald-400 text-sm">
            ₹{activeAmount} <span className="text-slate-400 font-normal text-xs">({activeAmount} Coins)</span>
          </span>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleAskAdmin}
            className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/10 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4 fill-slate-950" />
            <span>Ask Admin to Add Coins (WhatsApp)</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </button>

          <button
            onClick={handleCopyGuestId}
            className="w-full py-3 rounded-2xl bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Copy className="w-3.5 h-3.5 text-amber-400" />
            <span>{isCopied ? 'Guest ID Copied!' : 'Copy Guest ID Only'}</span>
          </button>
        </div>

        {/* Steps footer */}
        <div className="text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800/60 space-y-1">
          <span className="font-bold text-slate-300 block text-[10px] uppercase tracking-wider">How Manual Verification Works:</span>
          <ol className="list-decimal list-inside space-y-0.5 text-[10px] text-slate-400">
            <li>Press Ask Admin to send your Guest ID via WhatsApp.</li>
            <li>Admin shares UPI / QR Code for direct payment.</li>
            <li>Once payment is verified, coins credit to your wallet instantly.</li>
          </ol>
        </div>
      </div>
    </div>
  );
};
