import React, { useState } from 'react';
import { UserCheck, ShieldCheck, Zap, ArrowLeft, Lock } from 'lucide-react';

interface GuestOnboardingProps {
  onContinueAsGuest: () => void;
  onBack: () => void;
  isLoading: boolean;
}

export const GuestOnboarding: React.FC<GuestOnboardingProps> = ({
  onContinueAsGuest,
  onBack,
  isLoading,
}) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 md:p-8 relative">
      {/* Top Bar */}
      <header className="max-w-md w-full mx-auto flex items-center justify-between py-2">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <span className="text-xs font-semibold text-amber-400/90 tracking-wide">
          STEP 2 OF 2
        </span>
      </header>

      {/* Main Card */}
      <main className="max-w-md w-full mx-auto my-auto py-6 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-orange-500/20 border border-amber-500/30 flex items-center justify-center mx-auto mb-5 text-amber-400">
          <UserCheck className="w-6 h-6" />
        </div>

        <h2 className="text-2xl font-bold text-center text-white mb-2">
          Continue as Guest
        </h2>

        <p className="text-slate-400 text-sm text-center mb-6 leading-relaxed">
          Play the ClashRen prototype instantly without creating an account.
        </p>

        {/* Zero Personal Info Notice */}
        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800/80 mb-6 space-y-2.5 text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold">
            <Lock className="w-3.5 h-3.5" />
            <span>Zero Data Collection</span>
          </div>
          <p className="text-slate-400">
            No registration, phone number, email, OTP, or password required. An automatic Guest ID is assigned instantly to track matchmaking.
          </p>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={onContinueAsGuest}
          disabled={isLoading}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-base shadow-lg shadow-amber-500/10 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <Zap className="w-5 h-5 fill-slate-950" />
              <span>Continue as Guest</span>
            </>
          )}
        </button>

        {/* Guarantee Badge */}
        <div className="mt-6 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
          <span>Guest ID stored locally on device</span>
        </div>
      </main>

      {/* Footer */}
      <footer className="text-center text-xs text-slate-600 py-2">
        ClashRen Guest Identity Engine
      </footer>
    </div>
  );
};
