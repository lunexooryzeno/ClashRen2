import React, { useState, useEffect } from 'react';
import { GuestProfile, CoinTransaction } from '../types';
import { Coins, Plus, History, X, ArrowUpRight, MessageCircle, ExternalLink, ShieldCheck } from 'lucide-react';

interface WalletModalProps {
  profile: GuestProfile;
  onClose: () => void;
  onOpenAddCoins: () => void;
  adminWhatsAppNumber?: string;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  profile,
  onClose,
  onOpenAddCoins,
  adminWhatsAppNumber = '919876543210',
}) => {
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');

  useEffect(() => {
    fetchTransactions();
  }, [profile.guestId, profile.coins]);

  const fetchTransactions = async () => {
    try {
      const res = await fetch(`/api/guest/${profile.guestId}/transactions`);
      if (res.ok) {
        const data = await res.json();
        setTransactions(data);
      }
    } catch (err) {
      // Silently handle transient fetch errors
    } finally {
      setLoading(false);
    }
  };

  const handleWithdrawWhatsApp = () => {
    const num = parseInt(withdrawAmount, 10);
    const requestedAmount = !isNaN(num) && num > 0 ? num : profile.withdrawableCoins;

    const textMessage = `Hello Admin,

I want to WITHDRAW coins from my ClashRen account.

Guest ID: ${profile.guestId}
Player Nickname: ${profile.nickname}
Requested Withdrawal Amount: ${requestedAmount} Coins (₹${requestedAmount})
Available Withdrawable Coins: ${profile.withdrawableCoins} Coins
Total Wallet Coins: ${profile.coins} Coins

Please verify my account and share the payment details (UPI / GPay / PhonePe).`;

    const encodedText = encodeURIComponent(textMessage);
    const whatsappUrl = `https://wa.me/${adminWhatsAppNumber}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  const getActionBadge = (tx: CoinTransaction) => {
    if (tx.amount > 0) {
      return (
        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold font-mono">
          +{tx.amount} Coins
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 text-[10px] font-bold font-mono">
        {tx.amount} Coins
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl relative my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-amber-400 font-black text-lg">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
            <span>ClashRen Coin Wallet</span>
          </div>
        </div>

        {/* Balance Display Card */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                Available Balance
              </span>
              <span className="text-3xl font-mono font-black text-amber-400 mt-0.5 block">
                {profile.coins} <span className="text-sm text-slate-400 font-sans font-semibold">Coins</span>
              </span>
            </div>

            <button
              onClick={onOpenAddCoins}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Add Coins</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-center text-xs">
            <div className="bg-slate-900 p-2 rounded-xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Withdrawable</span>
              <span className="font-mono font-bold text-emerald-400">{profile.withdrawableCoins} Coins</span>
            </div>
            <div className="bg-slate-900 p-2 rounded-xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Pending Winnings</span>
              <span className="font-mono font-bold text-orange-400">{profile.pendingCoins} Coins</span>
            </div>
          </div>
        </div>

        {/* Fast Wallet Actions: Add & Withdraw */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onOpenAddCoins}
              className="py-3 px-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/10"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Add Coins</span>
            </button>

            <button
              onClick={handleWithdrawWhatsApp}
              className="py-3 px-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/10"
            >
              <ArrowUpRight className="w-4 h-4 stroke-[3]" />
              <span>Withdraw</span>
            </button>
          </div>

          {/* Optional Withdrawal Form Card */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Withdraw Coins via WhatsApp
              </span>
              <span className="text-[10px] font-mono text-emerald-400 font-semibold">
                Rate: 1 Coin = ₹1
              </span>
            </div>

            <div className="flex gap-2">
              <input
                type="number"
                min="1"
                max={profile.withdrawableCoins}
                placeholder={`Amount (e.g. ${profile.withdrawableCoins || 100})`}
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-500/50 font-mono"
              />
              <button
                onClick={handleWithdrawWhatsApp}
                className="px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs transition-all cursor-pointer flex items-center gap-1 shrink-0"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-slate-950" />
                <span>Withdraw</span>
                <ExternalLink className="w-3 h-3 opacity-80" />
              </button>
            </div>
          </div>
        </div>

        {/* Transaction History Section */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span>Transaction History</span>
            </h4>
            <span className="text-[10px] text-slate-400 font-mono">{transactions.length} records</span>
          </div>

          {loading ? (
            <div className="text-center py-6 text-slate-500 text-xs">Loading ledger transactions...</div>
          ) : transactions.length === 0 ? (
            <div className="bg-slate-950 p-4 rounded-xl text-center text-xs text-slate-500">
              No coin transactions logged yet.
            </div>
          ) : (
            <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
              {transactions.map((tx) => (
                <div
                  key={tx.txnId || tx.id}
                  className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <span className="font-semibold text-white block">{tx.reason || tx.description}</span>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                      <span>{tx.txnId || tx.id}</span>
                      <span>•</span>
                      <span>{new Date(tx.createdAt).toLocaleTimeString()}</span>
                    </div>
                  </div>

                  <div className="text-right space-y-0.5">
                    {getActionBadge(tx)}
                    <span className="text-[10px] text-slate-500 block font-mono">
                      Bal: {tx.newBalance ?? tx.balanceAfter}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
