import React, { useState, useEffect } from 'react';
import {
  HostWorker,
  UserFeedback,
  Match,
  MacroDroidPhoneStatus,
  GuestProfile,
  CoinTransaction,
  VerificationWorkerStatus,
} from '../types';
import {
  ShieldAlert,
  Smartphone,
  Users,
  Swords,
  AlertCircle,
  MessageSquare,
  Play,
  RefreshCw,
  X,
  Check,
  Copy,
  ExternalLink,
  Search,
  PlusCircle,
  MinusCircle,
  Coins,
  History,
  Lock,
  LogOut,
  CheckCircle2,
  XCircle,
  Activity,
  Cpu,
} from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  // Authentication State
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return sessionStorage.getItem('clashren_admin_token');
  });
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Dashboard Tab State
  const [activeTab, setActiveTab] = useState<
    'overview' | 'disputes' | 'guest_search' | 'players' | 'matches' | 'workers' | 'simulation' | 'feedback'
  >('overview');

  // Overview & Data States
  const [overviewData, setOverviewData] = useState<any>(null);
  const [feedbacks, setFeedbacks] = useState<UserFeedback[]>([]);
  const [loading, setLoading] = useState(true);

  // Guest Search & Coin Management States
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedGuestResult, setSearchedGuestResult] = useState<{
    guest: GuestProfile;
    wallet: { coins: number; pendingCoins: number; lockedCoins: number; withdrawableCoins: number };
    transactions: CoinTransaction[];
    matchHistory: Match[];
  } | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  // Add / Remove Coins Form State
  const [coinAmount, setCoinAmount] = useState<number>(50);
  const [coinReason, setCoinReason] = useState('');
  const [coinActionSuccess, setCoinActionSuccess] = useState<string | null>(null);
  const [coinActionError, setCoinActionError] = useState<string | null>(null);
  const [isProcessingCoins, setIsProcessingCoins] = useState(false);

  // MacroDroid Simulation Form State
  const [simMatchId, setSimMatchId] = useState('');
  const [simStatus, setSimStatus] = useState<MacroDroidPhoneStatus>('room_created');
  const [simRoomId, setSimRoomId] = useState('48271639');
  const [simRoomPass, setSimRoomPass] = useState('7799');

  // Verify stored token on mount
  useEffect(() => {
    if (adminToken) {
      verifyAdminToken(adminToken);
    }
  }, []);

  // Poll overview data when authenticated
  useEffect(() => {
    if (!adminToken) return;
    fetchAdminData();
    const interval = setInterval(fetchAdminData, 3000);
    return () => clearInterval(interval);
  }, [adminToken]);

  const verifyAdminToken = async (token: string) => {
    try {
      const res = await fetch('/api/admin/verify', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        handleLogout();
      }
    } catch (err) {
      handleLogout();
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: emailInput, password: passwordInput }),
      });

      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || 'Login failed. Please check credentials.');
        return;
      }

      setAdminToken(data.token);
      sessionStorage.setItem('clashren_admin_token', data.token);
      setPasswordInput('');
    } catch (err) {
      setLoginError('Network error during login. Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    if (adminToken) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${adminToken}` },
        });
      } catch (e) {
        // Ignore network errors on logout
      }
    }
    setAdminToken(null);
    sessionStorage.removeItem('clashren_admin_token');
    setSearchedGuestResult(null);
  };

  const fetchAdminData = async () => {
    if (!adminToken) return;
    try {
      const res = await fetch('/api/admin/overview', {
        headers: { Authorization: `Bearer ${adminToken}` },
      });

      if (res.status === 401) {
        handleLogout();
        return;
      }

      if (res.ok) {
        const data = await res.json();
        setOverviewData(data);
        if (data.recentMatches && data.recentMatches.length > 0 && !simMatchId) {
          setSimMatchId(data.recentMatches[0].matchId);
        }
      }

      const fbRes = await fetch('/api/feedback');
      if (fbRes.ok) {
        const fbData = await fbRes.json();
        setFeedbacks(fbData);
      }
    } catch (err) {
      // Silently handle admin overview fetch errors
    } finally {
      setLoading(false);
    }
  };

  const handleSearchGuest = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim() || !adminToken) return;

    setIsSearching(true);
    setSearchError(null);
    setCoinActionSuccess(null);
    setCoinActionError(null);

    try {
      const res = await fetch(`/api/admin/guest/search/${encodeURIComponent(searchQuery.trim())}`, {
        headers: { Authorization: `Bearer ${adminToken}` },
      });

      const data = await res.json();
      if (!res.ok) {
        setSearchError(data.error || 'Guest not found');
        setSearchedGuestResult(null);
        return;
      }

      setSearchedGuestResult(data);
    } catch (err) {
      setSearchError('Error performing guest search.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleCoinAction = async (action: 'ADD' | 'REMOVE' | 'PENALTY') => {
    if (!searchedGuestResult || !adminToken || coinAmount <= 0) return;

    setIsProcessingCoins(true);
    setCoinActionSuccess(null);
    setCoinActionError(null);

    try {
      const res = await fetch('/api/admin/coins', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({
          guestId: searchedGuestResult.guest.guestId,
          amount: Number(coinAmount),
          action,
          reason: coinReason,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setCoinActionError(data.error || 'Coin adjustment failed');
        return;
      }

      setCoinActionSuccess(
        `Action ${action} successful! Old Balance: ${data.previousBalance} Coins | Change: ${action === 'ADD' ? '+' : '-'}${coinAmount} Coins | New Balance: ${data.newBalance} Coins`
      );

      // Refresh guest details
      handleSearchGuest();
      fetchAdminData();
      setCoinReason('');
    } catch (err) {
      setCoinActionError('Network error while adjusting coins.');
    } finally {
      setIsProcessingCoins(false);
    }
  };

  const handleToggleGuestAccount = async (guestId: string, currentEnabled: boolean) => {
    if (!adminToken) return;
    try {
      await fetch('/api/admin/guest/toggle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ guestId, isEnabled: !currentEnabled }),
      });
      fetchAdminData();
      if (searchedGuestResult?.guest.guestId === guestId) {
        handleSearchGuest();
      }
    } catch (err) {
      console.error('Toggle guest failed', err);
    }
  };

  const handleResolveDispute = async (
    matchId: string,
    resolution: 'CASE_A_FAKE_WINNER' | 'CASE_B_GENUINE_WINNER',
    notes?: string
  ) => {
    if (!adminToken) return;
    try {
      const res = await fetch(`/api/admin/disputes/${matchId}/resolve`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ resolution, adminNotes: notes || 'Resolved via Admin Panel' }),
      });
      if (res.ok) {
        fetchAdminData();
      }
    } catch (err) {
      console.error('Resolve dispute failed', err);
    }
  };

  const handleFreezeWallet = async (guestId: string, frozen: boolean) => {
    if (!adminToken) return;
    try {
      await fetch('/api/admin/guest/freeze-wallet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ guestId, frozen }),
      });
      fetchAdminData();
      if (searchedGuestResult?.guest.guestId === guestId) handleSearchGuest();
    } catch (err) {
      console.error('Freeze wallet failed', err);
    }
  };

  const handleBlockAccount = async (guestId: string, blocked: boolean, reason?: string) => {
    if (!adminToken) return;
    try {
      await fetch('/api/admin/guest/block', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({ guestId, blocked, reason }),
      });
      fetchAdminData();
      if (searchedGuestResult?.guest.guestId === guestId) handleSearchGuest();
    } catch (err) {
      console.error('Block account failed', err);
    }
  };

  const handleSimulateMacroDroid = async () => {
    if (!simMatchId || !adminToken) return;
    try {
      await fetch('/api/admin/simulate-macrodroid', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({
          matchId: simMatchId,
          phoneStatus: simStatus,
          roomId: simRoomId,
          roomPassword: simRoomPass,
        }),
      });
      fetchAdminData();
    } catch (err) {
      console.error('Simulation trigger failed', err);
    }
  };

  // Render Admin Login Page if unauthenticated
  if (!adminToken) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/98 backdrop-blur-md flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto shadow-inner">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-white">ClashRen Admin Login</h2>
            <p className="text-xs text-slate-400">
              Prototype control panel & management portal
            </p>
          </div>

          {loginError && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3.5 rounded-2xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                Admin Email
              </label>
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="admin@example.com"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-500/50 transition-all font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                Admin Password
              </label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••••••••••••••••"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-500/50 transition-all font-mono"
              />
            </div>

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoggingIn ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Sign In to Admin Dashboard</span>
                </>
              )}
            </button>
          </form>

          <div className="text-center text-[11px] text-slate-500 border-t border-slate-800/80 pt-4">
            Secured via server-side session authentication. No credentials stored in browser bundles.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col p-2 sm:p-4 md:p-8 overflow-y-auto">
      <div className="max-w-5xl w-full mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 space-y-6 shadow-2xl relative my-auto">
        {/* Top Action Controls */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white">ClashRen Admin Dashboard</h2>
              <p className="text-xs text-slate-400">Master Control, Guest Wallet & Host Architecture</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dashboard Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-800/80 no-scrollbar">
          {(
            [
              { id: 'overview', label: 'Overview' },
              { id: 'disputes', label: `Dispute Review (${overviewData?.pendingDisputesCount || 0})` },
              { id: 'guest_search', label: 'Search Guest & Wallet' },
              { id: 'players', label: 'Active Players' },
              { id: 'matches', label: 'Active Matches & Jobs' },
              { id: 'workers', label: 'Worker Phone Status' },
              { id: 'simulation', label: 'MacroDroid Simulator' },
              { id: 'feedback', label: `Feedback (${feedbacks.length})` },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* TAB: DISPUTES REVIEW */}
        {activeTab === 'disputes' && overviewData && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400" />
                Dispute Review & Result Appeals
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                {overviewData.recentMatches?.filter((m: Match) => m.status === 'DISPUTED' || m.dispute).length || 0} Total Disputes
              </span>
            </div>

            {overviewData.recentMatches?.filter((m: Match) => m.status === 'DISPUTED' || m.dispute).length === 0 ? (
              <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-base font-bold text-white">No Open Disputes</h4>
                <p className="text-xs text-slate-400">All match results are verified and payouts finalized cleanly.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {overviewData.recentMatches
                  ?.filter((m: Match) => m.status === 'DISPUTED' || m.dispute)
                  .map((m: Match) => (
                    <div
                      key={m.matchId}
                      className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-amber-400 text-sm">Match ID: {m.matchId}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            m.status === 'DISPUTED' ? 'bg-red-500/10 text-red-400 border border-red-500/30' : 'bg-emerald-500/10 text-emerald-400'
                          }`}>
                            STATUS: {m.status}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          Prize: {m.prize} Coins
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        {/* Claimant Details */}
                        <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 space-y-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Claimant (Disputer)
                          </span>
                          <p className="font-mono font-bold text-white text-sm">
                            {m.dispute?.disputerGuestId || m.playerA.guestId}
                          </p>
                          <p className="text-[11px] text-amber-400">
                            Verification Deposit Paid: {m.dispute?.depositAmount || 5} Coins
                          </p>
                        </div>

                        {/* Accused / Winner Details */}
                        <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 space-y-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Claimed Winner / Accused
                          </span>
                          <p className="font-mono font-bold text-white text-sm">
                            {m.dispute?.accusedGuestId || m.claimedWinnerId || m.playerB.guestId}
                          </p>
                          <p className="text-[11px] text-emerald-400">
                            Pending Reward: {m.prize} Coins
                          </p>
                        </div>
                      </div>

                      {/* Reason & Proof */}
                      <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 text-xs space-y-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                          Dispute Reason & WhatsApp Alert Text
                        </span>
                        <p className="text-slate-200 font-medium">{m.dispute?.reason}</p>

                        {m.dispute?.whatsAppAlertText && (
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-[11px] text-amber-300 whitespace-pre-wrap">
                            {m.dispute.whatsAppAlertText}
                          </div>
                        )}

                        {m.screenshotUrl && (
                          <div className="pt-2 flex items-center gap-2">
                            <span className="text-[11px] text-slate-400">Submitted Screenshot:</span>
                            <a
                              href={m.screenshotUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-amber-400 hover:underline font-mono text-[11px] flex items-center gap-1"
                            >
                              <span>{m.screenshotUrl}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        )}
                      </div>

                      {/* Resolution Action Controls */}
                      {m.status === 'DISPUTED' && (
                        <div className="space-y-2 pt-2 border-t border-slate-800">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                            Admin Resolution Actions:
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {/* Case A: Fake Victory */}
                            <button
                              onClick={() => handleResolveDispute(m.matchId, 'CASE_A_FAKE_WINNER')}
                              className="p-3.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 text-xs font-bold transition-all cursor-pointer text-left space-y-1"
                            >
                              <div className="font-bold flex items-center gap-1.5 text-red-400">
                                <XCircle className="w-4 h-4" />
                                <span>Case A: Winner Was Fake</span>
                              </div>
                              <p className="text-[10px] text-slate-300 leading-tight">
                                Remove pending reward from fake winner, credit prize to claimant, refund 5 Coin deposit, increment violation count & block account.
                              </p>
                            </button>

                            {/* Case B: Genuine Victory */}
                            <button
                              onClick={() => handleResolveDispute(m.matchId, 'CASE_B_GENUINE_WINNER')}
                              className="p-3.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all cursor-pointer text-left space-y-1"
                            >
                              <div className="font-bold flex items-center gap-1.5 text-emerald-400">
                                <CheckCircle2 className="w-4 h-4" />
                                <span>Case B: Winner Was Genuine</span>
                              </div>
                              <p className="text-[10px] text-slate-300 leading-tight">
                                Finalize pending reward to winner, transfer 5 Coin deposit to winner, mark dispute false, reduce claimant trust score.
                              </p>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && overviewData && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Active Players
                </span>
                <span className="text-2xl font-mono font-bold text-white mt-1 block">
                  {overviewData.activePlayersCount}
                </span>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Active Queues
                </span>
                <span className="text-2xl font-mono font-bold text-amber-400 mt-1 block">
                  {overviewData.queuesCount}
                </span>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Active Matches
                </span>
                <span className="text-2xl font-mono font-bold text-emerald-400 mt-1 block">
                  {overviewData.activeMatchesCount}
                </span>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Pending Room Jobs
                </span>
                <span className="text-2xl font-mono font-bold text-indigo-400 mt-1 block">
                  {overviewData.pendingRoomJobsCount || 0}
                </span>
              </div>
            </div>

            {/* Quick Summary Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Host Worker Phones Status */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-amber-400" />
                    MacroDroid Host Phone Status
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">LIVE</span>
                </h4>

                <div className="space-y-2">
                  {overviewData.workers?.map((w: HostWorker) => (
                    <div
                      key={w.workerId}
                      className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{w.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{w.workerId}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[11px] text-slate-400">
                          {w.battery}% ({w.internet})
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            w.status === 'ONLINE'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-red-500/10 text-red-400'
                          }`}
                        >
                          {w.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verification Phone Status */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-amber-400" />
                    Verification Phone & OCR Engine
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">ACTIVE</span>
                </h4>

                {overviewData.verificationWorker && (
                  <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{overviewData.verificationWorker.name}</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold text-[10px]">
                        {overviewData.verificationWorker.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1">
                      <div>
                        OCR Engine: <span className="text-slate-200 font-mono">{overviewData.verificationWorker.ocrEngine}</span>
                      </div>
                      <div>
                        Confidence: <span className="text-amber-400 font-mono">{(overviewData.verificationWorker.confidenceThreshold * 100)}%</span>
                      </div>
                      <div>
                        Processed Screenshots: <span className="text-white font-mono">{overviewData.verificationWorker.processedCount}</span>
                      </div>
                      <div>
                        Pending Queue: <span className="text-indigo-400 font-mono">{overviewData.pendingVerificationCount}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SEARCH GUEST & WALLET MANAGEMENT */}
        {activeTab === 'guest_search' && (
          <div className="space-y-5">
            <div className="bg-slate-950 p-4 sm:p-5 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Search className="w-4 h-4 text-amber-400" />
                Search Guest Account & Manage Wallet Coins
              </h4>

              <form onSubmit={handleSearchGuest} className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Enter Guest ID (e.g. CR-8F2A-91KD) or Guest Nickname..."
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-500/50 transition-all font-mono"
                />
                <button
                  type="submit"
                  disabled={isSearching}
                  className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  {isSearching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  <span>Search</span>
                </button>
              </form>

              {searchError && (
                <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{searchError}</span>
                </div>
              )}
            </div>

            {/* Guest Result View */}
            {searchedGuestResult && (
              <div className="space-y-5">
                {/* Profile Header & Account Controls */}
                <div className="bg-slate-950 p-4 sm:p-5 rounded-2xl border border-amber-500/30 space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-black text-white">{searchedGuestResult.guest.nickname}</span>
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-amber-400 font-mono text-xs font-bold">
                          {searchedGuestResult.guest.guestId}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Joined: {new Date(searchedGuestResult.guest.createdAt).toLocaleString()} | Trust Score: {searchedGuestResult.guest.trustScore}/100
                      </p>
                    </div>

                    <button
                      onClick={() => handleToggleGuestAccount(searchedGuestResult.guest.guestId, searchedGuestResult.guest.isEnabled)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                        searchedGuestResult.guest.isEnabled
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                          : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20'
                      }`}
                    >
                      {searchedGuestResult.guest.isEnabled ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                      <span>{searchedGuestResult.guest.isEnabled ? 'Account Active' : 'Account Disabled'}</span>
                    </button>
                  </div>

                  {/* Wallet Breakdown Grid */}
                  <div>
                    <h5 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <Coins className="w-3.5 h-3.5 text-amber-400" />
                      Guest Wallet Balance Breakdown
                    </h5>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                      <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 block">Total Balance</span>
                        <span className="text-lg font-mono font-bold text-amber-400">{searchedGuestResult.wallet.coins} Coins</span>
                      </div>
                      <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 block">Withdrawable</span>
                        <span className="text-lg font-mono font-bold text-emerald-400">{searchedGuestResult.wallet.withdrawableCoins} Coins</span>
                      </div>
                      <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 block">Pending Winnings</span>
                        <span className="text-lg font-mono font-bold text-indigo-400">{searchedGuestResult.wallet.pendingCoins} Coins</span>
                      </div>
                      <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 block">Locked Coins</span>
                        <span className="text-lg font-mono font-bold text-slate-400">{searchedGuestResult.wallet.lockedCoins} Coins</span>
                      </div>
                    </div>
                  </div>

                  {/* Add / Remove Coins Form */}
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3 pt-4">
                    <h5 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-2">
                      <Coins className="w-4 h-4 text-amber-400" />
                      Server-Side Coin Adjustments
                    </h5>

                    {coinActionSuccess && (
                      <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 p-3 rounded-xl text-xs flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <span>{coinActionSuccess}</span>
                      </div>
                    )}

                    {coinActionError && (
                      <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-xl text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{coinActionError}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 block">Amount (Coins)</label>
                        <input
                          type="number"
                          min="1"
                          value={coinAmount}
                          onChange={(e) => setCoinAmount(Number(e.target.value))}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[11px] font-bold text-slate-400 block">Reason / Audit Note</label>
                        <input
                          type="text"
                          value={coinReason}
                          onChange={(e) => setCoinReason(e.target.value)}
                          placeholder="e.g. Tournament reward / Adjustment"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 pt-1">
                      <button
                        onClick={() => handleCoinAction('ADD')}
                        disabled={isProcessingCoins || coinAmount <= 0}
                        className="flex-1 min-w-[120px] py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                      >
                        <PlusCircle className="w-4 h-4" />
                        <span>+ Add Coins</span>
                      </button>

                      <button
                        onClick={() => handleCoinAction('REMOVE')}
                        disabled={isProcessingCoins || coinAmount <= 0}
                        className="flex-1 min-w-[120px] py-2.5 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                      >
                        <MinusCircle className="w-4 h-4" />
                        <span>- Remove Coins</span>
                      </button>

                      <button
                        onClick={() => handleCoinAction('PENALTY')}
                        disabled={isProcessingCoins || coinAmount <= 0}
                        className="py-2.5 px-3 rounded-xl bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 border border-orange-500/30 font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                      >
                        <AlertCircle className="w-4 h-4" />
                        <span>Penalty</span>
                      </button>
                    </div>

                    {/* Quick View Controls */}
                    <div className="flex gap-2 pt-2 border-t border-slate-800">
                      <button
                        onClick={() => setActiveTab('players')}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-slate-950 text-slate-300 border border-slate-800 hover:border-amber-500/30 text-[11px] font-semibold text-center"
                      >
                        View Player Profile
                      </button>
                      <button
                        onClick={() => setActiveTab('guest_search')}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-slate-950 text-amber-400 border border-amber-500/30 text-[11px] font-semibold text-center"
                      >
                        View Wallet Details
                      </button>
                    </div>
                  </div>

                  {/* Transaction History for Searched Guest */}
                  <div className="space-y-2 pt-2">
                    <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <History className="w-3.5 h-3.5 text-amber-400" />
                        Transaction History ({searchedGuestResult.transactions.length})
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">Server Audit Ledger</span>
                    </h5>

                    {searchedGuestResult.transactions.length === 0 ? (
                      <p className="text-xs text-slate-500 bg-slate-900 p-3 rounded-xl text-center">No coin transactions recorded for this guest yet.</p>
                    ) : (
                      <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                        {searchedGuestResult.transactions.map((tx) => (
                          <div key={tx.txnId || tx.id} className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1 text-xs">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-amber-400">{tx.txnId || tx.id}</span>
                                <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold font-mono ${
                                  tx.action === 'ADD' || tx.amount > 0
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                    : 'bg-red-500/10 text-red-400 border border-red-500/20'
                                }`}>
                                  {tx.action || (tx.amount > 0 ? 'ADD' : 'REMOVE')}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {new Date(tx.createdAt).toLocaleString()}
                              </span>
                            </div>

                            <div className="flex items-center justify-between text-[11px] text-slate-300">
                              <span>Reason: <strong className="text-white">{tx.reason || tx.description}</strong></span>
                              <span className="font-mono font-bold text-white">
                                Amount: {tx.amount > 0 ? `+${tx.amount}` : tx.amount} Coins
                              </span>
                            </div>

                            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1 border-t border-slate-800/60">
                              <span>Admin: {tx.adminEmail || 'lunexo@admin.com'}</span>
                              <span>Old Bal: {tx.previousBalance ?? '-'} → New Bal: {tx.newBalance ?? tx.balanceAfter}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: ACTIVE PLAYERS */}
        {activeTab === 'players' && overviewData && (
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Registered Guest Players ({overviewData.activePlayersList?.length || 0})
            </h4>

            <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="max-h-96 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800 sticky top-0">
                    <tr>
                      <th className="p-3">Guest ID</th>
                      <th className="p-3">Nickname</th>
                      <th className="p-3">Coins</th>
                      <th className="p-3">Wins / Losses</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {overviewData.activePlayersList?.map((g: GuestProfile) => (
                      <tr key={g.guestId} className="hover:bg-slate-900/50">
                        <td className="p-3 font-mono text-amber-400 font-bold">{g.guestId}</td>
                        <td className="p-3 font-semibold text-white">{g.nickname}</td>
                        <td className="p-3 font-mono font-bold text-emerald-400">{g.coins}</td>
                        <td className="p-3 text-slate-300">{g.wins}W / {g.losses}L</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${g.isEnabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                            {g.isEnabled ? 'Active' : 'Disabled'}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <button
                            onClick={() => {
                              setSearchQuery(g.guestId);
                              setActiveTab('guest_search');
                            }}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-300 font-bold text-[10px] transition-all cursor-pointer"
                          >
                            Manage Wallet
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: ACTIVE MATCHES & ROOM JOBS */}
        {activeTab === 'matches' && overviewData && (
          <div className="space-y-4">
            {/* Pending Room Jobs */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-indigo-500/30 space-y-3">
              <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center justify-between">
                <span>Pending Room Creation Jobs ({overviewData.pendingRoomJobs?.length || 0})</span>
                <span className="text-[10px] text-indigo-400 font-mono">MacroDroid Pipeline</span>
              </h4>

              {overviewData.pendingRoomJobs?.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-2">No pending room creation jobs right now.</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {overviewData.pendingRoomJobs?.map((m: Match) => (
                    <div key={m.matchId} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-amber-400 font-mono">{m.matchId}</span>
                        <span className="text-slate-300 block font-semibold">{m.playerA.nickname} vs {m.playerB.nickname}</span>
                      </div>
                      <div className="text-right font-mono text-[11px]">
                        <span className="text-indigo-400 font-bold block">{m.status}</span>
                        <span className="text-slate-400 text-[10px]">Token: {m.accessToken.substring(0, 12)}...</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* All Active Matches */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                Ongoing Matches ({overviewData.activeMatches?.length || 0})
              </h4>

              {overviewData.activeMatches?.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-2">No active matches at the moment.</p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {overviewData.activeMatches?.map((m: Match) => (
                    <div key={m.matchId} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-mono font-bold text-amber-400">{m.matchId}</span>
                        <span className="text-white block font-semibold">{m.playerA.nickname} vs {m.playerB.nickname}</span>
                        <span className="text-[10px] text-slate-400">Entry: {m.entryFee} Coins | Prize: {m.prize} Coins</span>
                      </div>
                      <div className="text-right">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono font-bold text-[10px]">
                          {m.status}
                        </span>
                        {m.roomCredentials && (
                          <span className="text-[10px] text-slate-400 block font-mono mt-1">Room: {m.roomCredentials.roomId}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 5: WORKERS & VERIFICATION PHONES */}
        {activeTab === 'workers' && overviewData && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Host Worker Phone & Verification Phone Architecture
            </h4>

            {/* MacroDroid Hosts */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-amber-400 block">1. MacroDroid Host Worker Phones</span>
              {overviewData.workers?.map((w: HostWorker) => (
                <div key={w.workerId} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white text-sm block">{w.name}</span>
                      <span className="font-mono text-[10px] text-amber-400">{w.workerId}</span>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      w.status === 'ONLINE' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400'
                    }`}>
                      {w.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-slate-400 pt-1">
                    <div>Battery Level: <span className="text-white font-mono">{w.battery}%</span></div>
                    <div>Internet Type: <span className="text-white font-mono">{w.internet}</span></div>
                    <div>Webhook Endpoint: <span className="text-amber-300 font-mono">POST /api/workers/host/status</span></div>
                  </div>
                </div>
              ))}
            </div>

            {/* Verification Worker Phone */}
            {overviewData.verificationWorker && (
              <div className="space-y-2 pt-2">
                <span className="text-xs font-bold text-amber-400 block">2. Verification Phone (Victory Screenshot OCR)</span>
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{overviewData.verificationWorker.name}</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-bold">
                      {overviewData.verificationWorker.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Engine: <code className="text-amber-300">{overviewData.verificationWorker.ocrEngine}</code> | Confidence Threshold: <span className="text-emerald-400 font-bold">85%</span>
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 6: MACRODROID SIMULATOR */}
        {activeTab === 'simulation' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 sm:p-5 rounded-2xl border border-amber-500/30 space-y-3">
              <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-2">
                <Play className="w-4 h-4 text-amber-400" />
                Live MacroDroid Room Creation Simulator
              </h4>
              <p className="text-xs text-slate-400">
                Trigger simulated room creation payloads for testing the player workflow without connecting an Android device.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold block">Target Match ID</label>
                  <input
                    type="text"
                    value={simMatchId}
                    onChange={(e) => setSimMatchId(e.target.value)}
                    placeholder="e.g. M-1021"
                    className="w-full bg-slate-900 text-white rounded-xl p-2.5 border border-slate-800 font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 font-semibold block">MacroDroid Phone Status</label>
                  <select
                    value={simStatus}
                    onChange={(e) => setSimStatus(e.target.value as any)}
                    className="w-full bg-slate-900 text-white rounded-xl p-2.5 border border-slate-800 font-mono"
                  >
                    <option value="Ready">Ready</option>
                    <option value="Launching Free Fire">Launching Free Fire</option>
                    <option value="Switching Guest Account">Switching Guest Account</option>
                    <option value="Opening Room Menu">Opening Room Menu</option>
                    <option value="Configuring Room">Configuring Room</option>
                    <option value="Creating Room">Creating Room</option>
                    <option value="Room Created">Room Created (Generate Credentials)</option>
                    <option value="Sending Credentials">Sending Credentials</option>
                    <option value="Error">Error</option>
                  </select>
                </div>

                {(simStatus === 'room_created' || simStatus === 'Room Created') && (
                  <>
                    <div className="space-y-1">
                      <label className="text-slate-400 font-semibold block">Simulated Room ID</label>
                      <input
                        type="text"
                        value={simRoomId}
                        onChange={(e) => setSimRoomId(e.target.value)}
                        className="w-full bg-slate-900 text-white rounded-xl p-2.5 border border-slate-800 font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-400 font-semibold block">Simulated Password</label>
                      <input
                        type="text"
                        value={simRoomPass}
                        onChange={(e) => setSimRoomPass(e.target.value)}
                        className="w-full bg-slate-900 text-white rounded-xl p-2.5 border border-slate-800 font-mono"
                      />
                    </div>
                  </>
                )}
              </div>

              <button
                onClick={handleSimulateMacroDroid}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>Send Simulated MacroDroid Status Update</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 7: FEEDBACK INBOX */}
        {activeTab === 'feedback' && (
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Community Feedback Inbox ({feedbacks.length})
            </h4>

            {feedbacks.length === 0 ? (
              <div className="bg-slate-950 p-6 rounded-2xl text-center text-slate-500 text-xs">
                No feedback received yet.
              </div>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {feedbacks.map((fb) => (
                  <div key={fb.id} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-slate-400">
                      <span className="font-bold text-amber-400">{fb.category}</span>
                      <span className="font-mono text-[10px]">{fb.guestId}</span>
                    </div>
                    <p className="text-slate-200">{fb.description}</p>
                    {fb.experienceRating && (
                      <span className="inline-block px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 text-[10px]">
                        Rating: {fb.experienceRating}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
