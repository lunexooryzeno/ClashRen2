import React, { useEffect, useState } from 'react';
import { QueueItem, GuestProfile } from '../types';
import { Radar, X, Swords, Shield, Trophy, Coins } from 'lucide-react';

interface MatchmakingQueueModalProps {
  queueItem: QueueItem;
  profile: GuestProfile;
  onCancelQueue: () => void;
}

export const MatchmakingQueueModal: React.FC<MatchmakingQueueModalProps> = ({
  queueItem,
  profile,
  onCancelQueue,
}) => {
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainingSecs = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 text-center space-y-6 shadow-2xl relative overflow-hidden">
        {/* Ambient background glow */}
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div>
          <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 uppercase tracking-wider">
            Matchmaking Queue
          </span>
          <h2 className="text-2xl font-black text-white mt-3">Searching for Opponent</h2>
          <p className="text-xs text-slate-400 mt-1">Finding a 1v1 player in community queue…</p>
        </div>

        {/* Animated Radar Pulse */}
        <div className="relative w-36 h-36 mx-auto flex items-center justify-center my-4">
          <div className="absolute inset-0 rounded-full border border-amber-500/20 animate-ping opacity-75" />
          <div className="absolute inset-2 rounded-full border border-orange-500/30 animate-pulse" />
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-500/20 to-orange-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-xl">
            <Swords className="w-10 h-10 animate-bounce" />
          </div>
        </div>

        {/* Queue Timer */}
        <div className="bg-slate-950 rounded-2xl p-3 border border-slate-800 inline-block px-6">
          <div className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Queue Time</div>
          <div className="text-2xl font-mono font-bold text-amber-400 mt-0.5">{formatTimer(seconds)}</div>
        </div>

        {/* Guest ID & Game Summary */}
        <div className="bg-slate-950/80 rounded-2xl p-4 border border-slate-800 text-left space-y-3">
          <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
            <span className="text-slate-400">Your Guest ID</span>
            <span className="font-mono font-bold text-amber-400">{profile.guestId}</span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-slate-900 p-2 rounded-xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Game</span>
              <span className="font-semibold text-slate-200">{queueItem.game}</span>
            </div>
            <div className="bg-slate-900 p-2 rounded-xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Entry Fee</span>
              <span className="font-semibold text-slate-200">{queueItem.entryFee} Coins</span>
            </div>
            <div className="bg-slate-900 p-2 rounded-xl border border-slate-800/80">
              <span className="text-[10px] text-slate-400 block">Prize</span>
              <span className="font-semibold text-amber-400">{queueItem.prize} Coins</span>
            </div>
          </div>
        </div>

        {/* Cancel Button */}
        <button
          onClick={onCancelQueue}
          className="w-full py-3.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm border border-slate-700 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <X className="w-4 h-4" />
          <span>Cancel Search (Refund {queueItem.entryFee} Coins)</span>
        </button>
      </div>
    </div>
  );
};
