import React from 'react';
import { AlertCircle, Coins, Plus, X, ArrowRight } from 'lucide-react';

interface InsufficientCoinsModalProps {
  currentCoins: number;
  requiredCoins: number;
  onClose: () => void;
  onOpenAddCoins: () => void;
}

export const InsufficientCoinsModal: React.FC<InsufficientCoinsModalProps> = ({
  currentCoins,
  requiredCoins,
  onClose,
  onOpenAddCoins,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-slate-900 border border-red-500/30 rounded-3xl p-6 space-y-5 shadow-2xl relative my-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-black text-white">Insufficient Coins</h3>
          <p className="text-xs text-slate-400">
            You need more coins to join this match. Your wallet balance cannot go negative.
          </p>
        </div>

        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Current Balance:</span>
            <span className="font-mono font-bold text-amber-400">{currentCoins} Coins</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Required Entry Fee:</span>
            <span className="font-mono font-bold text-red-400">{requiredCoins} Coins</span>
          </div>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800 font-bold">
            <span className="text-slate-300">Coins Needed:</span>
            <span className="font-mono text-amber-300">{requiredCoins - currentCoins} Coins</span>
          </div>
        </div>

        <div className="space-y-2">
          <button
            onClick={() => {
              onClose();
              onOpenAddCoins();
            }}
            className="w-full py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-amber-500/10 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Add Coins Now (Manual Admin Approval)</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 text-xs font-semibold transition-all cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
