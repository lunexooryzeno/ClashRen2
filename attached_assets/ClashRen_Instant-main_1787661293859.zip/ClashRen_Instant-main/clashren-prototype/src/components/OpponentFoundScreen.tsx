import React from 'react';
import { Match, GuestProfile } from '../types';
import { Swords, Smartphone, CheckCircle2, Loader2, ShieldCheck, Zap } from 'lucide-react';

interface OpponentFoundScreenProps {
  match: Match;
  profile: GuestProfile;
}

export const OpponentFoundScreen: React.FC<OpponentFoundScreenProps> = ({ match, profile }) => {
  const isPlayerA = match.playerA.guestId === profile.guestId;
  const opponent = isPlayerA ? match.playerB : match.playerA;

  const latestLog = match.hostPhoneLogs[match.hostPhoneLogs.length - 1];
  const displayStatus = match.latestPhoneStatus || latestLog?.message || latestLog?.status || 'Creating Room';

  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl p-5 text-center shadow-xl">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold mb-3">
          <Zap className="w-3.5 h-3.5 fill-emerald-400" />
          <span>MATCH PAIRING COMPLETE</span>
        </div>
        <h2 className="text-2xl font-black text-white">Opponent Found!</h2>
        <p className="text-xs text-slate-400 mt-1">
          Match ID: <span className="font-mono font-bold text-amber-400">{match.matchId}</span>
        </p>
      </div>

      {/* VS Cards Layout */}
      <div className="grid grid-cols-2 gap-3 relative">
        {/* VS Badge in Middle */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shadow-lg border-2 border-slate-950">
          VS
        </div>

        {/* You Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center space-y-1.5">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto text-sm font-bold">
            YOU
          </div>
          <h4 className="font-bold text-sm text-white truncate">{profile.nickname}</h4>
          <p className="text-[11px] font-mono text-amber-400/90 truncate">{profile.guestId}</p>
        </div>

        {/* Opponent Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center space-y-1.5">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 text-orange-400 flex items-center justify-center mx-auto text-sm font-bold">
            OPP
          </div>
          <h4 className="font-bold text-sm text-white truncate">{opponent.nickname}</h4>
          <p className="text-[11px] font-mono text-orange-400/90 truncate">{opponent.guestId}</p>
        </div>
      </div>

      {/* Match Details Breakdown */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-xs space-y-2.5">
        <div className="flex justify-between py-1 border-b border-slate-800">
          <span className="text-slate-400">Game Mode</span>
          <span className="font-semibold text-slate-200">{match.game} (1v1)</span>
        </div>
        <div className="flex justify-between py-1 border-b border-slate-800">
          <span className="text-slate-400">Entry Fee</span>
          <span className="font-semibold text-slate-200">{match.entryFee} Coins</span>
        </div>
        <div className="flex justify-between py-1">
          <span className="text-slate-400">Winning Prize</span>
          <span className="font-bold text-amber-400">{match.prize} Coins</span>
        </div>
      </div>

      {/* Host Phone Status Box */}
      <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-5 space-y-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <Loader2 className="w-5 h-5 animate-spin" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Host Phone Status
            </span>
            <h3 className="text-base font-black text-amber-300 mt-0.5">
              {displayStatus}…
            </h3>
          </div>
        </div>

        {/* Live Status Log Stream */}
        <div className="bg-slate-950 rounded-xl p-3 border border-slate-800/80 font-mono text-[11px] space-y-1.5 text-slate-300">
          <div className="flex items-center justify-between text-emerald-400 border-b border-slate-800/80 pb-1.5">
            <span className="flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5" />
              Worker: {match.workerId}
            </span>
            <span className="text-[10px] text-amber-400 font-bold px-1.5 py-0.5 bg-amber-500/10 rounded border border-amber-500/20">
              LIVE MACRODROID
            </span>
          </div>
          <div className="text-amber-400/90 font-mono pt-0.5">
            &gt; {displayStatus}
          </div>
        </div>
      </div>
    </div>
  );
};
