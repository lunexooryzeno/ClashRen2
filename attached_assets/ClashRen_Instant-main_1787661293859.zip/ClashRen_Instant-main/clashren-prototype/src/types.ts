export type GameCategory = 'Clash Squad' | 'Battle Royale';
export type GameMode = 'Solo' | 'Duo' | 'Squad';
export type GameName = 'Clash Squad Normal';

export interface EntryCardOption {
  id: string;
  entryFee: number;
  prize: number;
}

export interface GuestProfile {
  guestId: string; // e.g. CR-8F2A-91KD
  nickname: string; // e.g. Guest-7F3A92
  coins: number;
  pendingCoins: number;
  lockedCoins: number;
  withdrawableCoins: number;
  trustScore: number;
  matchesPlayed: number;
  wins: number;
  losses: number;
  createdAt: number;
  isEnabled: boolean;
  isBlocked?: boolean;
  blockReason?: string;
  violationCount?: number;
  walletFrozen?: boolean;
}

export type QueueState = 'SEARCHING' | 'MATCHED' | 'CANCELLED';

export interface QueueItem {
  id: string;
  guestId: string;
  nickname: string;
  category: GameCategory;
  mode: GameMode;
  game: GameName;
  entryFee: number;
  prize: number;
  joinedAt: number;
  state: QueueState;
}

export type MatchStatus = 
  | 'WAITING_FOR_ROOM'
  | 'ROOM_CREATING'
  | 'ROOM_READY'
  | 'IN_GAME'
  | 'RESULT_VERIFICATION'
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'DISPUTED'
  | 'FINALIZED'
  | 'CANCELLED';

export type VerificationJobState = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'EXPIRED';

export interface VerificationJob {
  match_id: string;
  guest_id: string;
  opponent_guest_id: string;
  screenshot_url: string;
  verification_token: string;
  created_at: string;
  expires_at: string;
  state: VerificationJobState;
}

export interface VerificationResultPayload {
  verification_token: string;
  match_id: string;
  guest_id: string;
  is_valid_screenshot: boolean;
  is_winner: boolean;
  confidence: number;
  detected_text?: string;
  message?: string;
  response_code?: number;
}

export type MacroDroidPhoneStatus = 
  | 'ready'
  | 'launching_game'
  | 'switching_account'
  | 'opening_room_menu'
  | 'configuring_room'
  | 'creating_room'
  | 'room_created'
  | 'sending_credentials'
  | 'error';

export interface RoomCredentials {
  roomId: string;
  roomPassword: string;
  createdAt: number;
  joinWindowExpiresAt: number; // 30s + 15s grace
  openFfUrl?: string;
}

export interface PlayerJoinState {
  guestId: string;
  joined: boolean;
  joinedAt?: number;
}

export type PayoutState = 
  | 'NOT_CREATED'
  | 'PENDING'
  | 'LOCKED'
  | 'FINALIZED'
  | 'REVERSED';

export interface MatchPayout {
  payoutId: string; // Unique idempotent key: MATCH_ID + _PAYOUT
  matchId: string;
  winnerGuestId: string | null;
  amount: number;
  state: PayoutState;
  createdAt: number;
  finalizedAt?: number;
}

export interface Match {
  matchId: string; // e.g. M-1021
  playerA: GuestProfile;
  playerB: GuestProfile;
  category: GameCategory;
  mode: GameMode;
  game: GameName;
  entryFee: number;
  prize: number;
  status: MatchStatus;
  createdAt: number;
  accessToken: string;
  workerId: string;
  roomCredentials?: RoomCredentials;
  playerAJoin?: PlayerJoinState;
  playerBJoin?: PlayerJoinState;
  hostPhoneLogs: Array<{
    status: MacroDroidPhoneStatus;
    timestamp: number;
    message?: string;
  }>;
  claimedWinnerId?: string;
  screenshotUrl?: string;
  ocrVerification?: {
    valid: boolean;
    detectedNickname?: string;
    detectedText?: string;
    ocrConfidence?: number;
    timestamp: number;
  };
  disputeWindowExpiresAt?: number; // 30 minutes pending timer or 10 minutes window
  pendingRewardExpiresAt?: number;
  verificationMessage?: string;
  dispute?: {
    disputerGuestId: string;
    accusedGuestId?: string;
    depositAmount?: number;
    reason: string;
    screenshotUrl?: string;
    videoUrl?: string;
    status: 'OPEN' | 'RESOLVED_WINNER' | 'RESOLVED_REVERSED' | 'FALSE_DISPUTE';
    createdAt: number;
    adminNotes?: string;
    whatsAppAlertText?: string;
  };
  payout?: MatchPayout;
  finalWinnerId?: string;
  cancelReason?: string;
  dismissedBy?: string[];
  latestPhoneStatus?: string;
  openFfUrl?: string;
}

export interface HostWorker {
  workerId: string;
  name: string;
  webhookUrl: string;
  status: 'ONLINE' | 'OFFLINE' | 'BUSY';
  battery: number;
  internet: '4G' | '5G' | 'WIFI' | 'POOR';
  currentMatchId?: string;
  lastHeartbeatAt: number;
  isEnabled: boolean;
}

export type FeedbackCategory = 
  | 'Bug Report'
  | 'Matchmaking Issue'
  | 'Room Creation Issue'
  | 'Verification Issue'
  | 'Wallet Issue'
  | 'UI / UX Suggestion'
  | 'Feature Request'
  | 'Other';

export interface UserFeedback {
  id: string;
  guestId: string;
  matchId?: string;
  category: FeedbackCategory;
  description: string;
  screenshotUrl?: string;
  experienceRating?: 'Excellent' | 'Good' | 'Average' | 'Poor' | 'Very Poor';
  createdAt: number;
  status: 'NEW' | 'IN_PROGRESS' | 'RESOLVED';
}

export interface MacroDroidStatusPayload {
  worker_id: string;
  access_token: string;
  match_id: string;
  phone_status: MacroDroidPhoneStatus | string;
  msg_code?: string;
  response_code?: number;
  timestamp?: number;
  room_id?: string;
  room_password?: string;
  open_ff_url?: string;
}

export type TransactionAction =
  | 'ADD'
  | 'REMOVE'
  | 'ENTRY'
  | 'REFUND'
  | 'PRIZE'
  | 'PENALTY'
  | 'ADD_ADMIN'
  | 'REMOVE_ADMIN'
  | 'CLAIM_TEST';

export interface CoinTransaction {
  txnId: string; // e.g. TXN-1021
  id?: string;
  guestId: string;
  adminEmail?: string;
  action: TransactionAction;
  type?: TransactionAction;
  amount: number;
  previousBalance: number;
  newBalance: number;
  balanceAfter?: number;
  reason: string;
  description?: string;
  createdAt: number;
}

export interface CoinNotification {
  id: string;
  guestId: string;
  amount: number;
  newBalance: number;
  message: string;
  createdAt: number;
  read: boolean;
}

export interface VerificationWorkerStatus {
  workerId: string;
  name: string;
  status: 'ONLINE' | 'OFFLINE' | 'PROCESSING';
  ocrEngine: string;
  confidenceThreshold: number;
  processedCount: number;
  lastActiveAt: number;
}
