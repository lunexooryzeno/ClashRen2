import React, { useState, useEffect } from 'react';
import {
  GameCategory,
  GameMode,
  GameName,
  EntryCardOption,
  GuestProfile,
  QueueItem,
  Match,
  FeedbackCategory,
} from './types';
import { LandingPage } from './components/LandingPage';
import { GuestOnboarding } from './components/GuestOnboarding';
import { Navbar } from './components/Navbar';
import { HomeScreen } from './components/HomeScreen';
import { MatchmakingQueueModal } from './components/MatchmakingQueueModal';
import { OpponentFoundScreen } from './components/OpponentFoundScreen';
import { RoomReadyScreen } from './components/RoomReadyScreen';
import { InGameView } from './components/InGameView';
import { DisputeModal } from './components/DisputeModal';
import { WalletModal } from './components/WalletModal';
import { FeedbackModal } from './components/FeedbackModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { AdminPanel } from './components/AdminPanel';
import { AddCoinsModal } from './components/AddCoinsModal';
import { InsufficientCoinsModal } from './components/InsufficientCoinsModal';
import { CoinNotificationToast } from './components/CoinNotificationToast';

type ScreenState = 'LANDING' | 'ONBOARDING' | 'MAIN';

export default function App() {
  const [screen, setScreen] = useState<ScreenState>('LANDING');
  const [guestProfile, setGuestProfile] = useState<GuestProfile | null>(null);
  const [activePlayers, setActivePlayers] = useState<number>(1);
  const [queueItem, setQueueItem] = useState<QueueItem | null>(null);
  const [activeMatch, setActiveMatch] = useState<Match | null>(null);
  const [isLoadingOnboarding, setIsLoadingOnboarding] = useState<boolean>(false);

  // Modals state
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isDisputeOpen, setIsDisputeOpen] = useState(false);
  const [isAddCoinsOpen, setIsAddCoinsOpen] = useState(false);
  const [isInsufficientCoinsOpen, setIsInsufficientCoinsOpen] = useState(false);
  const [insufficientRequiredFee, setInsufficientRequiredFee] = useState(10);
  const [coinNotification, setCoinNotification] = useState<{ amount: number; newBalance: number } | null>(null);
  const [isVerificationMinimized, setIsVerificationMinimized] = useState(false);

  // On initial mount: restore stored guest ID if available and check for /admin route
  useEffect(() => {
    const savedGuestId = localStorage.getItem('clashren_guest_id');
    if (savedGuestId) {
      fetchGuestProfile(savedGuestId);
    }
    fetchActivePlayers();

    const checkAdminRoute = () => {
      if (window.location.pathname === '/admin' || window.location.hash === '#admin') {
        setIsAdminOpen(true);
      }
    };

    checkAdminRoute();
    window.addEventListener('popstate', checkAdminRoute);
    window.addEventListener('hashchange', checkAdminRoute);

    const interval = setInterval(fetchActivePlayers, 5000);
    return () => {
      clearInterval(interval);
      window.removeEventListener('popstate', checkAdminRoute);
      window.removeEventListener('hashchange', checkAdminRoute);
    };
  }, []);

  const handleOpenAdmin = () => {
    setIsAdminOpen(true);
    if (window.location.pathname !== '/admin') {
      window.history.pushState({}, '', '/admin');
    }
  };

  const handleCloseAdmin = () => {
    setIsAdminOpen(false);
    if (window.location.pathname === '/admin') {
      window.history.pushState({}, '', '/');
    }
  };

  // Poll matchmaking / active match status when in main view
  useEffect(() => {
    const guestId = guestProfile?.guestId;
    if (!guestId || screen !== 'MAIN') return;

    const pollStatus = async () => {
      try {
        const res = await fetch(`/api/matchmaking/status/${guestId}`);
        if (!res.ok) return;
        const data = await res.json();

        if (data.state === 'SEARCHING' && data.queueItem) {
          setQueueItem(data.queueItem);
          setActiveMatch(null);
        } else if ((data.state === 'MATCHED' || data.state === 'ENDED') && data.match) {
          setQueueItem(null);
          setActiveMatch(data.match);
        } else {
          setQueueItem(null);
          setActiveMatch((prevMatch) => {
            if (prevMatch && (prevMatch.status === 'FINALIZED' || prevMatch.status === 'CANCELLED')) {
              return prevMatch;
            }
            return null;
          });
        }

        // Refresh profile coins & check unread coin notifications
        const notifRes = await fetch(`/api/guest/${guestId}/notifications`);
        if (notifRes.ok) {
          const unreadNotifs = await notifRes.json();
          if (Array.isArray(unreadNotifs) && unreadNotifs.length > 0) {
            const latest = unreadNotifs[unreadNotifs.length - 1];
            setCoinNotification({
              amount: latest.amount,
              newBalance: latest.newBalance,
            });
          }
        }

        const profRes = await fetch(`/api/guest/${guestId}`);
        if (profRes.ok) {
          const updated = await profRes.json();
          setGuestProfile((prev) => {
            if (!prev) return updated;
            if (
              prev.coins === updated.coins &&
              prev.pendingCoins === updated.pendingCoins &&
              prev.withdrawableCoins === updated.withdrawableCoins &&
              prev.wins === updated.wins &&
              prev.losses === updated.losses
            ) {
              return prev;
            }
            return updated;
          });
        }
      } catch (err) {
        // Silently handle transient network fetch errors during background polling
      }
    };

    pollStatus();
    const intervalTime = (activeMatch || queueItem) ? 1000 : 2000;
    const interval = setInterval(pollStatus, intervalTime);
    return () => clearInterval(interval);
  }, [guestProfile?.guestId, screen, !!activeMatch, !!queueItem]);

  const fetchActivePlayers = async () => {
    try {
      const savedGid = localStorage.getItem('clashren_guest_id');
      const gid = guestProfile?.guestId || savedGid;
      const q = gid ? `?guestId=${encodeURIComponent(gid)}` : '';
      const res = await fetch(`/api/active-players${q}`);
      if (!res.ok) return;
      const data = await res.json();
      const count = typeof data.activePlayers === 'number' && data.activePlayers > 0 ? data.activePlayers : 1;
      setActivePlayers(count);
    } catch (err) {
      // Silently handle transient fetch errors
    }
  };

  const fetchGuestProfile = async (guestId: string) => {
    try {
      const res = await fetch('/api/guest/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ existingGuestId: guestId }),
      });
      if (res.ok) {
        const data = await res.json();
        setGuestProfile(data);
        localStorage.setItem('clashren_guest_id', data.guestId);
        setScreen('MAIN');
      }
    } catch (err) {
      console.error('Error onboarding guest', err);
    }
  };

  const handleContinueAsGuest = async () => {
    setIsLoadingOnboarding(true);
    try {
      const res = await fetch('/api/guest/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      setGuestProfile(data);
      localStorage.setItem('clashren_guest_id', data.guestId);
      setScreen('MAIN');
    } catch (err) {
      console.error('Error onboarding guest', err);
    } finally {
      setIsLoadingOnboarding(false);
    }
  };

  const handleFindOpponent = async (
    category: GameCategory,
    mode: GameMode,
    game: GameName,
    entryCard: EntryCardOption
  ) => {
    if (!guestProfile) return;

    if (guestProfile.coins < entryCard.entryFee) {
      setInsufficientRequiredFee(entryCard.entryFee);
      setIsInsufficientCoinsOpen(true);
      return;
    }

    try {
      const res = await fetch('/api/matchmaking/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestId: guestProfile.guestId,
          category,
          mode,
          game,
          entryFee: entryCard.entryFee,
          prize: entryCard.prize,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        if (errData.code === 'INSUFFICIENT_COINS') {
          setInsufficientRequiredFee(entryCard.entryFee);
          setIsInsufficientCoinsOpen(true);
        } else {
          alert(errData.error || 'Failed to enter queue');
        }
        return;
      }

      const data = await res.json();
      setQueueItem(data.queueItem);

      // Refresh coins
      const profRes = await fetch(`/api/guest/${guestProfile.guestId}`);
      if (profRes.ok) {
        setGuestProfile(await profRes.json());
      }
    } catch (err) {
      console.error('Find opponent error', err);
    }
  };

  const handleCancelQueue = async () => {
    if (!guestProfile) return;
    try {
      await fetch('/api/matchmaking/leave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guestId: guestProfile.guestId }),
      });
      setQueueItem(null);

      const profRes = await fetch(`/api/guest/${guestProfile.guestId}`);
      if (profRes.ok) {
        setGuestProfile(await profRes.json());
      }
    } catch (err) {
      console.error('Cancel queue error', err);
    }
  };

  const handleRoomTimerExpired = async () => {
    if (!guestProfile || !activeMatch) return;
    setActiveMatch((prev) => (prev ? { ...prev, status: 'IN_GAME' } : null));
    try {
      await fetch(`/api/matches/${activeMatch.matchId}/close-room`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch (err) {
      console.error('Room timer expire error', err);
    }
  };

  const handleSubmitVictoryScreenshot = async (screenshotUrl: string, screenshotData?: string) => {
    if (!guestProfile || !activeMatch) return;
    try {
      const res = await fetch(`/api/matches/${activeMatch.matchId}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestId: guestProfile.guestId,
          screenshotUrl,
          screenshotData: screenshotData || screenshotUrl,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.match) {
          setActiveMatch(data.match);
        } else {
          setActiveMatch((prev) =>
            prev
              ? {
                  ...prev,
                  status: 'RESULT_VERIFICATION',
                  claimedWinnerId: guestProfile.guestId,
                  screenshotUrl: data.tempScreenshotUrl || screenshotUrl,
                }
              : null
          );
        }
      }
    } catch (err) {
      console.error('Verify error', err);
    }
  };

  const handleAcceptResult = async () => {
    if (!guestProfile || !activeMatch) return;
    try {
      await fetch(`/api/matches/${activeMatch.matchId}/dispute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guestId: guestProfile.guestId, action: 'ACCEPT' }),
      });
    } catch (err) {
      console.error('Accept result error', err);
    }
  };

  const handleSubmitDispute = async (reason: string, screenshotUrl?: string) => {
    if (!guestProfile || !activeMatch) return;
    try {
      await fetch(`/api/matches/${activeMatch.matchId}/dispute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestId: guestProfile.guestId,
          action: 'DISPUTE',
          reason,
          screenshotUrl,
        }),
      });
      setIsDisputeOpen(false);
    } catch (err) {
      console.error('Dispute error', err);
    }
  };

  const handleClaimCoins = async (amount: number) => {
    if (!guestProfile) return;
    try {
      const res = await fetch('/api/guest/claim-coins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guestId: guestProfile.guestId, amount }),
      });
      if (res.ok) {
        const profRes = await fetch(`/api/guest/${guestProfile.guestId}`);
        if (profRes.ok) {
          setGuestProfile(await profRes.json());
        }
      }
    } catch (err) {
      console.error('Claim coins error', err);
    }
  };

  const handleSubmitFeedback = async (
    category: FeedbackCategory,
    description: string,
    screenshotUrl?: string,
    experienceRating?: 'Excellent' | 'Good' | 'Average' | 'Poor' | 'Very Poor'
  ) => {
    if (!guestProfile) return;
    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestId: guestProfile.guestId,
          matchId: activeMatch?.matchId,
          category,
          description,
          screenshotUrl,
          experienceRating,
        }),
      });
    } catch (err) {
      console.error('Feedback error', err);
    }
  };

  const handleResetIdentity = () => {
    localStorage.removeItem('clashren_guest_id');
    setGuestProfile(null);
    setScreen('LANDING');
    setIsSettingsOpen(false);
  };

  // Render view router based on screen state
  if (screen === 'LANDING') {
    return (
      <LandingPage
        onGetStarted={() => setScreen('ONBOARDING')}
        onOpenFeedback={() => setIsFeedbackOpen(true)}
      />
    );
  }

  if (screen === 'ONBOARDING') {
    return (
      <GuestOnboarding
        onContinueAsGuest={handleContinueAsGuest}
        onBack={() => setScreen('LANDING')}
        isLoading={isLoadingOnboarding}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Navigation Bar */}
      {guestProfile && (
        <Navbar
          coins={guestProfile.coins}
          activePlayers={activePlayers}
          guestId={guestProfile.guestId}
          onOpenWallet={() => setIsWalletOpen(true)}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenAdmin={handleOpenAdmin}
          onOpenFeedback={() => setIsFeedbackOpen(true)}
        />
      )}

      {/* Main Content Router */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-2 sm:p-4">
        {/* State 0: Blocked Guest Account Notice */}
        {guestProfile?.isBlocked ? (
          <div className="max-w-md mx-auto my-8 bg-slate-900 border border-red-500/40 rounded-3xl p-6 sm:p-8 space-y-6 text-center shadow-2xl relative">
            <div className="w-16 h-16 rounded-full bg-red-500/20 border border-red-500/30 text-red-400 flex items-center justify-center mx-auto">
              <span className="text-3xl">⚠️</span>
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-black text-white">Account Temporarily Restricted</h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                Your ClashRen account has been temporarily restricted due to a match verification dispute.
              </p>
            </div>

            <div className="bg-red-950/40 border border-red-500/30 rounded-2xl p-4 text-left space-y-1">
              <span className="text-[10px] uppercase font-bold text-red-300 tracking-wider block">
                Restriction Details:
              </span>
              <p className="text-xs font-semibold text-slate-200">
                Reason: {guestProfile.blockReason || 'Result verification under admin review.'}
              </p>
              {guestProfile.violationCount && (
                <p className="text-[11px] text-red-300">
                  Recorded Violations: {guestProfile.violationCount}
                </p>
              )}
            </div>

            <div className="space-y-3 pt-2">
              <a
                href="https://wa.me/919999999999?text=Hello%20ClashRen%20Admin,%20my%20account%20is%20restricted."
                target="_blank"
                rel="noreferrer"
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <span>Contact Admin on WhatsApp</span>
              </a>
              <button
                onClick={() => setIsFeedbackOpen(true)}
                className="w-full py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
              >
                Send Feedback
              </button>
            </div>
          </div>
        ) : activeMatch && !isVerificationMinimized ? (
          /* State 1: Active Match view taking precedence */
          <div className="space-y-4">
            {activeMatch.status === 'WAITING_FOR_ROOM' || activeMatch.status === 'ROOM_CREATING' ? (
              <OpponentFoundScreen match={activeMatch} profile={guestProfile!} />
            ) : activeMatch.status === 'ROOM_READY' &&
              activeMatch.roomCredentials &&
              activeMatch.roomCredentials.joinWindowExpiresAt > Date.now() ? (
              <RoomReadyScreen
                match={activeMatch}
                profile={guestProfile!}
                onRoomTimerExpired={handleRoomTimerExpired}
                onMinimize={() => setIsVerificationMinimized(true)}
              />
            ) : (
              <InGameView
                match={activeMatch}
                profile={guestProfile!}
                onSubmitVictoryScreenshot={handleSubmitVictoryScreenshot}
                onAcceptResult={handleAcceptResult}
                onOpenDisputeModal={() => setIsDisputeOpen(true)}
                onOpenFeedback={() => setIsFeedbackOpen(true)}
                onMinimize={() => setIsVerificationMinimized(true)}
                onCloseMatch={async () => {
                  if (activeMatch && guestProfile) {
                    const matchId = activeMatch.matchId;
                    setActiveMatch(null);
                    setIsVerificationMinimized(false);
                    try {
                      await fetch(`/api/matches/${matchId}/dismiss`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ guestId: guestProfile.guestId }),
                      });
                    } catch (err) {
                      console.error('Failed to dismiss match:', err);
                    }
                  } else {
                    setActiveMatch(null);
                    setIsVerificationMinimized(false);
                  }
                }}
              />
            )}
          </div>
        ) : (
          /* State 2: Default Home Match Selection Screen */
          guestProfile && (
            <HomeScreen
              profile={guestProfile}
              onFindOpponent={handleFindOpponent}
              onOpenFeedback={() => setIsFeedbackOpen(true)}
            />
          )
        )}
      </main>

      {/* Minimized Match Result Verification Floating Banner */}
      {activeMatch && isVerificationMinimized && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 max-w-md w-[92%] bg-slate-900/95 border border-amber-500/50 backdrop-blur-md rounded-2xl p-3.5 shadow-2xl flex items-center justify-between cursor-pointer hover:border-amber-400 transition-all group"
             onClick={() => setIsVerificationMinimized(false)}
        >
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-amber-400 animate-ping" />
            <div>
              <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block">
                MINIMIZED MATCH RESULT
              </span>
              <p className="text-xs font-bold text-white font-mono">
                Pending Match Result (Match ID: {activeMatch.matchId})
              </p>
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsVerificationMinimized(false);
            }}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md cursor-pointer transition-all"
          >
            Click to Resume
          </button>
        </div>
      )}

      {/* Queue Modal overlay */}
      {queueItem && guestProfile && (
        <MatchmakingQueueModal
          queueItem={queueItem}
          profile={guestProfile}
          onCancelQueue={handleCancelQueue}
        />
      )}

      {/* Wallet Modal */}
      {isWalletOpen && guestProfile && (
        <WalletModal
          profile={guestProfile}
          onClose={() => setIsWalletOpen(false)}
          onOpenAddCoins={() => {
            setIsWalletOpen(false);
            setIsAddCoinsOpen(true);
          }}
        />
      )}

      {/* Profile Modal */}
      {isProfileOpen && guestProfile && (
        <ProfileModal
          profile={guestProfile}
          onClose={() => setIsProfileOpen(false)}
          onOpenWallet={() => {
            setIsProfileOpen(false);
            setIsWalletOpen(true);
          }}
          onOpenAddCoins={() => {
            setIsProfileOpen(false);
            setIsAddCoinsOpen(true);
          }}
        />
      )}

      {/* Add Coins Modal */}
      {isAddCoinsOpen && guestProfile && (
        <AddCoinsModal
          guestId={guestProfile.guestId}
          currentCoins={guestProfile.coins}
          onClose={() => setIsAddCoinsOpen(false)}
        />
      )}

      {/* Insufficient Coins Modal */}
      {isInsufficientCoinsOpen && guestProfile && (
        <InsufficientCoinsModal
          currentCoins={guestProfile.coins}
          requiredCoins={insufficientRequiredFee}
          onClose={() => setIsInsufficientCoinsOpen(false)}
          onOpenAddCoins={() => {
            setIsInsufficientCoinsOpen(false);
            setIsAddCoinsOpen(true);
          }}
        />
      )}

      {/* Real-time Coin Added Toast Notification */}
      {coinNotification && (
        <CoinNotificationToast
          amount={coinNotification.amount}
          newBalance={coinNotification.newBalance}
          onClose={() => setCoinNotification(null)}
        />
      )}

      {/* Settings Modal */}
      {isSettingsOpen && guestProfile && (
        <SettingsModal
          guestId={guestProfile.guestId}
          onClose={() => setIsSettingsOpen(false)}
          onResetIdentity={handleResetIdentity}
          onOpenFeedback={() => setIsFeedbackOpen(true)}
        />
      )}

      {/* Feedback Modal */}
      {isFeedbackOpen && guestProfile && (
        <FeedbackModal
          profile={guestProfile}
          matchId={activeMatch?.matchId}
          onClose={() => setIsFeedbackOpen(false)}
          onSubmitFeedback={handleSubmitFeedback}
        />
      )}

      {/* Dispute Modal */}
      {isDisputeOpen && activeMatch && guestProfile && (
        <DisputeModal
          match={activeMatch}
          profile={guestProfile}
          onClose={() => setIsDisputeOpen(false)}
          onSubmitDispute={handleSubmitDispute}
        />
      )}

      {/* Admin Panel Modal */}
      {isAdminOpen && <AdminPanel onClose={handleCloseAdmin} />}
    </div>
  );
}
