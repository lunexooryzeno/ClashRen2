import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  GuestProfile,
  QueueItem,
  Match,
  MacroDroidStatusPayload,
  HostWorker,
  UserFeedback,
  MatchPayout,
  MacroDroidPhoneStatus,
  CoinTransaction,
  VerificationWorkerStatus,
  VerificationJob,
  VerificationResultPayload,
} from './src/types';
import { DEFAULT_HOST_WORKERS } from './src/data/mockData';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Server-only Admin Credentials (NEVER exposed to client)
const ADMIN_EMAIL = 'lunexo@admin.com';
const ADMIN_PASSWORD = 'HHL6XM47VDR9EVV8HT9R0C5';
const activeAdminTokens = new Set<string>();

// In-Memory Storage
const guests = new Map<string, GuestProfile>();
const queues: QueueItem[] = [];
const matches = new Map<string, Match>();
const workers = new Map<string, HostWorker>();
const feedbacks: UserFeedback[] = [];
const payouts = new Map<string, MatchPayout>();
const coinTransactions: CoinTransaction[] = [];
const coinNotifications: Array<{
  id: string;
  guestId: string;
  amount: number;
  newBalance: number;
  message: string;
  createdAt: number;
  read: boolean;
}> = [];

// Verification worker status
const verificationWorker: VerificationWorkerStatus = {
  workerId: 'VERIF-PHONE-01',
  name: 'OCR Victory Verification Worker',
  status: 'ONLINE',
  ocrEngine: 'Tesseract / Vision OCR v2.4',
  confidenceThreshold: 0.85,
  processedCount: 28,
  lastActiveAt: Date.now(),
};

// Record coin ledger transaction
function recordTransaction(
  guestId: string,
  action: CoinTransaction['action'],
  amount: number,
  previousBalance: number,
  newBalance: number,
  reason: string,
  adminEmail?: string
): CoinTransaction {
  const txnId = `TXN-${Math.floor(1000 + Math.random() * 9000)}`;
  const tx: CoinTransaction = {
    txnId,
    id: txnId,
    guestId,
    adminEmail,
    action,
    type: action,
    amount,
    previousBalance,
    newBalance,
    balanceAfter: newBalance,
    reason,
    description: reason,
    createdAt: Date.now(),
  };
  coinTransactions.unshift(tx);
  return tx;
}

// Admin Authentication Middleware
function requireAdminAuth(req: Request, res: Response, next: () => void) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7)
    : (req.headers['x-admin-token'] as string);

  if (!token || !activeAdminTokens.has(token)) {
    return res.status(401).json({ error: 'Unauthorized. Admin authentication required.' });
  }
  next();
}

// Initialize default workers
DEFAULT_HOST_WORKERS.forEach((w) => workers.set(w.workerId, w));

// Helper: Random string generators
function generateGuestId(): string {
  const chars = '0123456789ABCDEF';
  const p1 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const p2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `CR-${p1}-${p2}`;
}

function generateNickname(): string {
  const code = Math.floor(100000 + Math.random() * 900000).toString(16).toUpperCase().padStart(6, '0');
  return `Guest-${code}`;
}

function generateMatchId(): string {
  return `M-${Math.floor(1000 + Math.random() * 9000)}`;
}

function generateAccessToken(): string {
  return `TK_${Math.random().toString(36).substring(2, 10).toUpperCase()}_${Date.now()}`;
}

function generateRoomCredentials(): { roomId: string; roomPassword: string } {
  const roomId = Math.floor(10000000 + Math.random() * 90000000).toString();
  const roomPassword = Math.floor(1000 + Math.random() * 9000).toString();
  return { roomId, roomPassword };
}

// Dedicated Room Creation Job Queue
const roomJobQueue: string[] = [];
let activeRoomJobId: string | null = null;
let activeJobTimeoutTimer: NodeJS.Timeout | null = null;

// Check worker timeout (if no heartbeat for 15s)
setInterval(() => {
  const now = Date.now();
  workers.forEach((worker) => {
    if (now - worker.lastHeartbeatAt > 15000 && worker.status !== 'OFFLINE') {
      worker.status = 'OFFLINE';
      console.log(`Worker ${worker.workerId} marked OFFLINE due to 3 missed heartbeats (>15s)`);

      if (activeRoomJobId) {
        const activeMatch = matches.get(activeRoomJobId);
        if (activeMatch && activeMatch.workerId === worker.workerId && (activeMatch.status === 'ROOM_CREATING' || activeMatch.status === 'WAITING_FOR_ROOM')) {
          console.warn(`Cancelling match ${activeMatch.matchId} because host phone worker went OFFLINE`);
          refundPlayer(activeMatch.playerA.guestId, activeMatch.entryFee, 'Host phone worker offline');
          refundPlayer(activeMatch.playerB.guestId, activeMatch.entryFee, 'Host phone worker offline');
          activeMatch.status = 'CANCELLED';
          activeMatch.cancelReason = 'Host phone worker offline (no heartbeats received in 15 seconds)';

          if (activeJobTimeoutTimer) clearTimeout(activeJobTimeoutTimer);
          activeRoomJobId = null;
          processRoomQueue();
        }
      }
    }
  });
}, 5000);

// Auto-process queue & timeout expired room join windows
setInterval(() => {
  processQueue();
  checkJoinWindowTimeouts();
  checkDisputeWindowTimeouts();
}, 1000);

function processQueue() {
  if (queues.length < 2) return;

  // Group queue items by category + mode + game + entryFee (FIFO)
  const groups = new Map<string, QueueItem[]>();
  queues.forEach((item) => {
    if (item.state !== 'SEARCHING') return;
    const key = `${item.category}_${item.mode}_${item.game}_${item.entryFee}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(item);
  });

  groups.forEach((items) => {
    while (items.length >= 2) {
      const p1Item = items.shift()!;
      const p2Item = items.shift()!;

      // Remove both matched real players from main queue array
      const idx1 = queues.findIndex((q) => q.id === p1Item.id);
      if (idx1 !== -1) queues.splice(idx1, 1);
      const idx2 = queues.findIndex((q) => q.id === p2Item.id);
      if (idx2 !== -1) queues.splice(idx2, 1);

      createMatch(p1Item, p2Item);
    }
  });
}

function createMatch(p1Item: QueueItem, p2Item: QueueItem) {
  const playerA = guests.get(p1Item.guestId);
  const playerB = guests.get(p2Item.guestId);

  if (!playerA || !playerB) return;

  const matchId = generateMatchId();
  const accessToken = generateAccessToken();

  const newMatch: Match = {
    matchId,
    playerA,
    playerB,
    category: p1Item.category,
    mode: p1Item.mode,
    game: p1Item.game,
    entryFee: p1Item.entryFee,
    prize: p1Item.prize,
    status: 'WAITING_FOR_ROOM',
    createdAt: Date.now(),
    accessToken,
    workerId: 'host_phone_1',
    hostPhoneLogs: [
      {
        status: 'ready',
        timestamp: Date.now(),
        message: 'Opponent found! Added to room creation job queue.',
      },
    ],
  };

  matches.set(matchId, newMatch);

  // Queue room creation job
  roomJobQueue.push(matchId);
  processRoomQueue();
}

function processRoomQueue() {
  if (activeRoomJobId !== null) return; // Busy creating a room
  if (roomJobQueue.length === 0) return;

  const nextMatchId = roomJobQueue.shift()!;
  const match = matches.get(nextMatchId);

  if (!match || match.status === 'CANCELLED') {
    processRoomQueue();
    return;
  }

  activeRoomJobId = nextMatchId;
  match.status = 'ROOM_CREATING';
  match.hostPhoneLogs.push({
    status: 'ready',
    timestamp: Date.now(),
    message: 'Dispatching room creation job to MacroDroid host phone',
  });

  // Base MacroDroid webhook trigger URL
  const macroDroidBaseUrl = 'https://trigger.macrodroid.com/98315e1f-abce-4c9f-ab7d-87004928eb82/clashren';
  const triggerUrl = `${macroDroidBaseUrl}?game_mode=89UB&access_token=${encodeURIComponent(match.accessToken)}&match_id=${encodeURIComponent(match.matchId)}`;

  console.log(`[MacroDroid Webhook Dispatch] Match ${match.matchId} -> ${triggerUrl}`);

  fetch(triggerUrl)
    .then((res) => {
      console.log(`[MacroDroid Webhook HTTP ${res.status}] Trigger sent successfully for match ${match.matchId}`);
      if (!res.ok) {
        match.hostPhoneLogs.push({
          status: 'error',
          timestamp: Date.now(),
          message: `MacroDroid webhook responded with HTTP ${res.status}`,
        });
      }
    })
    .catch((err) => {
      console.error(`[MacroDroid Webhook Error] Failed to reach MacroDroid host phone for match ${match.matchId}:`, err);
      match.hostPhoneLogs.push({
        status: 'error',
        timestamp: Date.now(),
        message: `Network error connecting to MacroDroid webhook: ${err.message || 'Host phone unreachable'}`,
      });
    });

  // Safety Timeout: 90 seconds max per room job
  if (activeJobTimeoutTimer) clearTimeout(activeJobTimeoutTimer);
  activeJobTimeoutTimer = setTimeout(() => {
    if (activeRoomJobId === match.matchId) {
      console.warn(`[MacroDroid Timeout] Match ${match.matchId} timed out waiting for MacroDroid host phone`);
      match.hostPhoneLogs.push({
        status: 'error',
        timestamp: Date.now(),
        message: 'MacroDroid host phone creation timed out (90s without response)',
      });
      refundPlayer(match.playerA.guestId, match.entryFee, 'Host room creation timeout');
      refundPlayer(match.playerB.guestId, match.entryFee, 'Host room creation timeout');
      match.status = 'CANCELLED';
      match.cancelReason = 'MacroDroid host phone room creation timed out (90 seconds without response)';

      activeRoomJobId = null;
      processRoomQueue();
    }
  }, 90000);
}

function checkJoinWindowTimeouts() {
  const now = Date.now();
  matches.forEach((match) => {
    if (match.status === 'ROOM_READY' && match.roomCredentials) {
      if (now > match.roomCredentials.joinWindowExpiresAt) {
        match.status = 'IN_GAME';
        console.log(`[Match ${match.matchId}] Join window timer reached zero -> Transitioned match to IN_GAME for result verification.`);
      }
    }
  });
}

function checkDisputeWindowTimeouts() {
  const now = Date.now();
  matches.forEach((match) => {
    if (match.status === 'PENDING_VERIFICATION' && match.disputeWindowExpiresAt) {
      if (now > match.disputeWindowExpiresAt && !match.dispute) {
        // Auto finalize payout
        finalizePayout(match.matchId, match.claimedWinnerId || match.playerA.guestId);
      }
    }
  });
}

function refundPlayer(guestId: string, amount: number, reason: string = 'Match refund') {
  const guest = guests.get(guestId);
  if (guest) {
    const prevBal = guest.coins;
    guest.coins += amount;
    guest.withdrawableCoins += amount;
    recordTransaction(guestId, 'REFUND', amount, prevBal, guest.coins, reason);
  }
}

function finalizePayout(matchId: string, winnerGuestId: string) {
  const match = matches.get(matchId);
  if (!match) return;

  const payoutKey = `${matchId}_PAYOUT`;
  let payout = payouts.get(payoutKey);

  // Idempotency: Never credit if already FINALIZED
  if (payout && payout.state === 'FINALIZED') {
    console.log(`[PAYOUT BLOCKED] Payout for ${matchId} was already FINALIZED.`);
    return;
  }

  if (!payout) {
    payout = {
      payoutId: payoutKey,
      matchId,
      winnerGuestId,
      amount: match.prize,
      state: 'LOCKED',
      createdAt: Date.now(),
    };
    payouts.set(payoutKey, payout);
  }

  // Credit winner
  const winner = guests.get(winnerGuestId);
  if (winner) {
    const prevBal = winner.coins;
    winner.pendingCoins = Math.max(0, winner.pendingCoins - match.prize);
    winner.coins += match.prize;
    winner.withdrawableCoins += match.prize;
    winner.wins += 1;
    recordTransaction(winnerGuestId, 'PRIZE', match.prize, prevBal, winner.coins, `Match Victory Prize (${matchId})`);
  }

  // Record loss for loser
  const loserGuestId = winnerGuestId === match.playerA.guestId ? match.playerB.guestId : match.playerA.guestId;
  const loser = guests.get(loserGuestId);
  if (loser) {
    loser.losses += 1;
  }

  payout.state = 'FINALIZED';
  payout.finalizedAt = Date.now();

  match.status = 'FINALIZED';
  match.finalWinnerId = winnerGuestId;
  match.payout = payout;
}

// Background Worker: Auto-Finalize Pending Rewards after 30 minutes if no dispute
setInterval(() => {
  const now = Date.now();
  for (const match of matches.values()) {
    if (
      match.status === 'PENDING_VERIFICATION' &&
      match.pendingRewardExpiresAt &&
      now >= match.pendingRewardExpiresAt &&
      !match.dispute
    ) {
      console.log(`[Auto-Finalizing Pending Reward] Match ${match.matchId} reached 30 min timer without dispute.`);
      const winnerId = match.claimedWinnerId || match.playerA.guestId;
      finalizePayout(match.matchId, winnerId);
    }
  }
}, 5000);

// Active online sessions tracking (guestId or client IP -> lastSeen timestamp)
const onlineSessions = new Map<string, number>();

app.use((req: Request, res: Response, next) => {
  const guestId = (req.query.guestId || req.body?.guestId || req.headers['x-guest-id']) as string | undefined;
  const sessionKey = (guestId && typeof guestId === 'string' && !guestId.startsWith('BOT-'))
    ? guestId
    : `ip_${req.ip || 'client'}`;
  onlineSessions.set(sessionKey, Date.now());
  next();
});

// API Routes

// Active Players count (Real-time active online guest count based on heartbeats)
app.get('/api/active-players', (req: Request, res: Response) => {
  const paramGuestId = req.query.guestId as string | undefined;
  const sessionKey = (paramGuestId && typeof paramGuestId === 'string' && !paramGuestId.startsWith('BOT-'))
    ? paramGuestId
    : `ip_${req.ip || 'client'}`;
  
  onlineSessions.set(sessionKey, Date.now());

  const now = Date.now();
  const ACTIVE_THRESHOLD_MS = 30000; // 30s heartbeat window

  for (const [id, lastSeen] of onlineSessions.entries()) {
    if (now - lastSeen > ACTIVE_THRESHOLD_MS) {
      onlineSessions.delete(id);
    }
  }

  const activeCount = Math.max(onlineSessions.size, 1);
  res.json({ activePlayers: activeCount });
});

// Guest Onboarding
app.post('/api/guest/onboard', (req: Request, res: Response) => {
  const { existingGuestId } = req.body || {};

  if (existingGuestId && guests.has(existingGuestId)) {
    return res.json(guests.get(existingGuestId));
  }

  const guestId = generateGuestId();
  const nickname = generateNickname();

  const newProfile: GuestProfile = {
    guestId,
    nickname,
    coins: 0, // Default balance: 0 Coins
    pendingCoins: 0,
    lockedCoins: 0,
    withdrawableCoins: 0,
    trustScore: 100,
    matchesPlayed: 0,
    wins: 0,
    losses: 0,
    createdAt: Date.now(),
    isEnabled: true,
  };

  guests.set(guestId, newProfile);
  res.json(newProfile);
});

app.get('/api/guest/:id', (req: Request, res: Response) => {
  const profile = guests.get(req.params.id);
  if (!profile) return res.status(404).json({ error: 'Guest not found' });
  res.json(profile);
});

// Fetch unread real-time coin notifications for player
app.get('/api/guest/:id/notifications', (req: Request, res: Response) => {
  const guestId = req.params.id;
  const unread = coinNotifications.filter((n) => n.guestId === guestId && !n.read);
  unread.forEach((n) => (n.read = true));
  res.json(unread);
});

// Fetch transaction history for a player
app.get('/api/guest/:id/transactions', (req: Request, res: Response) => {
  const guestId = req.params.id;
  const guestTxs = coinTransactions.filter((tx) => tx.guestId === guestId);
  res.json(guestTxs);
});

// Claim test coins for prototype testing
app.post('/api/guest/claim-coins', (req: Request, res: Response) => {
  const { guestId, amount = 50 } = req.body;
  const guest = guests.get(guestId);
  if (!guest) return res.status(404).json({ error: 'Guest not found' });

  const numAmount = Number(amount);
  const prevBal = guest.coins;
  guest.coins += numAmount;
  guest.withdrawableCoins += numAmount;
  recordTransaction(guestId, 'CLAIM_TEST', numAmount, prevBal, guest.coins, 'Claimed Prototype Test Coins');
  res.json({ success: true, newCoins: guest.coins });
});

// Matchmaking: Join Queue
app.post('/api/matchmaking/join', (req: Request, res: Response) => {
  const { guestId, category = 'Clash Squad', mode = 'Solo', game = 'Clash Squad Normal', entryFee = 5, prize = 10 } = req.body;

  const guest = guests.get(guestId);
  if (!guest) return res.status(404).json({ error: 'Guest profile not found' });

  // 1. Check if suspended or blocked
  if (guest.isEnabled === false || guest.isBlocked) {
    return res.status(403).json({
      error: 'Account Temporarily Restricted',
      message: guest.blockReason || 'Your ClashRen account has been temporarily restricted due to a match verification dispute under admin review.',
      isBlocked: true,
      blockReason: guest.blockReason || 'Result verification under admin review.',
    });
  }

  // 2. Check coin balance
  if (guest.coins < entryFee) {
    return res.status(400).json({
      error: 'Insufficient coins. Please add coins via WhatsApp admin.',
      code: 'INSUFFICIENT_COINS',
      requiredCoins: entryFee,
      availableCoins: guest.coins,
    });
  }

  // 3. Check if already in queue
  const existingIndex = queues.findIndex((q) => q.guestId === guestId && q.state === 'SEARCHING');
  if (existingIndex !== -1) {
    return res.json({ success: true, queueItem: queues[existingIndex] });
  }

  // 4. Check if already in an active match
  const inActiveMatch = Array.from(matches.values()).some(
    (m) =>
      (m.playerA.guestId === guestId || m.playerB.guestId === guestId) &&
      m.status !== 'FINALIZED' &&
      m.status !== 'CANCELLED'
  );
  if (inActiveMatch) {
    return res.status(400).json({ error: 'Player is already in an active match.' });
  }

  // Deduct entry fee immediately
  const prevBal = guest.coins;
  guest.coins -= entryFee;
  guest.withdrawableCoins = Math.max(0, guest.withdrawableCoins - entryFee);
  recordTransaction(guestId, 'ENTRY', -entryFee, prevBal, guest.coins, `Matchmaking Entry Fee (${category} ${mode} ${entryFee} Coins)`);

  const queueItem: QueueItem = {
    id: `Q-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    guestId,
    nickname: guest.nickname,
    category,
    mode,
    game,
    entryFee,
    prize,
    joinedAt: Date.now(),
    state: 'SEARCHING',
  };

  queues.push(queueItem);

  // Trigger FIFO queue pairing immediately
  processQueue();

  res.json({ success: true, queueItem });
});

// Matchmaking: Cancel / Leave Queue
app.post('/api/matchmaking/leave', (req: Request, res: Response) => {
  const { guestId } = req.body;
  const qIdx = queues.findIndex((q) => q.guestId === guestId && q.state === 'SEARCHING');

  if (qIdx !== -1) {
    const item = queues[qIdx];
    queues.splice(qIdx, 1);
    refundPlayer(guestId, item.entryFee, 'Cancelled matchmaking queue');
  }

  res.json({ success: true });
});

// Dismiss match from client polling
app.post('/api/matches/:id/dismiss', (req: Request, res: Response) => {
  const { id } = req.params;
  const { guestId } = req.body || {};
  const match = matches.get(id);

  if (match && guestId) {
    match.dismissedBy = match.dismissedBy || [];
    if (!match.dismissedBy.includes(guestId)) {
      match.dismissedBy.push(guestId);
    }
  }

  res.json({ success: true });
});

// Matchmaking: Poll status
app.get('/api/matchmaking/status/:guestId', (req: Request, res: Response) => {
  const { guestId } = req.params;

  // Check if active match exists
  const activeMatch = Array.from(matches.values()).find(
    (m) =>
      (m.playerA.guestId === guestId || m.playerB.guestId === guestId) &&
      m.status !== 'FINALIZED' &&
      m.status !== 'CANCELLED' &&
      !m.dismissedBy?.includes(guestId)
  );

  if (activeMatch) {
    return res.json({ state: 'MATCHED', match: activeMatch });
  }

  // Check if there is an ended or cancelled match recently that has NOT been dismissed by this player
  const recentEndedMatch = Array.from(matches.values()).find(
    (m) =>
      (m.playerA.guestId === guestId || m.playerB.guestId === guestId) &&
      (m.status === 'FINALIZED' || m.status === 'CANCELLED') &&
      !m.dismissedBy?.includes(guestId)
  );

  if (recentEndedMatch && Date.now() - recentEndedMatch.createdAt < 300000) {
    return res.json({ state: 'ENDED', match: recentEndedMatch });
  }

  const inQueue = queues.find((q) => q.guestId === guestId && q.state === 'SEARCHING');
  if (inQueue) {
    return res.json({ state: 'SEARCHING', queueItem: inQueue });
  }

  res.json({ state: 'IDLE' });
});

// Helper to parse incoming MacroDroid payload regardless of string/JSON/query format
function parseBodyPayload(req: Request): Record<string, any> {
  let bodyObj: Record<string, any> = {};
  if (req.body) {
    if (typeof req.body === 'object' && req.body !== null) {
      bodyObj = req.body;
    } else if (typeof req.body === 'string') {
      const trimmed = req.body.trim();
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        try {
          bodyObj = JSON.parse(trimmed);
        } catch (e) {
          // Fallback if not valid JSON
        }
      }
    }
  }
  return { ...req.query, ...bodyObj };
}

// MacroDroid Webhook Response Handler
const handleHostStatus = (req: Request, res: Response) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const payload = parseBodyPayload(req);
  console.log('[MacroDroid Webhook Status Received]', { method: req.method, payload, headers: req.headers });

  const {
    worker_id,
    access_token,
    accessToken,
    verification_token,
    verificationToken,
    token,
    match_id,
    matchId,
    id,
    phone_status,
    phoneStatus,
    msg_code,
    msgCode,
    status,
    response_code,
    responseCode,
    room_id,
    roomId,
    RoomID,
    room,
    room_code,
    room_no,
    room_password,
    roomPassword,
    RoomPassword,
    password,
    pass,
    room_pass,
    pwd,
    pin,
    open_ff_url,
    openFfUrl,
    url,
    error_message,
    errorMessage,
  } = payload;

  const effectiveMatchId = (match_id || matchId || id || '').toString().trim();
  const effectiveToken = (access_token || accessToken || verification_token || verificationToken || token || '').toString().trim();

  // Robust Match Lookup:
  // 1. By matchId if explicit and not macro placeholder
  let match = (effectiveMatchId && !effectiveMatchId.includes('{v=')) ? matches.get(effectiveMatchId) : undefined;

  // 2. By accessToken if explicit and not macro placeholder
  if (!match && effectiveToken && !effectiveToken.includes('{v=')) {
    match = Array.from(matches.values()).find((m) => m.accessToken === effectiveToken);
  }

  // 3. By currently active room creation job ID
  if (!match && activeRoomJobId) {
    match = matches.get(activeRoomJobId);
  }

  // 4. By any match currently in ROOM_CREATING state
  if (!match) {
    match = Array.from(matches.values()).find((m) => m.status === 'ROOM_CREATING');
  }

  // 5. Fallback: Most recent match in ROOM_READY, ROOM_CREATING, or WAITING_FOR_ROOM
  if (!match) {
    match = Array.from(matches.values()).reverse().find((m) => 
      m.status === 'ROOM_READY' || m.status === 'ROOM_CREATING' || m.status === 'WAITING_FOR_ROOM'
    );
  }

  if (!match) {
    console.warn('[MacroDroid Status Warning] No match found for payload', payload);
    return res.status(404).json({ error: 'Match not found for provided token or ID' });
  }

  // Validate Access Token if provided and match has accessToken
  if (effectiveToken && match.accessToken && match.accessToken !== effectiveToken && !effectiveToken.includes('{v=')) {
    console.warn(`[MacroDroid Security Warning] Access token mismatch for match ${match.matchId}. Expected ${match.accessToken}, got ${effectiveToken}`);
  }

  const rawStatus = (phone_status || phoneStatus || msg_code || msgCode || status || '').toString().trim();
  const lowerRawStatus = rawStatus.toLowerCase();

  // Extract open_ff_url with all possible field name aliases
  const ffUrl = 
    open_ff_url || 
    openFfUrl || 
    url || 
    payload.ff_url || 
    payload.free_fire_url || 
    payload.open_url || 
    payload.game_url || 
    payload.ffUrl || 
    payload.link || 
    match.openFfUrl || 
    "intent://#Intent;package=com.dts.freefireth;end";

  match.openFfUrl = ffUrl;

  // Extract room_id and room_password with all possible field name aliases
  const rawRoomId = room_id ?? roomId ?? RoomID ?? room ?? room_code ?? room_no ?? payload.ROOM_ID ?? payload.rm_id ?? payload.roomid ?? payload.roomNo;
  const rawRoomPass = room_password ?? roomPassword ?? RoomPassword ?? password ?? pass ?? room_pass ?? pwd ?? pin ?? payload.ROOM_PASSWORD ?? payload.roompass;

  const strRoomId = (rawRoomId !== undefined && rawRoomId !== null) ? String(rawRoomId).trim() : '';
  const hasExplicitRoomId = strRoomId !== '' && !strRoomId.includes('{v=') && strRoomId.toLowerCase() !== 'null' && strRoomId.toLowerCase() !== 'undefined';

  // Keep worker status ONLINE & update heartbeat timestamp
  const targetWorkerId = String(worker_id || match.workerId || 'host_phone_1');
  let worker = workers.get(targetWorkerId);
  if (!worker) {
    worker = {
      workerId: targetWorkerId,
      name: `MacroDroid FF Host (${targetWorkerId})`,
      webhookUrl: 'https://trigger.macrodroid.com/98315e1f-abce-4c9f-ab7d-87004928eb82/clashren',
      status: 'ONLINE',
      battery: 90,
      internet: '5G',
      lastHeartbeatAt: Date.now(),
      isEnabled: true,
    };
    workers.set(targetWorkerId, worker);
  } else {
    worker.status = 'ONLINE';
    worker.lastHeartbeatAt = Date.now();
  }

  let mappedStatus: MacroDroidPhoneStatus = 'ready';
  let friendlyMsg = rawStatus || 'Host phone status update';

  if (lowerRawStatus.includes('ready')) {
    mappedStatus = 'ready';
  } else if (lowerRawStatus.includes('launch')) {
    mappedStatus = 'launching_game';
  } else if (lowerRawStatus.includes('switch') || lowerRawStatus.includes('account')) {
    mappedStatus = 'switching_account';
  } else if (lowerRawStatus.includes('open') || lowerRawStatus.includes('menu')) {
    mappedStatus = 'opening_room_menu';
  } else if (lowerRawStatus.includes('config')) {
    mappedStatus = 'configuring_room';
  } else if (lowerRawStatus.includes('creat') && !lowerRawStatus.includes('created')) {
    mappedStatus = 'creating_room';
  } else if (lowerRawStatus.includes('created') || lowerRawStatus.includes('done') || lowerRawStatus.includes('success')) {
    mappedStatus = 'room_created';
  } else if (lowerRawStatus.includes('error') || response_code === 500 || responseCode === 500) {
    mappedStatus = 'error';
    friendlyMsg = error_message || errorMessage || 'Host phone encountered an error creating room';
  }

  if (hasExplicitRoomId) {
    mappedStatus = 'room_created';
  }

  match.hostPhoneLogs.push({
    status: mappedStatus,
    timestamp: Date.now(),
    message: friendlyMsg,
  });

  const isRoomCreatedSignal = 
    mappedStatus === 'room_created' || 
    lowerRawStatus.includes('created') || 
    lowerRawStatus.includes('done') || 
    lowerRawStatus.includes('success') || 
    hasExplicitRoomId;

  if (isRoomCreatedSignal) {
    let finalRoomId: string;
    let finalRoomPass: string;

    if (hasExplicitRoomId) {
      finalRoomId = strRoomId;
      const strRoomPass = (rawRoomPass !== undefined && rawRoomPass !== null) ? String(rawRoomPass).trim() : '';
      finalRoomPass = (strRoomPass !== '' && !strRoomPass.includes('{v=')) ? strRoomPass : '1234';
    } else {
      finalRoomId = match.roomCredentials?.roomId || Math.floor(10000000 + Math.random() * 90000000).toString();
      finalRoomPass = match.roomCredentials?.roomPassword || Math.floor(1000 + Math.random() * 9000).toString();
    }

    match.roomCredentials = {
      roomId: finalRoomId,
      roomPassword: finalRoomPass,
      createdAt: match.roomCredentials?.createdAt || Date.now(),
      joinWindowExpiresAt: Date.now() + 300000, // 5 minutes join window
      openFfUrl: ffUrl,
    };
    match.status = 'ROOM_READY';
    match.latestPhoneStatus = rawStatus ? `${rawStatus} (ID: ${finalRoomId})` : `Room Created (ID: ${finalRoomId})`;
    match.playerAJoin = match.playerAJoin || { guestId: match.playerA.guestId, joined: false };
    match.playerBJoin = match.playerBJoin || { guestId: match.playerB.guestId, joined: false };

    console.log(`[MacroDroid Room Created Success] Match ${match.matchId} -> Room ID: ${finalRoomId}, Pass: ${finalRoomPass}, URL: ${ffUrl}`);

    if (activeJobTimeoutTimer) clearTimeout(activeJobTimeoutTimer);
    activeRoomJobId = null;
    processRoomQueue();
  } else if (mappedStatus === 'error') {
    refundPlayer(match.playerA.guestId, match.entryFee, `Room creation failed: ${friendlyMsg}`);
    refundPlayer(match.playerB.guestId, match.entryFee, `Room creation failed: ${friendlyMsg}`);
    match.status = 'CANCELLED';
    match.cancelReason = `Host phone error: ${friendlyMsg}`;

    if (activeJobTimeoutTimer) clearTimeout(activeJobTimeoutTimer);
    activeRoomJobId = null;
    processRoomQueue();
  } else {
    // Progress status update (e.g., "Configuring Room", "Opening Game")
    match.latestPhoneStatus = rawStatus || friendlyMsg;
    console.log(`[MacroDroid Progress Update] Match ${match.matchId} -> Phone Status: ${match.latestPhoneStatus}`);
  }

  res.json({
    success: true,
    matchId: match.matchId,
    matchStatus: match.status,
    phoneStatus: match.latestPhoneStatus,
    roomCredentials: match.roomCredentials || null,
    match,
  });
};

app.post('/api/workers/host/status', handleHostStatus);
app.get('/api/workers/host/status', handleHostStatus);

// Endpoint to manually set or override Room Credentials
app.post('/api/matches/:id/credentials', (req: Request, res: Response) => {
  const { id } = req.params;
  const { roomId, roomPassword, openFfUrl } = req.body || {};
  const match = matches.get(id);
  if (!match) return res.status(404).json({ error: 'Match not found' });

  const finalRoomId = String(roomId || '').trim() || match.roomCredentials?.roomId || Math.floor(10000000 + Math.random() * 90000000).toString();
  const finalRoomPass = String(roomPassword || '').trim() || match.roomCredentials?.roomPassword || Math.floor(1000 + Math.random() * 9000).toString();
  const finalUrl = openFfUrl || match.openFfUrl || "intent://#Intent;package=com.dts.freefireth;end";

  match.roomCredentials = {
    roomId: finalRoomId,
    roomPassword: finalRoomPass,
    createdAt: Date.now(),
    joinWindowExpiresAt: Date.now() + 300000,
    openFfUrl: finalUrl,
  };
  match.status = 'ROOM_READY';
  match.latestPhoneStatus = `Room Ready (ID: ${finalRoomId})`;
  match.playerAJoin = match.playerAJoin || { guestId: match.playerA.guestId, joined: false };
  match.playerBJoin = match.playerBJoin || { guestId: match.playerB.guestId, joined: false };

  res.json({ success: true, match });
});

// Worker Heartbeat Handler
const handleWorkerHeartbeat = (req: Request, res: Response) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const payload = parseBodyPayload(req);
  const {
    worker_id = 'host_phone_1',
    phone_status,
    battery,
    internet,
    current_match_id,
    response_code,
    timestamp,
  } = payload;

  let worker = workers.get(String(worker_id));
  if (!worker) {
    worker = {
      workerId: String(worker_id),
      name: `MacroDroid FF Host (${worker_id})`,
      webhookUrl: 'https://trigger.macrodroid.com/98315e1f-abce-4c9f-ab7d-87004928eb82/clashren',
      status: 'ONLINE',
      battery: typeof battery === 'number' ? battery : (parseInt(String(battery)) || 90),
      internet: internet ? '5G' : 'WIFI',
      lastHeartbeatAt: Date.now(),
      isEnabled: true,
    };
    workers.set(String(worker_id), worker);
  } else {
    worker.battery = typeof battery === 'number' ? battery : (parseInt(String(battery)) || worker.battery);
    worker.internet = internet ? '5G' : worker.internet;
    worker.lastHeartbeatAt = Date.now();
    const st = (phone_status || '').toString().toLowerCase();
    worker.status = (st === 'ready' || st === 'online') ? 'ONLINE' : 'BUSY';
    worker.currentMatchId = current_match_id ? String(current_match_id) : undefined;
  }

  res.json({ success: true, serverTime: Date.now() });
};

app.post('/api/workers/host/heartbeat', handleWorkerHeartbeat);
app.get('/api/workers/host/heartbeat', handleWorkerHeartbeat);
app.post('/api/workers/heartbeat', handleWorkerHeartbeat);
app.get('/api/workers/heartbeat', handleWorkerHeartbeat);

// Temporary Screenshot In-Memory Storage (60 min expiration)
interface TempScreenshot {
  id: string;
  matchId: string;
  data: string; // Base64 or image URL
  createdAt: number;
  expiresAt: number;
}
const tempScreenshots = new Map<string, TempScreenshot>();

// Verification Job Queue
const verificationJobs = new Map<string, VerificationJob>();

// Cleanup worker for expired screenshots (60 mins) unless disputed
setInterval(() => {
  const now = Date.now();
  for (const [id, temp] of tempScreenshots.entries()) {
    if (now > temp.expiresAt) {
      const match = matches.get(temp.matchId);
      // Keep screenshot if match is in DISPUTED state for admin review
      if (!match || match.status !== 'DISPUTED') {
        tempScreenshots.delete(id);
        console.log(`[Temp Screenshot Expired] Deleted temporary screenshot ${id} for match ${temp.matchId}`);
      }
    }
  }

  // Expire verification jobs older than 60 mins
  for (const [token, job] of verificationJobs.entries()) {
    const jobExp = new Date(job.expires_at).getTime();
    if (now > jobExp && job.state === 'PENDING') {
      job.state = 'EXPIRED';
      console.log(`[Verification Job Expired] Marked job for token ${token} as EXPIRED`);
    }
  }
}, 10000);

// Serve temporary screenshot
app.get('/api/temp/upload/:id', (req: Request, res: Response) => {
  const rawId = req.params.id || '';
  const cleanId = rawId.replace(/\.png$/i, '').trim();
  const temp = tempScreenshots.get(cleanId);

  if (!temp || Date.now() > temp.expiresAt) {
    const match = matches.get(temp?.matchId || '');
    if (!match || match.status !== 'DISPUTED') {
      return res.status(404).json({ error: 'Screenshot expired or not found' });
    }
  }

  if (temp.data.startsWith('data:image')) {
    const parts = temp.data.split(',');
    const mime = parts[0].match(/:(.*?);/)?.[1] || 'image/png';
    const imgBuf = Buffer.from(parts[1], 'base64');
    res.setHeader('Content-Type', mime);
    return res.send(imgBuf);
  } else if (temp.data.startsWith('http')) {
    return res.redirect(temp.data);
  }

  res.status(404).json({ error: 'Invalid image format' });
});

// GET Verification Jobs Queue Endpoint for MacroDroid Verification Phone
app.get('/api/workers/verification/start', (req: Request, res: Response) => {
  const now = Date.now();
  const pendingJobs: VerificationJob[] = [];
  const includeAll = req.query.all === 'true' || req.query.include_processing === 'true';

  for (const job of verificationJobs.values()) {
    const jobExp = new Date(job.expires_at).getTime();
    const isUncompleted = job.state !== 'COMPLETED';

    if (now < jobExp && (isUncompleted || includeAll)) {
      pendingJobs.push({
        match_id: job.match_id,
        guest_id: job.guest_id,
        opponent_guest_id: job.opponent_guest_id,
        screenshot_url: job.screenshot_url,
        verification_token: job.verification_token,
        created_at: job.created_at,
        expires_at: job.expires_at,
        state: job.state,
      });

      if (req.query.claim === 'true') {
        job.state = 'PROCESSING';
      }
    }
  }

  res.json(pendingJobs);
});

// View all active verification jobs
app.get('/api/workers/verification/jobs', (req: Request, res: Response) => {
  const allJobs = Array.from(verificationJobs.values());
  res.json(allJobs);
});

// MacroDroid Verification Phone Result Handler
const handleVerificationResult = (req: Request, res: Response) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const payload = parseBodyPayload(req);
  console.log('[MacroDroid Verification Result Received]', payload);

  // Check if this payload is actually a Host Phone Status / Room Creation update sent to this endpoint by MacroDroid
  const isHostStatusPayload = 
    payload.phone_status !== undefined || 
    payload.phoneStatus !== undefined ||
    payload.msg_code !== undefined || 
    payload.msgCode !== undefined ||
    payload.room_id !== undefined || 
    payload.roomId !== undefined || 
    payload.worker_id !== undefined ||
    (payload.is_valid_screenshot === undefined && payload.isValidScreenshot === undefined && payload.is_winner === undefined && payload.isWinner === undefined);

  if (isHostStatusPayload) {
    console.log('[MacroDroid /api/workers/verification/result] Delegating host status payload to handleHostStatus');
    return handleHostStatus(req, res);
  }

  const {
    verification_token,
    verificationToken,
    access_token,
    accessToken,
    token,
    match_id,
    matchId,
    guest_id,
    guestId,
    is_valid_screenshot,
    isValidScreenshot,
    is_winner,
    isWinner,
    confidence = 0.95,
    detected_text = 'BOOYAH',
    message = 'Official Free Fire winner screen detected',
  } = payload;

  const effToken = (verification_token || verificationToken || access_token || accessToken || token || '').toString().trim();
  const job = effToken ? verificationJobs.get(effToken) : undefined;

  const effMatchId = (match_id || matchId || job?.match_id || '').toString().trim();
  const effGuestId = (guest_id || guestId || job?.guest_id || '').toString().trim();

  if (!effMatchId || !effGuestId || !effToken) {
    console.warn('[Verification Result Missing Required Fields]', { effMatchId, effGuestId, effToken, payload });
    return res.status(400).json({ error: 'match_id, guest_id, and verification_token are required' });
  }

  if (job && job.state === 'COMPLETED') {
    return res.json({ success: true, message: 'Duplicate verification result ignored', code: 200 });
  }

  const match = matches.get(effMatchId);
  if (!match) {
    return res.status(404).json({ error: 'Match not found' });
  }

  // Idempotency check: if payout already finalized, ignore
  if (match.payout && match.payout.state === 'FINALIZED') {
    return res.json({ success: true, message: 'Match payout already finalized', code: 200 });
  }

  // Mark job as COMPLETED and remove from queue
  if (job) {
    job.state = 'COMPLETED';
  }

  const winner = guests.get(effGuestId);
  if (!winner) {
    return res.status(404).json({ error: 'Winner guest profile not found' });
  }

  const effValid = is_valid_screenshot !== undefined ? Boolean(is_valid_screenshot) : Boolean(isValidScreenshot ?? true);
  const effWinner = is_winner !== undefined ? Boolean(is_winner) : Boolean(isWinner ?? true);
  const confidencePct = Math.round((confidence > 1 ? confidence / 100 : confidence) * 100);
  const isOk = effValid && effWinner;

  match.claimedWinnerId = effGuestId;
  match.status = 'PENDING_VERIFICATION';
  match.verificationMessage = message || 'Official Free Fire winner screen detected';
  match.ocrVerification = {
    valid: isOk,
    detectedNickname: winner.nickname,
    detectedText: detected_text || 'BOOYAH',
    ocrConfidence: confidencePct,
    timestamp: Date.now(),
  };

  // 30-minute pending timer for pending reward
  match.pendingRewardExpiresAt = Date.now() + 30 * 60 * 1000;
  match.disputeWindowExpiresAt = match.pendingRewardExpiresAt;

  // Lock reward in pending coins for winner
  winner.pendingCoins += match.prize;

  console.log(`[Verification Phone Success] Match ${effMatchId} set to PENDING_VERIFICATION. Reward pending for ${winner.guestId}`);

  res.json({
    success: true,
    verification_token: effToken,
    match_id: effMatchId,
    guest_id: effGuestId,
    is_valid_screenshot: isOk,
    is_winner: effWinner,
    confidence: confidencePct,
    detected_text,
    message: match.verificationMessage,
    response_code: 200,
    match,
  });
};

app.post('/api/workers/verification/result', handleVerificationResult);
app.get('/api/workers/verification/result', handleVerificationResult);

// Confirm Room Joined
app.post('/api/matches/:id/join', (req: Request, res: Response) => {
  const { id } = req.params;
  const { guestId } = req.body;

  const match = matches.get(id);
  if (!match) return res.status(404).json({ error: 'Match not found' });

  if (match.playerA.guestId === guestId && match.playerAJoin) {
    match.playerAJoin.joined = true;
    match.playerAJoin.joinedAt = Date.now();
  } else if (match.playerB.guestId === guestId && match.playerBJoin) {
    match.playerBJoin.joined = true;
    match.playerBJoin.joinedAt = Date.now();
  }

  if (match.playerAJoin?.joined && match.playerBJoin?.joined) {
    match.status = 'IN_GAME';
  }

  res.json({ success: true, match });
});

// Close Room / Timer Expired -> Move Match to IN_GAME (Winner Result Verification Stage)
app.post('/api/matches/:id/close-room', (req: Request, res: Response) => {
  const { id } = req.params;
  const match = matches.get(id);
  if (!match) return res.status(404).json({ error: 'Match not found' });

  if (
    match.status === 'ROOM_READY' ||
    match.status === 'ROOM_CREATING' ||
    match.status === 'WAITING_FOR_ROOM'
  ) {
    match.status = 'IN_GAME';
    console.log(`[Match ${match.matchId}] Join timer expired / room closed -> Transitioned to IN_GAME for winner verification.`);
  }

  res.json({ success: true, match });
});

// Submit Screenshot & Create Verification Job in Queue
app.post('/api/matches/:id/verify', (req: Request, res: Response) => {
  const { id } = req.params;
  const { guestId, screenshotData, screenshotUrl } = req.body;

  const match = matches.get(id);
  if (!match) return res.status(404).json({ error: 'Match not found' });

  const isPlayerA = match.playerA.guestId === guestId;
  const claimingPlayer = isPlayerA ? match.playerA : match.playerB;
  const opponentPlayer = isPlayerA ? match.playerB : match.playerA;

  // 1. Create temporary screenshot record (60 minutes expiration)
  const tempImgId = `img_${Math.random().toString(36).substring(2, 10)}`;
  const rawImage = screenshotData || screenshotUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80';
  
  tempScreenshots.set(tempImgId, {
    id: tempImgId,
    matchId: match.matchId,
    data: rawImage,
    createdAt: Date.now(),
    expiresAt: Date.now() + 60 * 60 * 1000, // 60 minutes
  });

  const host = req.get('host') || 'localhost:3000';
  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const generatedTempUrl = `/api/temp/upload/${tempImgId}`;
  const fullTempUrl = `${protocol}://${host}/api/temp/upload/${tempImgId}.png`;

  // 2. Create Verification Job for MacroDroid Verification Phone Queue
  const verificationToken = `VERIFY_TOKEN_${Math.random().toString(36).substring(2, 8).toUpperCase()}_${Date.now()}`;
  const nowIso = new Date().toISOString();
  const expIso = new Date(Date.now() + 60 * 60 * 1000).toISOString();

  const job: VerificationJob = {
    match_id: match.matchId,
    guest_id: guestId,
    opponent_guest_id: opponentPlayer.guestId,
    screenshot_url: fullTempUrl,
    verification_token: verificationToken,
    created_at: nowIso,
    expires_at: expIso,
    state: 'PENDING',
  };

  verificationJobs.set(verificationToken, job);

  match.claimedWinnerId = guestId;
  match.screenshotUrl = generatedTempUrl;
  match.status = 'RESULT_VERIFICATION';

  console.log(`[Verification Job Created] Token: ${verificationToken} for Match ${match.matchId} by ${guestId} -> ${fullTempUrl}`);

  res.json({
    success: true,
    verificationToken,
    job,
    tempScreenshotUrl: generatedTempUrl,
    displayTempUrl: fullTempUrl,
    match,
  });
});

// File Dispute (Requires 5 Coin Deposit)
app.post('/api/matches/:id/dispute', (req: Request, res: Response) => {
  const { id } = req.params;
  const { guestId, action, reason, screenshotUrl } = req.body; // action: 'ACCEPT' or 'DISPUTE'

  const match = matches.get(id);
  if (!match) return res.status(404).json({ error: 'Match not found' });

  if (action === 'ACCEPT') {
    finalizePayout(id, match.claimedWinnerId || match.playerA.guestId);
    return res.json({ success: true, message: 'Result accepted. Prize credited!' });
  }

  const disputer = guests.get(guestId);
  if (!disputer) return res.status(404).json({ error: 'Guest not found' });

  // Check 5 Coin Dispute Deposit
  const DISPUTE_DEPOSIT = 5;
  if (disputer.coins < DISPUTE_DEPOSIT) {
    return res.status(400).json({
      error: `Submitting a dispute requires a ${DISPUTE_DEPOSIT} Coin deposit. You currently have ${disputer.coins} Coins.`,
      code: 'INSUFFICIENT_DISPUTE_DEPOSIT',
      requiredCoins: DISPUTE_DEPOSIT,
      availableCoins: disputer.coins,
    });
  }

  // Deduct 5 Coins immediately
  const prevBal = disputer.coins;
  disputer.coins -= DISPUTE_DEPOSIT;
  disputer.withdrawableCoins = Math.max(0, disputer.withdrawableCoins - DISPUTE_DEPOSIT);
  recordTransaction(
    guestId,
    'PENALTY',
    -DISPUTE_DEPOSIT,
    prevBal,
    disputer.coins,
    `5 Coin Deposit for Match Dispute (${match.matchId})`
  );

  const accusedGuestId = match.claimedWinnerId || (guestId === match.playerA.guestId ? match.playerB.guestId : match.playerA.guestId);

  // Format WhatsApp Admin Alert Notification
  const whatsAppAlertText = `ClashRen Dispute Alert\nMatch ID: ${match.matchId}\nClaimant Guest ID: ${guestId}\nOpponent Guest ID: ${accusedGuestId}\nDispute Deposit: 5 Coins\nReason: ${reason || 'Claimed winner is fake / hacking / incorrect result'}\nPlease review this dispute in the Admin Panel.`;

  console.log('====================================================');
  console.log('[WHATSAPP ADMIN DISPUTE ALERT TRIGGERED]');
  console.log(whatsAppAlertText);
  console.log('====================================================');

  // Freeze winner pending reward
  match.status = 'DISPUTED';
  match.dispute = {
    disputerGuestId: guestId,
    accusedGuestId,
    depositAmount: DISPUTE_DEPOSIT,
    reason: reason || 'Claimed winner is fake / hacking / incorrect result',
    screenshotUrl,
    status: 'OPEN',
    createdAt: Date.now(),
    whatsAppAlertText,
  };

  res.json({
    success: true,
    dispute: match.dispute,
    whatsAppAlertText,
    disputerCoins: disputer.coins,
  });
});

// Admin Dispute Resolution Route
app.post('/api/admin/disputes/:id/resolve', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { resolution, adminNotes } = req.body; // resolution: 'CASE_A_FAKE_WINNER' | 'CASE_B_GENUINE_WINNER'

  const match = matches.get(id);
  if (!match || !match.dispute) return res.status(400).json({ error: 'No open dispute for this match' });

  match.dispute.adminNotes = adminNotes;
  const disputer = guests.get(match.dispute.disputerGuestId);
  const accused = guests.get(match.dispute.accusedGuestId || match.claimedWinnerId || '');

  if (resolution === 'CASE_A_FAKE_WINNER') {
    // Fake Winner Case:
    // 1. Remove pending reward from fake winner
    if (accused) {
      accused.pendingCoins = Math.max(0, accused.pendingCoins - match.prize);
      accused.violationCount = (accused.violationCount || 0) + 1;
      accused.isBlocked = true;
      accused.blockReason = 'Result verification under admin review (Fake victory screenshot)';
      recordTransaction(accused.guestId, 'PENALTY', 0, accused.coins, accused.coins, `Fake Victory Penalty - Match ${match.matchId}`, ADMIN_EMAIL);
    }

    // 2. Credit prize to actual winner (disputer)
    if (disputer) {
      const prevBal = disputer.coins;
      disputer.coins += match.prize;
      disputer.withdrawableCoins += match.prize;
      disputer.wins += 1;
      recordTransaction(disputer.guestId, 'PRIZE', match.prize, prevBal, disputer.coins, `Dispute Won Victory Prize (${match.matchId})`, ADMIN_EMAIL);

      // 3. Refund 5 Coin dispute deposit
      const prevBal2 = disputer.coins;
      disputer.coins += 5;
      disputer.withdrawableCoins += 5;
      recordTransaction(disputer.guestId, 'REFUND', 5, prevBal2, disputer.coins, `Dispute Deposit Refund (${match.matchId})`, ADMIN_EMAIL);
    }

    match.dispute.status = 'RESOLVED_REVERSED';
    match.finalWinnerId = disputer?.guestId;
    match.status = 'FINALIZED';

  } else if (resolution === 'CASE_B_GENUINE_WINNER') {
    // Genuine Winner Case:
    // 1. Finalize pending reward to verified winner
    if (accused) {
      const prevBal = accused.coins;
      accused.pendingCoins = Math.max(0, accused.pendingCoins - match.prize);
      accused.coins += match.prize;
      accused.withdrawableCoins += match.prize;
      accused.wins += 1;
      recordTransaction(accused.guestId, 'PRIZE', match.prize, prevBal, accused.coins, `Match Victory Prize (${match.matchId})`, ADMIN_EMAIL);

      // 2. Transfer 5 Coin dispute deposit to verified winner
      const prevBal2 = accused.coins;
      accused.coins += 5;
      accused.withdrawableCoins += 5;
      recordTransaction(accused.guestId, 'ADD', 5, prevBal2, accused.coins, `Awarded False Dispute Deposit (${match.matchId})`, ADMIN_EMAIL);
    }

    // 3. Penalty for false disputer: Reduce trust score
    if (disputer) {
      disputer.trustScore = Math.max(30, disputer.trustScore - 15);
      disputer.losses += 1;
    }

    match.dispute.status = 'FALSE_DISPUTE';
    match.finalWinnerId = accused?.guestId;
    match.status = 'FINALIZED';
  }

  res.json({ success: true, match });
});

// Match details
app.get('/api/matches/:id', (req: Request, res: Response) => {
  const match = matches.get(req.params.id);
  if (!match) return res.status(404).json({ error: 'Match not found' });
  res.json(match);
});

// Submit Feedback
app.post('/api/feedback', (req: Request, res: Response) => {
  const { guestId, matchId, category, description, screenshotUrl, experienceRating } = req.body;

  const fb: UserFeedback = {
    id: `FB-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    guestId,
    matchId,
    category: category || 'Other',
    description: description || '',
    screenshotUrl,
    experienceRating,
    createdAt: Date.now(),
    status: 'NEW',
  };

  feedbacks.unshift(fb);
  res.json({ success: true, feedback: fb });
});

// Get Feedback (Public submit, Admin view)
app.get('/api/feedback', (req: Request, res: Response) => {
  res.json(feedbacks);
});

// ==========================================
// ADMIN AUTHENTICATION & MANAGEMENT ENDPOINTS
// ==========================================

// Admin Login (Server-Side Authentication)
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  if (email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASSWORD) {
    const token = `ADM_TK_${Math.random().toString(36).substring(2)}_${Date.now()}`;
    activeAdminTokens.add(token);
    return res.json({
      success: true,
      token,
      admin: {
        email: ADMIN_EMAIL,
        role: 'SUPER_ADMIN',
      },
    });
  }

  return res.status(401).json({ error: 'Invalid admin credentials.' });
});

// Admin Logout
app.post('/api/admin/logout', requireAdminAuth, (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7)
    : (req.headers['x-admin-token'] as string);

  if (token) {
    activeAdminTokens.delete(token);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// Verify Admin Token
app.get('/api/admin/verify', requireAdminAuth, (req: Request, res: Response) => {
  res.json({ valid: true, email: ADMIN_EMAIL });
});

// Admin Overview Metrics, Workers, Matches & Players
app.get('/api/admin/overview', requireAdminAuth, (req: Request, res: Response) => {
  const allMatchesList = Array.from(matches.values());
  const activeMatchesList = allMatchesList.filter(
    (m) => m.status !== 'FINALIZED' && m.status !== 'CANCELLED'
  );
  const pendingRoomJobs = allMatchesList.filter(
    (m) => m.status === 'WAITING_FOR_ROOM' || m.status === 'ROOM_CREATING'
  );

  const totalWalletCoins = Array.from(guests.values()).reduce((sum, g) => sum + g.coins, 0);

  res.json({
    activePlayersCount: guests.size + 20,
    queuesCount: queues.length,
    activeMatchesCount: activeMatchesList.length,
    pendingRoomJobsCount: pendingRoomJobs.length,
    pendingVerificationCount: allMatchesList.filter((m) => m.status === 'PENDING_VERIFICATION').length,
    pendingDisputesCount: allMatchesList.filter((m) => m.status === 'DISPUTED').length,
    totalWalletCoins,
    workers: Array.from(workers.values()),
    verificationWorker,
    feedbacksCount: feedbacks.length,
    activeMatches: activeMatchesList,
    pendingRoomJobs,
    recentMatches: allMatchesList.slice(-20).reverse(),
    activePlayersList: Array.from(guests.values()),
    recentTransactions: coinTransactions.slice(0, 30),
  });
});

// Admin: Search Guest by Guest ID or Nickname
app.get('/api/admin/guest/search/:guestId', requireAdminAuth, (req: Request, res: Response) => {
  const search = req.params.guestId.trim().toUpperCase();

  const matchingGuests = Array.from(guests.values()).filter(
    (g) => g.guestId.toUpperCase().includes(search) || g.nickname.toUpperCase().includes(search)
  );

  if (matchingGuests.length === 0) {
    return res.status(404).json({ error: `No guest found matching ID or Nickname "${search}".` });
  }

  const primaryGuest = matchingGuests[0];
  const guestTxs = coinTransactions.filter((tx) => tx.guestId === primaryGuest.guestId);
  const guestMatches = Array.from(matches.values()).filter(
    (m) => m.playerA.guestId === primaryGuest.guestId || m.playerB.guestId === primaryGuest.guestId
  );

  res.json({
    guest: primaryGuest,
    matchingGuests,
    wallet: {
      coins: primaryGuest.coins,
      pendingCoins: primaryGuest.pendingCoins,
      lockedCoins: primaryGuest.lockedCoins,
      withdrawableCoins: primaryGuest.withdrawableCoins,
    },
    transactions: guestTxs,
    matchHistory: guestMatches,
  });
});

// Admin: Add or Remove Coins (Requires Admin Auth)
app.post('/api/admin/coins', requireAdminAuth, (req: Request, res: Response) => {
  const { guestId, amount, action, reason } = req.body || {};

  if (!guestId || typeof amount !== 'number' || amount <= 0 || !['ADD', 'REMOVE', 'PENALTY'].includes(action)) {
    return res.status(400).json({ error: 'Valid guestId, positive amount, and action (ADD, REMOVE, PENALTY) are required.' });
  }

  const guest = guests.get(guestId.trim());
  if (!guest) {
    return res.status(404).json({ error: `Guest ID ${guestId} not found.` });
  }

  const previousBalance = guest.coins;

  if (action === 'ADD') {
    guest.coins += amount;
    guest.withdrawableCoins += amount;
    const newBalance = guest.coins;

    const tx = recordTransaction(
      guest.guestId,
      'ADD',
      amount,
      previousBalance,
      newBalance,
      reason ? `Manual Deposit: ${reason}` : 'Manual Deposit',
      ADMIN_EMAIL
    );

    // Push real-time notification
    coinNotifications.push({
      id: `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      guestId: guest.guestId,
      amount,
      newBalance,
      message: `${amount} Coins Added Successfully! Your wallet has been credited by the ClashRen admin.`,
      createdAt: Date.now(),
      read: false,
    });

    return res.json({
      success: true,
      action: 'ADD',
      amount,
      previousBalance,
      newBalance,
      guest,
      transaction: tx,
    });
  } else {
    if (guest.coins < amount) {
      return res.status(400).json({
        error: `Cannot remove ${amount} coins. Guest currently has ${guest.coins} coins.`,
      });
    }

    const txAction = action === 'PENALTY' ? 'PENALTY' : 'REMOVE';
    guest.coins -= amount;
    guest.withdrawableCoins = Math.max(0, guest.withdrawableCoins - amount);
    const newBalance = guest.coins;

    const tx = recordTransaction(
      guest.guestId,
      txAction,
      -amount,
      previousBalance,
      newBalance,
      reason ? `${txAction}: ${reason}` : `Manual ${txAction}`,
      ADMIN_EMAIL
    );

    return res.json({
      success: true,
      action: txAction,
      amount,
      previousBalance,
      newBalance,
      guest,
      transaction: tx,
    });
  }
});

// Admin: Freeze or Unfreeze Guest Wallet
app.post('/api/admin/guest/freeze-wallet', requireAdminAuth, (req: Request, res: Response) => {
  const { guestId, frozen } = req.body || {};
  const guest = guests.get(guestId);
  if (!guest) return res.status(404).json({ error: 'Guest not found' });

  guest.walletFrozen = Boolean(frozen);
  res.json({ success: true, guestId: guest.guestId, walletFrozen: guest.walletFrozen });
});

// Admin: Block or Unblock Guest Account
app.post('/api/admin/guest/block', requireAdminAuth, (req: Request, res: Response) => {
  const { guestId, blocked, reason } = req.body || {};
  const guest = guests.get(guestId);
  if (!guest) return res.status(404).json({ error: 'Guest not found' });

  guest.isBlocked = Boolean(blocked);
  guest.blockReason = reason || 'Result verification under admin review.';
  if (guest.isBlocked) {
    guest.isEnabled = false;
  } else {
    guest.isEnabled = true;
  }

  res.json({ success: true, guestId: guest.guestId, isBlocked: guest.isBlocked, blockReason: guest.blockReason });
});

// Admin: Get All Transactions
app.get('/api/admin/transactions', requireAdminAuth, (req: Request, res: Response) => {
  res.json(coinTransactions);
});

// Admin: Simulate MacroDroid Response payload
app.post('/api/admin/simulate-macrodroid', requireAdminAuth, (req: Request, res: Response) => {
  const { matchId, phoneStatus, roomId, roomPassword, openFfUrl } = req.body;

  const match = matches.get(matchId);
  if (!match) return res.status(404).json({ error: 'Match not found' });

  const displayStatus = phoneStatus || 'Room Created';
  match.latestPhoneStatus = displayStatus;
  const ffUrl = openFfUrl || "intent://#Intent;package=com.dts.freefireth;end";
  match.openFfUrl = ffUrl;

  let mappedStatus: MacroDroidPhoneStatus = 'ready';
  const lower = displayStatus.toLowerCase();
  if (lower.includes('created')) mappedStatus = 'room_created';
  else if (lower.includes('launch')) mappedStatus = 'launching_game';
  else if (lower.includes('switch')) mappedStatus = 'switching_account';
  else if (lower.includes('open') || lower.includes('menu')) mappedStatus = 'opening_room_menu';
  else if (lower.includes('config')) mappedStatus = 'configuring_room';
  else if (lower.includes('creat')) mappedStatus = 'creating_room';
  else if (lower.includes('error')) mappedStatus = 'error';

  match.hostPhoneLogs.push({
    status: mappedStatus,
    timestamp: Date.now(),
    message: displayStatus,
  });

  if (lower.includes('created') || mappedStatus === 'room_created') {
    const rId = roomId || Math.floor(10000000 + Math.random() * 90000000).toString();
    const rPass = roomPassword || Math.floor(1000 + Math.random() * 9000).toString();

    match.roomCredentials = {
      roomId: rId,
      roomPassword: rPass,
      createdAt: Date.now(),
      joinWindowExpiresAt: Date.now() + 45000,
      openFfUrl: ffUrl,
    };
    match.status = 'ROOM_READY';
    match.latestPhoneStatus = 'Room Created';
  }

  res.json({ success: true, match });
});

// Admin: Toggle guest permission
app.post('/api/admin/guest/toggle', requireAdminAuth, (req: Request, res: Response) => {
  const { guestId, isEnabled } = req.body;
  const guest = guests.get(guestId);
  if (guest) {
    guest.isEnabled = isEnabled;
  }
  res.json({ success: true, guest });
});


// Vite Middleware for Dev, Static serving for Production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ClashRen Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
