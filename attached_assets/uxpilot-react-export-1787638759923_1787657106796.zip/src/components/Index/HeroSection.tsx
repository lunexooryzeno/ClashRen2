import React, { useRef } from "react";
import { motion } from 'framer-motion';
import { Rocket, Eye, ChevronRight, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  const containerRef = useRef(null);

  return (
    <section ref={containerRef} className="min-h-screen flex items-center justify-center text-center px-4 overflow-hidden bg-black pb-20 md:pt-40 md:pb-0 relative flex-col pt-16" id="section-1">
      <div className="relative container mx-auto px-4 lg:grid lg:grid-cols-2 items-center min-h-[calc(100vh-120px)] z-10">
        {/* Left Side (Desktop) / Top (Mobile): Visuals */}
        <div className="relative order-1 lg:order-2 flex items-center justify-center mb-10 lg:mb-0">
          <div className="w-full max-w-lg aspect-[4/3] md:aspect-square">
            {/* Pedestal Image Frame */}
            <div className="relative z-20 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
              <img
                src="https://github.com/lunexooryzeno/ClashRen2/blob/main/attached_assets/logo/1d88ab71-ecd0-4731-860b-c6cae072eed4.png?raw=true"
                alt="ClashRen Visual"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            </div>
          </div>
        </div>

        {/* Right Side (Desktop) / Bottom (Mobile): Content */}
        <div className="flex flex-col items-center lg:items-start text-center lg:text-left order-2 lg:order-1">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl md:text-5xl font-heading font-black text-white tracking-tight mb-6 leading-[0.9] uppercase whitespace-nowrap"
          >
            CLASH<span className="text-brand">REN</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-lg md:text-xl text-gray-400 max-w-xl mb-10 font-medium leading-relaxed"
          >
            Don't wait for your moment. Create it. Challenge real players, compete in intense matches, and turn every victory into another step toward the top.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative group"
            >
              <Button
                className="h-14 px-8 bg-brand hover:bg-brand/90 text-white rounded-xl text-base font-black transition-all shadow-[0_0_20px_rgba(255,30,39,0.3)] group-hover:shadow-[0_0_40px_rgba(255,30,39,0.6)] uppercase tracking-wider flex items-center justify-center gap-3 relative overflow-hidden group border-none"
                asChild
              >
                <a href="#">
                  <Rocket className="w-5 h-5 group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform duration-300" />
                  <span className="relative z-10">Play Now</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                </a>
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ y: -5, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                variant="outline"
                className="h-14 px-8 bg-white/5 border-white/10 hover:bg-white/10 hover:border-brand/50 text-white rounded-xl text-base font-black transition-all uppercase tracking-wider flex items-center justify-center gap-3 group relative overflow-hidden"
                asChild
              >
                <a href="#how-it-works">
                  <Eye className="w-5 h-5 text-brand group-hover:rotate-[360deg] transition-transform duration-500" />
                  <span className="group-hover:text-brand transition-colors duration-300">Explore</span>
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-brand/0 via-brand/5 to-brand/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                </a>
              </Button>
            </motion.div>
          </motion.div>

          {/* Social Proof/Stats Mini */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-12 flex items-center gap-6 text-gray-500 border-t border-white/5 pt-8 w-full justify-center lg:justify-start"
          >
            <div>
              <div className="text-white font-bold text-xl">10K+</div>
              <div className="text-[10px] uppercase tracking-widest">Active Players</div>
            </div>
            <div className="h-8 w-px bg-white/10"></div>
            <div>
              <div className="text-white font-bold text-xl">₹50K+</div>
              <div className="text-[10px] uppercase tracking-widest">Prizes Won</div>
            </div>
            <div className="h-8 w-px bg-white/10"></div>
            <div>
              <div className="text-white font-bold text-xl">24/7</div>
              <div className="text-[10px] uppercase tracking-widest">Matchmaking</div>
            </div>
          </motion.div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 w-full h-12 md:h-40 bg-gradient-to-t from-black via-black/20 to-transparent z-[5]"></div>
    </section>
  );
};

export default HeroSection;
