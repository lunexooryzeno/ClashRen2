import React from "react";
import { motion } from "framer-motion";
import { Zap, ShieldCheck, Trophy, BarChart3, Swords, Layers } from "lucide-react";

const WhyClashRenSection = () => {
  const features = [
    {
      icon: <Zap className="w-6 h-6 text-brand" />,
      title: "Instant Matchmaking",
      description: "Find opponents automatically without waiting for scheduled competitions."
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-brand" />,
      title: "Fair Play",
      description: "Built-in result verification and dispute mechanisms help protect competitive matches."
    },
    {
      icon: <Layers className="w-6 h-6 text-brand" />,
      title: "Transparent Rewards",
      description: "Clearly display entry requirements, rewards, and match outcomes."
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-brand" />,
      title: "Player Stats",
      description: "Track wins, losses, match history, performance, and progression."
    },
    {
      icon: <Trophy className="w-6 h-6 text-brand" />,
      title: "Competitive Tournaments",
      description: "Join scheduled tournaments and compete for larger rewards."
    },
    {
      icon: <Swords className="w-6 h-6 text-brand" />,
      title: "Multiple Game Modes",
      description: "Support different competitive formats and game modes."
    }
  ];

  return (
    <section className="py-20 bg-black relative overflow-hidden" id="why-clashren">
      <div className="container mx-auto px-6">
        <div className="mb-12 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-brand font-black tracking-[0.4em] text-[10px] uppercase mb-2 block">Advantages</span>
            <h2 className="font-heading font-black text-2xl md:text-5xl mb-4 tracking-tighter uppercase">
              WHY <span className="text-brand">CLASHREN?</span>
            </h2>
            <div className="w-16 h-1 bg-brand mx-auto rounded-full mb-6"></div>
          </motion.div>
        </div>

        <div className="flex flex-row overflow-x-auto pb-8 md:grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto scrollbar-hide snap-x snap-mandatory px-4 md:px-0">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5, borderColor: "rgba(255, 30, 39, 0.4)" }}
              className="min-w-[280px] md:min-w-0 p-8 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-sm transition-all group snap-center"
            >
              <div className="w-12 h-12 rounded-2xl bg-brand/10 flex items-center justify-center mb-6 group-hover:bg-brand/20 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyClashRenSection;