import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Rocket, Sparkles } from "lucide-react";

const CTASection = () => {
  return (
    <section className="py-24 px-4 relative overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative rounded-[2rem] overflow-hidden bg-zinc-950 border border-zinc-800 p-10 md:p-20 text-center isolate"
        >
          {/* Animated Background Elements */}
          <div className="absolute inset-0 -z-10 overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,30,39,0.18),transparent_70%)]" />
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

            {/* Background Beams */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute top-0 left-1/4 w-32 h-full bg-brand/10 blur-3xl animate-beam" />
              <div className="absolute top-0 left-2/4 w-32 h-full bg-brand/5 blur-3xl animate-beam [animation-delay:1.5s]" />
            </div>

            {/* Moving Glows */}
            <motion.div
              animate={{
                x: [0, 100, 0],
                y: [0, -50, 0],
                opacity: [0.2, 0.4, 0.2]
              }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="absolute -top-1/2 -right-1/4 w-full h-full bg-brand/20 rounded-full blur-[120px]"
            />
            <motion.div
              animate={{
                x: [0, -100, 0],
                y: [0, 50, 0],
                opacity: [0.1, 0.3, 0.1]
              }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              className="absolute -bottom-1/2 -left-1/4 w-full h-full bg-brand/10 rounded-full blur-[120px]"
            />
          </div>

          <div className="max-w-3xl mx-auto space-y-8 relative z-10">
            <div className="space-y-5">
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="flex justify-center"
              >
                <Badge
                  variant="outline"
                  className="border-brand/30 bg-brand/10 text-brand px-4 py-1.5 text-xs font-semibold tracking-wide backdrop-blur-sm"
                >
                  <Sparkles className="w-3.5 h-3.5 mr-1.5 animate-pulse" />
                  JOIN 10,000+ COMPETITORS
                </Badge>
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="text-4xl md:text-6xl font-bold font-heading tracking-tighter leading-tight"
              >
                READY TO{" "}
                <motion.span
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.35, type: "spring", stiffness: 200 }}
                  className="inline-block relative text-brand drop-shadow-[0_0_30px_rgba(255,30,39,0.5)]"
                >
                  DOMINATE?
                  <motion.span
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.7, duration: 0.5, ease: "easeOut" }}
                    className="absolute -bottom-1 left-0 right-0 h-1 bg-brand/60 rounded-full origin-left"
                  />
                </motion.span>
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="text-zinc-300 text-base md:text-lg max-w-2xl mx-auto leading-relaxed font-medium"
              >
                Join thousands of players already competing for glory and massive prize pools.
                Your legend starts with a single match.
              </motion.p>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2"
            >
              <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}>
                <Button
                  size="lg"
                  className="relative h-14 px-9 text-base font-bold rounded-2xl group overflow-hidden bg-brand hover:bg-brand/90 text-white transition-all duration-300 shadow-[0_0_20px_rgba(255,30,39,0.4)] hover:shadow-[0_0_35px_rgba(255,30,39,0.6)]"
                >
                  <div className="absolute inset-0 bg-[linear-gradient(120deg,transparent,rgba(255,255,255,0.3),transparent)] translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                  <span className="relative z-10 flex items-center">
                    <Rocket className="mr-2.5 w-4.5 h-4.5 group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform" />
                    PLAY NOW
                  </span>
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;