import React, { useRef, useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBolt, faChartLine, faGamepad, faShieldHalved, faTrophy, faUsers } from '@fortawesome/free-solid-svg-icons';
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";

const TiltCard = ({ children, className, lgSpan = false, rowSpan = false }: { children: React.ReactNode, className?: string, lgSpan?: boolean, rowSpan?: boolean }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateY,
        rotateX,
        transformStyle: "preserve-3d",
      }}
      className={`relative group overflow-hidden rounded-[2rem] border border-white/10 bg-surface/30 backdrop-blur-sm transition-shadow hover:shadow-[0_20px_50px_rgba(255,30,39,0.2)] ${lgSpan ? 'lg:col-span-2' : ''} ${rowSpan ? 'row-span-2' : ''} ${className}`}
    >
      <div style={{ transform: "translateZ(50px)", transformStyle: "preserve-3d" }} className="h-full w-full">
        {children}
      </div>
    </motion.div>
  );
};

const TournamentsSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <section className="py-24 px-4 md:px-12 bg-black relative overflow-hidden" id="section-3">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand/5 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-brand/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="mb-12 md:mb-16 relative z-10 text-center md:text-left">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-block"
        >
          <h2 className="font-heading font-black text-xl md:text-4xl mb-3 tracking-tighter uppercase leading-tight">
            WHY <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand to-red-500 italic">CLASHREN?</span>
          </h2>
          <div className="w-full h-1 bg-gradient-to-r from-brand to-transparent mb-4 md:mb-6"></div>
        </motion.div>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-gray-400 max-w-xl text-sm md:text-xl font-medium px-4 md:px-0"
        >
          The premier destination for competitive mobile gaming. Experience elite matchmaking, secure payments, and daily high-stakes action.
        </motion.p>
      </div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="flex flex-row-reverse overflow-x-auto pb-8 md:grid md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 md:auto-rows-[18rem] scrollbar-hide snap-x snap-mandatory px-4 md:px-0"
      >
        {/* Tile 6 */}
        <TiltCard className="min-w-[300px] h-[22rem] md:h-auto md:min-w-0 snap-center">
          <img alt="gaming community" className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 opacity-40 group-hover:opacity-70" src="https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_8f8529fdfb_baf232bbd8cedd63.png"/>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-8">
            <div className="text-brand text-3xl mb-4"><FontAwesomeIcon icon={faUsers} /></div>
            <h3 className="font-heading font-bold text-2xl mb-2 text-white">Global Arena</h3>
            <p className="text-gray-400 text-sm group-hover:text-gray-200 transition-colors">Connect and compete with thousands of verified players daily.</p>
          </div>
        </TiltCard>

        {/* Tile 5 */}
        <TiltCard className="min-w-[300px] h-[22rem] md:h-auto md:min-w-0 snap-center">
          <img alt="stats dashboard" className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 opacity-40 group-hover:opacity-70" src="https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_1abfbd058b_76eeebd0a08ea1b0.png"/>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-8">
            <div className="text-brand text-3xl mb-4"><FontAwesomeIcon icon={faChartLine} /></div>
            <h3 className="font-heading font-bold text-2xl mb-2 text-white">Advanced Stats</h3>
            <p className="text-gray-400 text-sm group-hover:text-gray-200 transition-colors">Detailed analytics for every game and win streak tracking.</p>
          </div>
        </TiltCard>

        {/* Tile 4 */}
        <TiltCard lgSpan className="h-[22rem] md:h-auto min-w-[300px] md:min-w-0 snap-center">
          <img alt="battle station" className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 opacity-50" src="https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_63727a524d_5bc0bfca8172be82.png"/>
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/60 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-between p-8">
            <div className="max-w-xs">
              <div className="text-brand text-3xl mb-4"><FontAwesomeIcon icon={faGamepad} /></div>
              <h3 className="font-heading font-bold text-2xl md:text-3xl mb-2 text-white uppercase italic">Multiple Modes</h3>
              <p className="text-gray-400">Ranked ladders, casual skirmishes, and weekly featured cups.</p>
            </div>
            <div className="hidden sm:block">
               <div className="px-6 py-2 bg-brand text-white text-xs font-black rounded-full animate-pulse tracking-widest shadow-[0_0_20px_rgba(255,30,39,0.4)]">LIVE NOW</div>
            </div>
          </div>
        </TiltCard>

        {/* Tile 3 */}
        <TiltCard className="min-w-[300px] h-[22rem] md:h-auto md:min-w-0 snap-center">
          <img alt="trophy prize" className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 opacity-40 group-hover:opacity-70" src="https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_e57b34f37e_272506039668f3fd.png"/>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-8">
            <div className="text-brand text-3xl mb-4"><FontAwesomeIcon icon={faTrophy} /></div>
            <h3 className="font-heading font-bold text-2xl mb-2 text-white">Elite Rewards</h3>
            <p className="text-gray-400 text-sm group-hover:text-gray-200 transition-colors">Win exclusive rewards, physical gear, and cash prizes in every conquest.</p>
          </div>
        </TiltCard>

        {/* Tile 2 */}
        <TiltCard className="min-w-[300px] h-[22rem] md:h-auto md:min-w-0 snap-center">
          <img alt="tournament stage" className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 opacity-40 group-hover:opacity-70" src="https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_bedb32d1a9_46dd57c963dfb6be.png"/>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-8">
            <div className="text-brand text-3xl mb-4"><FontAwesomeIcon icon={faShieldHalved} /></div>
            <h3 className="font-heading font-bold text-2xl mb-2 text-white">Fair & Secure</h3>
            <p className="text-gray-400 text-sm group-hover:text-gray-200 transition-colors">Verified matches with military-grade anti-cheat and transparent scoring.</p>
          </div>
        </TiltCard>

        {/* Tile 1 */}
        <TiltCard lgSpan rowSpan className="h-[22rem] md:h-auto min-w-[300px] md:min-w-0 snap-center">
          <img alt="mechanical keyboard" className="absolute inset-0 w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700 opacity-60 group-hover:opacity-100" src="https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_46b7fa72e9_4b50c5631846b0c6.png"/>
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
          <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-12">
            <div className="w-14 h-14 md:w-16 md:h-16 mb-4 md:mb-6 text-brand text-3xl md:text-4xl flex items-center justify-center bg-black/60 backdrop-blur-xl rounded-2xl border border-brand/30 shadow-[0_0_30px_rgba(255,30,39,0.3)]">
              <FontAwesomeIcon icon={faBolt} />
            </div>
            <h3 className="font-heading font-black text-2xl md:text-5xl mb-3 md:mb-4 text-white uppercase italic">Instant Matchmaking</h3>
            <p className="text-gray-300 text-sm md:text-lg max-w-md group-hover:text-white transition-colors">Jump into a match within seconds. No waiting, no queues — just pure competition with players at your level.</p>
          </div>
        </TiltCard>
      </motion.div>
    </section>
  );
};

export default TournamentsSection;