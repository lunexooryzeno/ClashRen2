import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleQuestion, faTrophy, faUsers, faWallet } from '@fortawesome/free-solid-svg-icons';
import { motion } from "framer-motion";

const StatsGrid = () => {
  const stats = [
    { icon: faUsers, value: "43", label: "Players Registered", color: "from-brand/20" },
    { icon: faCircleQuestion, value: "128", label: "Matches Played", color: "from-blue-500/10" },
    { icon: faTrophy, value: "28", label: "Matches Won", color: "from-yellow-500/10" },
    { icon: faWallet, value: "₹1,240", label: "Rewards Distributed", color: "from-green-500/10" },
  ];

  return (
    <section className="py-20 px-4 md:px-12 bg-black relative z-20 overflow-hidden" id="section-2">
      {/* Decorative background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>

      <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8 relative z-10">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: i * 0.1,
              ease: [0.22, 1, 0.36, 1]
            }}
            whileHover={{
              y: -8,
              transition: { duration: 0.3 }
            }}
            className={`flex flex-col items-center text-center p-6 md:p-10 rounded-[2rem] bg-gradient-to-br ${stat.color} to-transparent border border-white/5 backdrop-blur-sm transition-all group hover:border-brand/30 hover:shadow-[0_20px_50px_-20px_rgba(255,30,39,0.3)] perspective-1000`}
          >
            <motion.div
              whileHover={{ rotateY: 360 }}
              transition={{ duration: 0.8 }}
              className="text-brand text-3xl md:text-5xl mb-6 relative"
            >
              <div className="absolute inset-0 bg-brand/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <FontAwesomeIcon icon={stat.icon} className="relative z-10" />
            </motion.div>

            <div className="font-heading font-black text-3xl md:text-5xl mb-2 tracking-tighter text-white tabular-nums">
              {stat.value}
            </div>

            <div className="text-[10px] md:text-xs text-gray-500 uppercase tracking-[0.2em] font-black group-hover:text-gray-300 transition-colors">
              {stat.label}
            </div>

            {/* 3D accent line */}
            <div className="w-0 group-hover:w-12 h-1 bg-brand mt-4 rounded-full transition-all duration-500"></div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default StatsGrid;
