import React from "react";
import { motion } from "framer-motion";

const HowItWorksSection = () => {
  const steps = [
    {
      number: "01.",
      title: "Select Tournament",
      description: "Browse open brackets and pick the mode that suits your playstyle.",
      label: "CHOOSE",
      img_url: "https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_8e9977f9b8_9e7561f246335339.png"},
    {
      number: "02.",
      title: "Match Instantly",
      description: "Our system pairs you with opponents of similar skill in seconds.",
      label: "GET MATCHED",
      img_url: "https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_d70e499ba5_5ef1704ac7477c6c.png"},
    {
      number: "03.",
      title: "Battle to Win",
      description: "Two competitive gamers focused on screens with colorful LED lighting in a professional arena setup",
      label: "PLAY",
      img_url: "https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_7c7edd120b_b5305f68ebadf645.png"},
    {
      number: "04.",
      title: "Verify Victory",
      description: "Log the outcome and upload proof to verify your win.",
      label: "SUBMIT",
      img_url: "https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_3538d3fa49_aea9340b26e2c89e.png"},
    {
      number: "05.",
      title: "Claim Rewards",
      description: "Collect your prize and climb the leaderboard toward glory.",
      label: "WIN",
      img_url: "https://storage.googleapis.com/uxpilot-auth.appspot.com/gen_4ae500a6fd_a3e6cf4105b64fc7.png"},
  ];

  return (
    <section className="py-20 bg-black relative overflow-hidden" id="how-it-works">
      <div className="mb-12 text-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-brand font-black tracking-[0.4em] text-[10px] uppercase mb-2 block">Process</span>
          <h2 className="font-heading font-black text-2xl md:text-5xl mb-4 tracking-tighter uppercase">
            HOW <span className="text-brand">CLASHREN</span> WORKS
          </h2>
          <div className="w-16 h-1 bg-brand mx-auto rounded-full mb-6"></div>
        </motion.div>
      </div>

      <div className="relative">
        <div className="overflow-x-auto pb-8 scrollbar-hide">
          <div className="flex gap-4 md:gap-6 w-max px-4 md:px-12">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, borderColor: "rgba(255,30,39,0.4)" }}
                className="flex-shrink-0 w-[280px] md:w-[350px] relative rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl transition-all flex flex-col items-center text-center overflow-hidden"
              >
                <div className="w-full h-48 relative overflow-hidden group">
                  <img src={step.img_url} alt={step.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent" />
                  <div className="absolute top-4 left-4 z-20">
                    <span className="text-[10px] font-black tracking-widest text-white uppercase bg-brand/90 backdrop-blur-md px-3 py-1 rounded-md shadow-lg">
                      Step {step.number.replace('.', '')}
                    </span>
                  </div>
                </div>

                <div className="relative z-10 flex flex-col items-center w-full p-8 pt-6">
                  <div className="mb-4">
                    <span className="text-[10px] font-bold tracking-[0.3em] text-brand uppercase px-4 py-1.5 rounded-full border border-brand/30 bg-brand/5 backdrop-blur-sm">
                      {step.label}
                    </span>
                  </div>

                  <h3 className="font-heading font-black text-xl mb-4 text-white uppercase tracking-tight">
                    {step.title}
                  </h3>

                  <p className="text-zinc-400 text-sm leading-relaxed font-medium line-clamp-2">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;