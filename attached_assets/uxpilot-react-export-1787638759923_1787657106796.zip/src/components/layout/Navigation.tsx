import { NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload } from '@fortawesome/free-solid-svg-icons';
import { faUser } from '@fortawesome/free-regular-svg-icons';
import { motion } from 'framer-motion';

const Navigation = () => {
  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 w-full z-50 px-3 md:px-12 py-2.5 md:py-4 flex justify-between items-center bg-black/60 backdrop-blur-xl border-b border-white/5"
    >
      <NavLink to="/" className="flex items-center gap-1.5 shrink-0">
        <div className="w-7 h-7 md:w-12 md:h-12 relative">
          <img
            src="https://github.com/lunexooryzeno/ClashRen2/blob/main/attached_assets/logo/4f55a4f7-34e4-4bfd-917f-63446ec6b5de-removebg-preview.jpg?raw=true"
            alt="ClashRen Logo"
            className="w-full h-full object-contain"
          />
        </div>
        <span className="font-heading font-black text-sm md:text-xl tracking-tight">
          CLASH<span className="text-brand">REN</span>
        </span>
      </NavLink>
      {/* Action Buttons */}
      <div className="flex items-center gap-1.5 md:gap-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="px-2.5 md:px-6 py-1.5 md:py-2 rounded-lg border border-white/20 hover:bg-white/10 transition-all text-[10px] md:text-sm font-medium flex items-center gap-1.5 md:gap-2 whitespace-nowrap"
        >
          <FontAwesomeIcon icon={faUser} className="text-[10px] md:text-xs" /> Sign In
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="px-2.5 md:px-6 py-1.5 md:py-2 rounded-lg bg-brand hover:bg-red-600 transition-all text-[10px] md:text-sm font-bold flex items-center gap-1.5 md:gap-2 shadow-[0_0_15px_rgba(255,30,39,0.3)] text-white whitespace-nowrap"
        >
          <FontAwesomeIcon icon={faDownload} className="text-[10px] md:text-xs" /> Download
        </motion.button>
      </div>
    </motion.nav>
  );
};

export default Navigation;
