import { NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDiscord, faWhatsapp, faInstagram, faYoutube } from '@fortawesome/free-brands-svg-icons';

const Footer = () => {
  return (
    <footer className="bg-black py-16 px-6 md:px-12 border-t border-white/5">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        <div>
          <NavLink to="/" className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 relative">
              <img
                src="https://github.com/lunexooryzeno/ClashRen2/blob/main/attached_assets/logo/4f55a4f7-34e4-4bfd-917f-63446ec6b5de-removebg-preview.jpg?raw=true"
                alt="ClashRen Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <span className="font-heading font-bold text-xl tracking-tight">
              CLASH<span className="text-brand">REN</span>
            </span>
          </NavLink>
          <p className="text-gray-500 text-sm">The ultimate destination for competitive gaming tournaments.</p>
        </div>
        <div>
          <h4 className="font-bold mb-4 uppercase text-xs tracking-widest">Platform</h4>
          <ul className="space-y-2 text-gray-400 text-sm">
            <li><a className="hover:text-white" href="#">Tournaments</a></li>
            <li><a className="hover:text-white" href="#">Leaderboard</a></li>
            <li><a className="hover:text-white" href="#">Rewards</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-4 uppercase text-xs tracking-widest">Company</h4>
          <ul className="space-y-2 text-gray-400 text-sm">
            <li><a className="hover:text-white" href="#">About Us</a></li>
            <li><a className="hover:text-white" href="#">Careers</a></li>
            <li><a className="hover:text-white" href="#">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-4 uppercase text-xs tracking-widest">Legal</h4>
          <ul className="space-y-2 text-gray-400 text-sm">
            <li><a className="hover:text-white" href="#">Terms of Service</a></li>
            <li><a className="hover:text-white" href="#">Privacy Policy</a></li>
          </ul>
        </div>
      </div>
      <div className="pt-8 border-t border-line flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="text-gray-600 text-xs">© 2026 ClashRen. All rights reserved.</div>
        <div className="flex gap-6 text-gray-400">
          <a className="hover:text-white" href="#"><FontAwesomeIcon icon={faDiscord} /></a>
          <a className="hover:text-white" href="#"><FontAwesomeIcon icon={faWhatsapp} /></a>
          <a className="hover:text-white" href="#"><FontAwesomeIcon icon={faInstagram} /></a>
          <a className="hover:text-white" href="#"><FontAwesomeIcon icon={faYoutube} /></a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
