import "@/styles/clashren-esports-tournaments.css";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/Index/HeroSection";
import HowItWorksSection from "@/components/Index/HowItWorksSection";
import Navigation from "@/components/layout/Navigation";
import TournamentsSection from "@/components/Index/TournamentsSection";
import CTASection from "@/components/Index/CTASection";
import { motion } from "framer-motion";

const Index = () => {
  return (
    <div className="bg-black text-white overflow-x-hidden">
      <Navigation />
      <HeroSection />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <HowItWorksSection />
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
      >
        <TournamentsSection />
      </motion.div>

      <CTASection />

      <Footer />
    </div>
  );
};

export default Index;
